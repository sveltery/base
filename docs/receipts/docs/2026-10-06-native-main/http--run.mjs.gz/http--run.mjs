import { spawn } from 'node:child_process';
import { open } from 'node:fs/promises';
const output=await open('.checks/http/server.log','w');
const child=spawn(process.execPath,['node_modules/vite/bin/vite.js','--host','127.0.0.1','--port','5178','--strictPort'],{cwd:'apps/docs',env:{...process.env,NODE_OPTIONS:'--max-old-space-size=2048'},stdio:['ignore',output.fd,output.fd]});
try {
 const deadline=Date.now()+45000;
 while(true){try{const response=await fetch('http://127.0.0.1:5178/docs/');if(response.ok)break;throw Error(`HTTP ${response.status}`);}catch(error){if(Date.now()>deadline)throw error;await new Promise(resolve=>setTimeout(resolve,200));}}
 await import('./check.mjs');
}finally{child.kill('SIGTERM');await new Promise(resolve=>{child.once('exit',resolve);setTimeout(()=>{child.kill('SIGKILL');resolve();},5000).unref();});await output.close();}
