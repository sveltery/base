import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import ts from '../../node_modules/typescript/lib/typescript.js';
const pin='47b40521eab921c2756bf9bdb0b0f07fbfdb8c8c';
const original=execFileSync('git',['--git-dir=../upstream-base-ui/.git','show',pin+':docs/src/components/Demo/Demo.tsx'],{encoding:'utf8'});
const native=readFileSync('apps/docs/src/lib/docs/Demo.svelte','utf8');
const sourceBody=original.slice(original.indexOf('  const onOpenChange = useStableCallback('),original.indexOf('\n  const onSelectFile ='));
const nativeBody=native.slice(native.indexOf('  async function openChange('),native.indexOf('\n</script>'));
const host={ getBoundingClientRect(){return {top:-10}},ownerDocument:{defaultView:{scrollBy(){}}} };
const cases=[];
const sourceProgram=ts.transpileModule(sourceBody+'\nreturn onOpenChange;', {compilerOptions:{target:ts.ScriptTarget.ESNext}}).outputText;
const onSource=new Function('useStableCallback','ga','demoId','demoSlug','collapsibleTriggerRef','ReactDOM','demo','ownerWindow',sourceProgram)(x=>x,null,'id','slug',{current:host},{flushSync:cb=>cb()},{setExpanded(){}},()=>host.ownerDocument.defaultView);
onSource(false); cases.push({implementation:'exact Original callback body',result:'completed using captured host'});
const nativeProgram=ts.transpileModule(nativeBody+'\nreturn openChange;', {compilerOptions:{target:ts.ScriptTarget.ESNext}}).outputText;
const onNative=new Function('tick',`let expanded=true; let buttonVisualEl=arguments[1];\n${nativeProgram}`)(async()=>{},host);
// Run exact native callback under a literal binding cleanup at the await boundary.
const teardownProgram=ts.transpileModule('let expanded=true; let buttonVisualEl=host;\n'+nativeBody+'\nconst pending=openChange(false); buttonVisualEl=null; return pending;', {compilerOptions:{target:ts.ScriptTarget.ESNext}}).outputText;
try { await new Function('tick','host',teardownProgram)(async()=>{},host); cases.push({implementation:'native callback with binding cleanup',result:'completed'}); }
catch(error){cases.push({implementation:'native callback with binding cleanup',result:'rejected',message:error.message});}
assert.equal(cases[1].result,'rejected');
const record={pin,originalPath:'docs/src/components/Demo/Demo.tsx',nativePath:'apps/docs/src/lib/docs/Demo.svelte',originalSha256:createHash('sha256').update(original).digest('hex'),nativeSha256:createHash('sha256').update(native).digest('hex'),sourceBody,nativeBody,cases,limits:'Actual extracted function bodies with synthetic host/commit boundary. Supplemental ownership reproduction, no mounted browser or unchanged upstream assertion credit.'};
writeFileSync('.checks/docs-lifetime/red.json',JSON.stringify(record,null,2)+'\n');
console.log(cases);
