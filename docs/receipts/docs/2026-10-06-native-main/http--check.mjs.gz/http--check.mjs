import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { docs } from '../../apps/fixtures/src/lib/docs/content.ts';
const base='http://127.0.0.1:5178';
const pages=[];
for (const doc of docs) {
 const url=`/docs/${doc.slug ? `${doc.slug}/` : ''}`;
 const response=await fetch(base+url);const html=await response.text();
 assert.equal(response.status,200,url); assert(html.includes(doc.title.replaceAll('&','&amp;'))||html.includes(doc.title),`${url} title`);
 for(const section of doc.sections) assert(html.includes(`id="${section.id}"`),`${url} #${section.id}`);
 pages.push({url,status:response.status,bytes:Buffer.byteLength(html),sections:doc.sections.length,sha256:createHash('sha256').update(html).digest('hex')});
}
const notices=await fetch(base+'/THIRD_PARTY_NOTICES.txt');assert.equal(notices.status,200);const served=Buffer.from(await notices.arrayBuffer());
const source=await readFile('apps/docs/static/THIRD_PARTY_NOTICES.txt');assert(served.equals(source));
const assets=[];
for(const path of ['/fonts/OFL.txt','/fonts/paper-mono.woff2']){const response=await fetch(base+path);assert.equal(response.status,200,path);const bytes=Buffer.from(await response.arrayBuffer());assert(bytes.equals(await readFile('apps/docs/static'+path)));assets.push({path,status:response.status,sha256:createHash('sha256').update(bytes).digest('hex')});}
const receipt={assets,status:'HTTP availability and SSR markup only; zero secured-browser or unchanged Source assertion credit',pages,notices:{status:notices.status,sha256:createHash('sha256').update(served).digest('hex')}};
await writeFile('.checks/http/results.json',JSON.stringify(receipt,null,2)+'\n');console.log(`${pages.length} authored HTTP routes and section IDs; source/served notices equal; no browser credit`);
