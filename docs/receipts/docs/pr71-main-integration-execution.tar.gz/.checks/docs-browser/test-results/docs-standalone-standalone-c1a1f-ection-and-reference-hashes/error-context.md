# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: docs-standalone.spec.ts >> standalone navigation, source code copy/selection and reference hashes
- Location: tests/docs-browser/docs-standalone.spec.ts:3:1

# Error details

```
Error: browserType.launch: Executable doesn't exist at /workspace/scratch/ac7ece966cf5/pr71-integration/.checks/pr71-integration/browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     pnpm exec playwright install                           ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```