# Popup family de989 complete used Source/native review

Frozen `de98922a3eba042d4097dc6edb0a51ab860ed72c`, Original `47b40521eab921c2756bf9bdb0b0f07fbfdb8c8c`. Overall **NOT CLEAR** because canonical useClick remains reopened. Every actual189 local module is recorded below; no whole historical family CLEAR is inherited. Imports/callers/member kinds, exact body/archive identities and precise nested authority records are in audit.json.

## packages/base/src/lib/direction-provider/context.ts

SHA256 `e400850423b49f956342a6efac2d8dcf2275365d23220564b6cefb8b44df47f8`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/anchor-positioning/useAnchorPositioning.svelte.ts (useDirection:runtime), packages/base/src/lib/utils/usePopupViewport.svelte.ts (useDirection:runtime).

## packages/base/src/lib/direction-provider/types.ts

SHA256 `a56af048e882453755ad2948782af4f2f832903e031d4812b8da9fc5f4b82aae`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/direction-provider/context.ts (TextDirection:type), packages/base/src/lib/internals/composite/composite.ts (TextDirection:type).

## packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts

SHA256 `c0d9f77faa3fa4fb8f78d01d958fdbc60ed960b043edfeb967f0b138ba367a9f`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Entire 986-line generic focus manager and full pinned Original: WeakRef prior-focus stack, tabindex, realm event classification, typeable combobox/modal/nonmodal/portal guards, pointer flags, inside-tree focus-out handling, hidden/inert isolation, initial focus scheduling, restore and return-focus ordering/cleanup. Latest explicit returnFocus callback/ref/boolean is read at actual effect cleanup; no full close-time snapshot remains. Menu-mounted default persistence is owned by MenuPopup, outside this generic helper.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/FloatingFocusManager.svelte (createFloatingFocusManager:runtime, FloatingFocusManagerProps:type).

## packages/base/src/lib/floating-ui/components/FloatingDelayGroup.svelte

SHA256 `8d23edb74b66c224cba535b1487b475313fae308f6b77957fa298df446021e7e`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Full native provider/context and Original full provider/defaults read; shared refs/context, initial delay ownership, live timeout getter and canonical Timeout retained; provider internal0 and future Tooltip public400 remain distinct.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/tooltip/Provider.svelte (default:runtime).

## packages/base/src/lib/floating-ui/components/FloatingDelayGroupContext.ts

SHA256 `4b3543c1123e580357ce02c3038cf89713de565ae310dca44550e7f90bb2a675`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Full native context/default body mapped to complete Original ContextValue/createContext default: one context lookup, shared default singleton, genuine provided refs/timer/current owner context. CLEAR; no invented provider or hover fallback.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/FloatingDelayGroup.svelte (FloatingDelayGroupContext:runtime, FloatingDelayGroupContextValue:type), packages/base/src/lib/floating-ui/hooks/useDelayGroup.svelte.ts (useFloatingDelayGroupContext:runtime).

## packages/base/src/lib/floating-ui/components/FloatingFocusManager.svelte

SHA256 `02e830d2f21614164344019f3bdd4420c4e0c58ddf49b12023c2202fcc236da8`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Popup.svelte (default:runtime).

## packages/base/src/lib/floating-ui/components/FloatingPortal.svelte

SHA256 `8111a018d91b947a0468565c84a636f6abb70196309da0a95fa5a4e86b3705b1`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Entire Full portal Source/context/child content adapter/consumer/lifetime body: canonical node getter remains readable after teardown, focus/tabbability/guard/inert/aria and markup projection preserve Source; no snapshot facade.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-shared-helper-review-058c281/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Portal.svelte (default:runtime).

## packages/base/src/lib/floating-ui/components/FloatingPortalContext.ts

SHA256 `897245ee2d655ee10875e45707bca62d75b11170e2cb5b8a575c6a2848533833`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (usePortalContext:runtime), packages/base/src/lib/floating-ui/components/FloatingPortal.svelte (PORTAL:runtime, FocusManagerState:type, FloatingPortalContext:type), packages/base/src/lib/floating-ui/hooks/useFloatingPortalNode.svelte.ts (usePortalContext:runtime).

## packages/base/src/lib/floating-ui/components/FloatingRootStore.svelte.ts

SHA256 `0f82be0f8c5c542753e3fc8bf5356066c20b71e2618b3decfa3698f5b91d5388`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/hooks/useFloating.svelte.ts (FloatingRootStore:type), packages/base/src/lib/floating-ui/hooks/useSyncedFloatingRootContext.svelte.ts (FloatingRootStore:runtime, FloatingRootState:type), packages/base/src/lib/floating-ui/types.ts (FloatingRootStore:type), packages/base/src/lib/utils/popups/store.ts (FloatingRootStore:runtime).

## packages/base/src/lib/floating-ui/components/FloatingTree.svelte.ts

SHA256 `40e508a5e0b3facfcf178890bb28a79e753d8e713d2e51c514724d4243a32027`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (useFloatingTree:runtime), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (useFloatingTree:runtime), packages/base/src/lib/floating-ui/hooks/useFloating.svelte.ts (useFloatingTree:runtime), packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts (useFloatingParentNodeId:runtime, useFloatingTree:runtime), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (useFloatingTree:runtime), packages/base/src/lib/popover/Positioner.svelte (useFloatingNodeId:runtime, provideFloatingNode:runtime), packages/base/src/lib/popover/Root.svelte (provideFloatingTree:runtime), packages/base/src/lib/preview-card/Positioner.svelte (useFloatingNodeId:runtime, provideFloatingNode:runtime), packages/base/src/lib/preview-card/Root.svelte (provideFloatingTree:runtime), packages/base/src/lib/utils/popups/popupStoreUtils.svelte.ts (useFloatingParentNodeId:runtime).

## packages/base/src/lib/floating-ui/components/FloatingTreeStore.ts

SHA256 `eb351b05f9f15cd7acebfe9b093cb42eb07c27073f41bd670633c94c41effdd3`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (FloatingTreeStore:runtime), packages/base/src/lib/floating-ui/components/FloatingTree.svelte.ts (FloatingTreeStore:runtime), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (FloatingTreeStore:runtime), packages/base/src/lib/floating-ui/hooks/useFloating.svelte.ts (FloatingTreeStore:type), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (FloatingTreeStore:type), packages/base/src/lib/floating-ui/types.ts (FloatingTreeStore:type), packages/base/src/lib/internals/anchor-positioning/types.ts (FloatingTreeStore:type).

## packages/base/src/lib/floating-ui/components/PortalContent.svelte

SHA256 `094ca8f25b2d4622ed70767b472ad6cecc481ae92470caa67385c72a3551f603`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/hooks/useFloatingPortalNode.svelte.ts (default:runtime).

## packages/base/src/lib/floating-ui/hooks/useClick.svelte.ts

SHA256 `34c159e4e2a0b468bea5d3f650050b83b7e63b41dbcd9a936543ec9ddaeb2b70`; fresh complete known reopened helper + complete Original; fresh current native full body: True.

Entire current221-line useClick and complete pinned234-line Original including all options/defaults, getNextOpen branches, frame/touch callbacks, enabled prop-bag selection, native currentTarget capture and memo-owned option/store closure. Fresh whole Popover Trigger call boundary read; retained callback ownership remains mismatched.

Source: NOT CLEAR: persistent reference/helper functions read live derived selected options/store; Original memo owns selected option/store closure retained by scheduled frame/touch callbacks and old prop bag.

Native: NOT CLEAR at Source lifetime boundary: preserving native defaults does not authorize changing business callback ownership to a later store/options.

Lifetime: Known P2: after policy/store changes a retained old bag or scheduled callback may use new reason/delay/store. A private accepted successor exists but is not this frozen body.

Maintainability: NOT CLEAR pending canonical bounded repair; do not add a family-local workaround or infer approval from identical older helper hash.

Complete Original owners: packages/react/src/floating-ui-react/hooks/useClick.ts

Actual incoming consumers: packages/base/src/lib/popover/Trigger.svelte (useClick:runtime).

## packages/base/src/lib/floating-ui/hooks/useClientPoint.svelte.ts

SHA256 `6a1953adb81d1875979353bffc2d43d1e1b73a32b55e681bfac1c433fba829a0`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Entire Source/client-point coordinates/focus/pointer/reference/static axes/uncontrolled conditions and native actual caller/store-owner timer/listener cleanup; zero-coordinate truthiness stays Source and no duplicate geometry driver.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-shared-helper-review-058c281/audit.json

Actual incoming consumers: packages/base/src/lib/tooltip/root/TooltipInteractions.svelte (useClientPoint:runtime).

## packages/base/src/lib/floating-ui/hooks/useDelayGroup.svelte.ts

SHA256 `5fbd431ac803aa0b09543055ff766e2afcb51c9ab1422b1135e8e5098b3982ed`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Full repaired native useDelayGroup/resetDelayRef and pinned Original consumer/provider read. Resource ownership captures ownedId and registers existing lifetime effect before openRef sync, close/reset and takeover; each timer guards the captured scheduling Store. Existing Source predicates, timeout values, cleanup cancellation, current-context close callbacks, initial delay resets and instant phase retained. No added state, generic render snapshot or lifecycle controller. Four actual paired unchanged equality cases plus15 native witnesses and strict32-file/scoped ESLint receipts pass. Prior P2 resolved at exact bd73205.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/tooltip/Trigger.svelte (useDelayGroup:runtime).

## packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts

SHA256 `bb2d0d06053246d50d15e8744efc322ed9413573e493a3d8dfba96f90e01d6ae`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/root/PopoverInteractions.svelte (useDismiss:runtime), packages/base/src/lib/preview-card/root/PreviewCardInteractions.svelte (useDismiss:runtime), packages/base/src/lib/tooltip/root/TooltipInteractions.svelte (useDismiss:runtime).

## packages/base/src/lib/floating-ui/hooks/useFloating.svelte.ts

SHA256 `dbd456a378ee02012d7cf8fb2db681f38e0a63b15d6fbb6894c8b293eb77c635`; fresh complete changed canonical bridge and full original/rootstore/native subscription/driver/caller boundary; fresh current native full body: True.

Entire original useFloatingWithStore/private useBaseUIFloating and complete current118-line canonical bridge: selected root store context, subscribed five state values, local null/undefined precedence, virtual/DOM reference conditions, default driver props, ref identities, element/context getter transport, node/tree publication and identity-owned teardown. Only repaired fallback raw store.state.floatingElement -> existing tracked floatingElement changes.

Source: CLEAR for this complete bridge and affected reviewed incoming boundary: native tracked selector supplies Original subscribed render value; undefined fallback responds to attaching positioner, explicit null still wins.

Native: CLEAR: existing createSubscriber-backed SvelteStore selected read is the native dependency; no render-version snapshot, hook lifecycle state machine, custom platform or extra geometry driver.

Lifetime: DOM and virtual position references keep independent precedence. Native geometry driver owns observer/task cancellation. dataRef/tree node publication teardown deletes only the same context it published; overlapping replacement survives.

Maintainability: CLEAR: one expression repair within the existing canonical bridge; complete source/refs/publication boundaries remain local and unchanged.

Complete Original owners: packages/react/src/floating-ui-react/hooks/useFloating.ts

Actual incoming consumers: packages/base/src/lib/internals/anchor-positioning/useAnchorPositioning.svelte.ts (useBaseUIFloating:runtime).

## packages/base/src/lib/floating-ui/hooks/useFloatingPortalNode.svelte.ts

SHA256 `6bfb1801f9ae16f8cfb97b87357e1b09e306361e1c005355acd7a34b6390a113`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Entire canonical portal-node creation/container/id/native realm observer/cleanup and child-content native snippet adapter; getWindow(node).MutationObserver preserves valid owner realm even with null defaultView. Capture owner/container and remove only this created node/content.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-shared-helper-review-058c281/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/FloatingPortal.svelte (useFloatingPortalNode:runtime, useFloatingPortalContent:runtime), packages/base/src/lib/utils/FloatingPortalLite.svelte (useFloatingPortalNode:runtime, useFloatingPortalContent:runtime, PortalContainer:type).

## packages/base/src/lib/floating-ui/hooks/useFocus.svelte.ts

SHA256 `0524a50da9077052ce98c908efdce6ec8fd3cfb5af7842aa57cb84ce0a95ab16`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Full focus-visible/safari/keyboard/mouse pointer bookkeeping, native focusin/out handlers, latest refs, disabled/open guards, delayed close and cleanup with actual current store/tree.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/preview-card/Trigger.svelte (useFocus:runtime), packages/base/src/lib/tooltip/Trigger.svelte (useFocus:runtime).

## packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts

SHA256 `384272183fd4420ea931d08e092e74f5bf7c4aa2ab183f25a019f668ccf9107a`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Entire 217-line floating-hover caller and full pinned Original: selected actual root/positioned store, open/reference/floating elements and tree parent; click/hover classification, inside interaction, pointer shielding/scope selection, enabled guards, mouse enter/leave descendant paths, close delay and child-close timer, listener/tree cleanup. Only shared instance selection changes to current accessor-derived instance.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Popup.svelte (useHoverFloatingInteraction:runtime), packages/base/src/lib/preview-card/Popup.svelte (useHoverFloatingInteraction:runtime), packages/base/src/lib/tooltip/Popup.svelte (useHoverFloatingInteraction:runtime).

## packages/base/src/lib/floating-ui/hooks/useHoverInteractionSharedState.svelte.ts

SHA256 `ef1574048bab3502c11609c1d085308bfb52f9294bc851efb0af50506dd1550e`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Entire HoverInteraction class and timers/dispose ownership plus full pinned Original helper: all constructor fields, pointer-mutation WeakMap authority, replacement/restoration order, initial store publication, current store selection and mount cleanup. Accessor returns the exact existing current dataRef.hoverInteractionState; an empty destination receives the initialized instance, without replacing an owned destination instance.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts (applySafePolygonPointerEventsMutation:runtime, clearSafePolygonPointerEventsMutation:runtime, isInteractiveElement:runtime, useHoverInteractionSharedState:runtime), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (applySafePolygonPointerEventsMutation:runtime, clearSafePolygonPointerEventsMutation:runtime, useHoverInteractionSharedState:runtime), packages/base/src/lib/tooltip/Trigger.svelte (useHoverInteractionSharedState:runtime).

## packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts

SHA256 `3bbc6e76e17a90be07b1b82536c3f8325e0f08641d771740ba7352494ae205dd`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Entire 398-line caller and full pinned Original: current store/context/tree and trigger selection; latest delay/rest/handleClose/enabled/shouldOpen/isClosing props; inactive-trigger and close-transition reentry rules; native mouse listeners, safe-polygon mutation, close timers, stale-open guard, rest movement thresholds, touch flushSync and returned DOM pointer props. Instance selection alone changes to current accessor-derived instance.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Trigger.svelte (useHoverReferenceInteraction:runtime), packages/base/src/lib/preview-card/Trigger.svelte (useHoverReferenceInteraction:runtime), packages/base/src/lib/tooltip/Trigger.svelte (useHoverReferenceInteraction:runtime).

## packages/base/src/lib/floating-ui/hooks/useHoverShared.ts

SHA256 `27321c9b2a6773e8743846b8af2a51a4339462f8189f1a9cad36b9702b4517df`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

All delay/rest function resolution, touch delay bypass, click-like classification, enabled-trigger ancestor matching and complete handle-close types/options.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/FloatingDelayGroup.svelte (getDelay:runtime), packages/base/src/lib/floating-ui/hooks/useDelayGroup.svelte.ts (getDelay:runtime), packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts (getDelay:runtime, isClickLikeOpenEvent:runtime, isHoverOpenEvent:runtime, isInsideEnabledTrigger:runtime), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (HandleClose:type, HandleCloseContextBase:type), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (getDelay:runtime, getRestMs:runtime, isClickLikeOpenEvent:runtime, isInsideEnabledTrigger:runtime), packages/base/src/lib/floating-ui/safePolygon.ts (HandleClose:type, HandleCloseOptions:type), packages/base/src/lib/tooltip/Trigger.svelte (getDelay:runtime).

## packages/base/src/lib/floating-ui/hooks/useSyncedFloatingRootContext.svelte.ts

SHA256 `144b7492c4df9f20f8da4b4fdbe5a5983219e2370c1fd6a4afef50226559815d`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/utils/popups/popupStoreUtils.svelte.ts (useSyncedFloatingRootContext:runtime).

## packages/base/src/lib/floating-ui/safePolygon.ts

SHA256 `8140d3e4f809bfe3fd1f6831752c66cf0fb811eee32fe4a0a9e33375387776b6`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Full 449 lines/full Original; speed thresholds, rect trough and all four quadrilateral geometries, overlap/landing/open-child guards, forty-ms close timer and handle options. No competing geometry algorithm.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/types.ts (SafePolygonOptions:type), packages/base/src/lib/popover/Trigger.svelte (safePolygon:runtime), packages/base/src/lib/preview-card/Trigger.svelte (safePolygon:runtime), packages/base/src/lib/tooltip/Trigger.svelte (safePolygon:runtime).

## packages/base/src/lib/floating-ui/types.ts

SHA256 `d75465f0e2fa7f46beab37d200f2f9e5a152dd4ca4a5751e5c9ca2811caed3d5`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Full native root versus positioned context/ref/element types, event/dataRef/node/tree shapes, arbitrary Source payload allowance, actual used hover/type exports. Original unused barrel/platform/render type fanout remains unselected.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (FloatingContext:type, FloatingRootContext:type), packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (FloatingUIOpenChangeDetails:type), packages/base/src/lib/floating-ui/components/FloatingDelayGroup.svelte (Delay:type), packages/base/src/lib/floating-ui/components/FloatingDelayGroupContext.ts (Delay:type), packages/base/src/lib/floating-ui/components/FloatingRootStore.svelte.ts (FloatingEvents:type, ContextData:type, ReferenceType:type), packages/base/src/lib/floating-ui/components/FloatingRootStore.svelte.ts (FloatingUIOpenChangeDetails:type), packages/base/src/lib/floating-ui/components/FloatingTree.svelte.ts (FloatingNodeType:type), packages/base/src/lib/floating-ui/components/FloatingTreeStore.ts (FloatingNodeType:type, FloatingEvents:type), packages/base/src/lib/floating-ui/hooks/useClick.svelte.ts (ElementProps:type, FloatingContext:type, FloatingRootContext:type), packages/base/src/lib/floating-ui/hooks/useClientPoint.svelte.ts (ContextData:type, ElementProps:type, FloatingContext:type, FloatingRootContext:type), packages/base/src/lib/floating-ui/hooks/useDelayGroup.svelte.ts (FloatingRootContext:type, Delay:type, FloatingContext:type), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (ElementProps:type, FloatingContext:type, FloatingRootContext:type), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (FloatingUIOpenChangeDetails:type), packages/base/src/lib/floating-ui/hooks/useFloating.svelte.ts (PositionedFloatingContext:type, ReferenceType:type), packages/base/src/lib/floating-ui/hooks/useFocus.svelte.ts (ElementProps:type, FloatingContext:type, FloatingRootContext:type), packages/base/src/lib/floating-ui/hooks/useFocus.svelte.ts (FloatingUIOpenChangeDetails:type), packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts (FloatingContext:type, FloatingRootContext:type), packages/base/src/lib/floating-ui/hooks/useHoverInteractionSharedState.svelte.ts (ContextData:type, FloatingRootContext:type, SafePolygonOptions:type), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (FloatingUIOpenChangeDetails:type), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (Delay:type, FloatingContext:type, FloatingRootContext:type), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (PositionedFloatingContext:type), packages/base/src/lib/floating-ui/hooks/useHoverShared.ts (ExtendedElements:type, FloatingTreeType:type, Placement:type), packages/base/src/lib/floating-ui/utils/createEventEmitter.ts (FloatingEvents:type), packages/base/src/lib/floating-ui/utils/nodes.ts (FloatingNodeType:type), packages/base/src/lib/internals/anchor-positioning/types.ts (FloatingRootContext:type), packages/base/src/lib/utils/popups/store.ts (FloatingRootContext:type).

## packages/base/src/lib/floating-ui/utils/composite.ts

SHA256 `96b8fde56711a770d9c1936cfae99d9576009539cc5c68ef139f463533893d27`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (isElementVisible:runtime), packages/base/src/lib/floating-ui/utils/tabbable.ts (isElementVisible:runtime).

## packages/base/src/lib/floating-ui/utils/constants.ts

SHA256 `14ac30673b196081a83c1e023ecfd546294733ceb2f756d2bad01e3a9d24880b`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/utils/element.ts (FOCUSABLE_ATTRIBUTE:runtime, TYPEABLE_SELECTOR:runtime).

## packages/base/src/lib/floating-ui/utils/createAttribute.ts

SHA256 `24fb1aacf4668a0ada9cfcb8d1f516b3ef7d5022df3f3b0a375394e260f07f4a`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (createAttribute:runtime), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (createAttribute:runtime), packages/base/src/lib/floating-ui/hooks/useFloatingPortalNode.svelte.ts (createAttribute:runtime), packages/base/src/lib/floating-ui/hooks/useFocus.svelte.ts (createAttribute:runtime).

## packages/base/src/lib/floating-ui/utils/createEventEmitter.ts

SHA256 `31ebcaf59c98304ec9944e91a86b0a3c3ed31359e76a102ea62c4213f5dff484`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/FloatingRootStore.svelte.ts (createEventEmitter:runtime), packages/base/src/lib/floating-ui/components/FloatingTreeStore.ts (createEventEmitter:runtime).

## packages/base/src/lib/floating-ui/utils/element.ts

SHA256 `43da99a8e24b9713afaaa52f09f8b21b92681252d1c17824cc246e15400c79eb`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (activeElement:runtime, contains:runtime, getTarget:runtime, isTypeableCombobox:runtime, getFloatingFocusElement:runtime, isTypeableElement:runtime), packages/base/src/lib/floating-ui/hooks/useClick.svelte.ts (getTarget:runtime, isTypeableElement:runtime), packages/base/src/lib/floating-ui/hooks/useClientPoint.svelte.ts (contains:runtime, getTarget:runtime), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (contains:runtime, getTarget:runtime, isEventTargetWithin:runtime, isRootElement:runtime), packages/base/src/lib/floating-ui/hooks/useFocus.svelte.ts (activeElement:runtime, contains:runtime, getTarget:runtime, isTargetInsideEnabledTrigger:runtime, isTypeableElement:runtime, matchesFocusVisible:runtime), packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts (contains:runtime, getTarget:runtime), packages/base/src/lib/floating-ui/hooks/useHoverInteractionSharedState.svelte.ts (isInteractiveElement:runtime), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (contains:runtime, getTarget:runtime), packages/base/src/lib/floating-ui/hooks/useHoverShared.ts (isTargetInsideEnabledTrigger:runtime), packages/base/src/lib/floating-ui/safePolygon.ts (contains:runtime, getTarget:runtime), packages/base/src/lib/floating-ui/utils/tabbable.ts (activeElement:runtime, contains:runtime), packages/base/src/lib/tooltip/Trigger.svelte (contains:runtime), packages/base/src/lib/utils/popups/useTriggerFocusGuards.svelte.ts (contains:runtime).

## packages/base/src/lib/floating-ui/utils/enqueueFocus.ts

SHA256 `60067b93919c6f4210890af14627b5e064c6d0d3ee9e287f4f7752fab7474773`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (enqueueFocus:runtime).

## packages/base/src/lib/floating-ui/utils/event.ts

SHA256 `b489c469d9e2b134b6cd97baa3a408010decf1399dbaa1367a015d70c770832e`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (isVirtualClick:runtime, isVirtualPointerEvent:runtime, stopEvent:runtime), packages/base/src/lib/floating-ui/components/FloatingRootStore.svelte.ts (isClickLikeEvent:runtime), packages/base/src/lib/floating-ui/hooks/useClick.svelte.ts (isMouseLikePointerType:runtime, isVirtualPointerEvent:runtime), packages/base/src/lib/floating-ui/hooks/useClientPoint.svelte.ts (isMouseLikePointerType:runtime), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (isVirtualClick:runtime), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (isMouseLikePointerType:runtime), packages/base/src/lib/floating-ui/hooks/useHoverShared.ts (isMouseLikePointerType:runtime), packages/base/src/lib/internals/composite/utils/navigation.ts (stopEvent:runtime), packages/base/src/lib/tooltip/Trigger.svelte (isMouseLikePointerType:runtime).

## packages/base/src/lib/floating-ui/utils/markOthers.ts

SHA256 `0a6397de4ac741e96e98ef3756caed2200a6ff8564b55d04a8573aaf06037406`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (markOthers:runtime).

## packages/base/src/lib/floating-ui/utils/matchesFocusVisible.ts

SHA256 `b1788640106924aa5e790e88b711fdf02ce942c0ead034aa94be636188f1c3ac`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/utils/element.ts (matchesFocusVisible:runtime).

## packages/base/src/lib/floating-ui/utils/nodes.ts

SHA256 `b78d4c24b96237d20d09a60549535fad0d8e61661b38091cbf5368b53c43f544`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (getNodeAncestors:runtime, getNodeChildren:runtime), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (getNodeChildren:runtime), packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts (getNodeChildren:runtime), packages/base/src/lib/floating-ui/safePolygon.ts (getNodeChildren:runtime).

## packages/base/src/lib/floating-ui/utils/tabbable.ts

SHA256 `7e890249d9926089244d66728f1957c9b67f980f4459c874081be0c90016cbbb`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (tabbable:runtime, focusable:runtime, isOutsideEvent:runtime, isTabbable:runtime, getNextTabbable:runtime, getPreviousTabbable:runtime, FocusableElement:type), packages/base/src/lib/floating-ui/components/FloatingPortal.svelte (enableFocusInside:runtime, disableFocusInside:runtime, getPreviousTabbable:runtime, getNextTabbable:runtime, isOutsideEvent:runtime), packages/base/src/lib/floating-ui/utils/enqueueFocus.ts (FocusableElement:type), packages/base/src/lib/utils/popups/useTriggerFocusGuards.svelte.ts (getNextTabbable:runtime, getTabbableAfterElement:runtime, getTabbableBeforeElement:runtime, isOutsideEvent:runtime), packages/base/src/lib/utils/popups/useTriggerFocusGuards.svelte.ts (FocusableElement:type).

## packages/base/src/lib/internals/anchor-positioning/adaptive-origin.ts

SHA256 `af5859dc474117523d5fa7c93acad144667590bd3d35248b72ffd2164e6dd86e`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/anchor-positioning/useAnchorPositioning.svelte.ts (DEFAULT_SIDES:runtime), packages/base/src/lib/utils/usePopupViewport.svelte.ts (adaptiveOrigin:runtime).

## packages/base/src/lib/internals/anchor-positioning/arrow.ts

SHA256 `faae61704c235e00a268afc06f286dbde18d270b499c31da65e16b4a16fab3c6`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/anchor-positioning/policy.ts (baseArrow:runtime).

## packages/base/src/lib/internals/anchor-positioning/css-vars.ts

SHA256 `5987e5aac4cb32b02a7415edee76937ff2a17ce4d48a694fd2d7522ae0e47e78`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/anchor-positioning/policy.ts (*:runtime).

## packages/base/src/lib/internals/anchor-positioning/hide.ts

SHA256 `02c0e2ed225845ffbbd4b45ad7bd2c76b9af8976b7147980ca0f64b6022fad68`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/anchor-positioning/policy.ts (hide:runtime).

## packages/base/src/lib/internals/anchor-positioning/policy.ts

SHA256 `66337d95ad094898b0ae95c94c4e07ea14fd041c32cad6a4c2ec8113859cb42d`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/anchor-positioning/useAnchorPositioning.svelte.ts (autoUpdate:runtime, createPositioningPolicy:runtime, getAutoUpdateOptions:runtime, getLogicalSide:runtime, getPhysicalSide:runtime).

## packages/base/src/lib/internals/anchor-positioning/types.ts

SHA256 `fa56b8d2b5fac3e9c1ed9597f89631d6381e1e73d5da507b1d41ec566917b82b`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Entire geometry and Source interaction-store/tree bridge option types, independent open/mounted presence, refs/virtual anchors, logical side/alignment/collision unions, offsets, shift/lazy/inline/adaptive middleware and result metadata.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/anchor-positioning/policy.ts (AnchorPositioningOptions:type, Side:type), packages/base/src/lib/internals/anchor-positioning/useAnchorPositioning.svelte.ts (AnchorPositioningOptions:type, Reference:type, Align:type), packages/base/src/lib/internals/anchor-positioning/useFloating.svelte.ts (PositioningResult:type, Reference:type), packages/base/src/lib/popover/types.ts (Side:type, Align:type, AnchorPositioningOptions:type), packages/base/src/lib/preview-card/types.ts (Side:type, Align:type, AnchorPositioningOptions:type), packages/base/src/lib/tooltip/types.ts (Side:type, Align:type, AnchorPositioningOptions:type), packages/base/src/lib/utils/usePopupAutoResize.svelte.ts (Side:type), packages/base/src/lib/utils/usePopupViewport.svelte.ts (Side:type).

## packages/base/src/lib/internals/anchor-positioning/useAnchorPositioning.svelte.ts

SHA256 `a2b7d8284ece515de3ca1c65d342fcdbae395d5484a4f8fd121d9d11f835876d`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Entire anchor orchestration plus full Original useAnchorPositioning: real canonical BaseUI store/tree bridge or private geometry-only path, one default DOM driver, reactive anchor registration, styles/CSS middleware write ownership, lazy flip exit presence, arrow and position context outputs. No geometry/controller clone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Positioner.svelte (useAnchorPositioning:runtime), packages/base/src/lib/popover/positioner/PopoverPositionerContext.ts (useAnchorPositioning:type), packages/base/src/lib/preview-card/Positioner.svelte (useAnchorPositioning:runtime), packages/base/src/lib/preview-card/positioner/PreviewCardPositionerContext.ts (useAnchorPositioning:type), packages/base/src/lib/tooltip/Positioner.svelte (useAnchorPositioning:runtime), packages/base/src/lib/tooltip/positioner/TooltipPositionerContext.ts (useAnchorPositioning:type).

## packages/base/src/lib/internals/anchor-positioning/useFloating.svelte.ts

SHA256 `9f504f4289d1b38e2fc78830320beec60d5ec6fe40f183b132916594c7027c8a`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Entire 131-line sole native DOM driver and full Original useFloatingWithStore/useBaseUIFloating renderer boundary, plus full native bridge and native/Original anchor/MenuPositioner callers: current selected DOM/virtual references, independent refs, mounted/keepMounted exit presence, same-present-host positioned output, generation/request cancellation, connected-node middleware guard, autoUpdate cleanup, error handling, DPR style rounding and Source ref setter conditions. Native onDestroy marks lifetime end; only post-destroy element getters select actual owned referenceRef/floatingRef.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/hooks/useFloating.svelte.ts (useFloating:runtime, NativeFloatingOptions:type), packages/base/src/lib/internals/anchor-positioning/useAnchorPositioning.svelte.ts (useFloating:runtime).

## packages/base/src/lib/internals/composite/composite.ts

SHA256 `938a8b4ede73c5b5655a800777fe4748a94786a05bf828129de299c04cf94673`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/composite/utils/navigation.ts (ARROW_DOWN:runtime, ARROW_LEFT:runtime, ARROW_RIGHT:runtime, ARROW_UP:runtime), packages/base/src/lib/popover/Popup.svelte (COMPOSITE_KEYS:runtime).

## packages/base/src/lib/internals/composite/root/CompositeRootContext.ts

SHA256 `b08d6af5d6e71ba46076718b4426c7d2e0485a059e9204759406af1f395b6f2c`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/use-button/useButton.svelte.ts (useCompositeRootContext:runtime).

## packages/base/src/lib/internals/composite/utils/navigation.ts

SHA256 `bb61a6e117cc345c347a3a29618d01e6e608ef1027b8e6464e072d8b70b4a0aa`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/utils/composite.ts (*:runtime), packages/base/src/lib/internals/composite/composite.ts (isIndexOutOfListBounds:runtime, isListIndexDisabled:runtime, findNonDisabledListIndex:runtime, getMaxListIndex:runtime, getMinListIndex:runtime).

## packages/base/src/lib/internals/constants.ts

SHA256 `de12c9af7ce208e69f24e5bbfefb3df6840e5b4f284109597087188a338c6893`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

All actually used Source constant values, popup collision defaults, PATIENT_CLICK_THRESHOLD, typeahead interval and visually-hidden owner style; omitted swipe-only constants do not create unused business scope.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (CLICK_TRIGGER_IDENTIFIER:runtime), packages/base/src/lib/floating-ui/components/FloatingPortal.svelte (ownerVisuallyHidden:runtime), packages/base/src/lib/internals/getDisabledMountTransitionStyles.ts (DISABLED_TRANSITIONS_STYLE:runtime), packages/base/src/lib/popover/Positioner.svelte (POPUP_COLLISION_AVOIDANCE:runtime), packages/base/src/lib/popover/store/PopoverStore.svelte.ts (PATIENT_CLICK_THRESHOLD:runtime), packages/base/src/lib/popover/Trigger.svelte (CLICK_TRIGGER_IDENTIFIER:runtime), packages/base/src/lib/preview-card/Positioner.svelte (POPUP_COLLISION_AVOIDANCE:runtime), packages/base/src/lib/tooltip/Positioner.svelte (POPUP_COLLISION_AVOIDANCE:runtime).

## packages/base/src/lib/internals/createBaseUIEventDetails.ts

SHA256 `1a9cb6cde2734d421a1bfb03ece9c744584b7e115a0eb3b9de974c22ab8ee684`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (createChangeEventDetails:runtime), packages/base/src/lib/floating-ui/components/FloatingDelayGroupContext.ts (BaseUIChangeEventDetails:type), packages/base/src/lib/floating-ui/components/FloatingPortal.svelte (createChangeEventDetails:runtime), packages/base/src/lib/floating-ui/components/FloatingPortalContext.ts (BaseUIChangeEventDetails:type), packages/base/src/lib/floating-ui/components/FloatingRootStore.svelte.ts (BaseUIChangeEventDetails:type), packages/base/src/lib/floating-ui/hooks/useClick.svelte.ts (createChangeEventDetails:runtime), packages/base/src/lib/floating-ui/hooks/useDelayGroup.svelte.ts (createChangeEventDetails:runtime), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (createChangeEventDetails:runtime), packages/base/src/lib/floating-ui/hooks/useFocus.svelte.ts (createChangeEventDetails:runtime), packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts (createChangeEventDetails:runtime), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (createChangeEventDetails:runtime), packages/base/src/lib/floating-ui/hooks/useSyncedFloatingRootContext.svelte.ts (BaseUIChangeEventDetails:type), packages/base/src/lib/floating-ui/types.ts (BaseUIChangeEventDetails:type), packages/base/src/lib/popover/Close.svelte (createChangeEventDetails:runtime), packages/base/src/lib/popover/Root.svelte (createChangeEventDetails:runtime), packages/base/src/lib/popover/types.ts (BaseUIChangeEventDetails:type), packages/base/src/lib/preview-card/Root.svelte (createChangeEventDetails:runtime), packages/base/src/lib/preview-card/types.ts (BaseUIChangeEventDetails:type), packages/base/src/lib/tooltip/Root.svelte (createChangeEventDetails:runtime), packages/base/src/lib/tooltip/store/TooltipStore.svelte.ts (createChangeEventDetails:runtime), packages/base/src/lib/tooltip/Trigger.svelte (createChangeEventDetails:runtime), packages/base/src/lib/tooltip/types.ts (BaseUIChangeEventDetails:type), packages/base/src/lib/utils/popups/popupHandle.svelte.ts (createChangeEventDetails:runtime, BaseUIChangeEventDetails:type), packages/base/src/lib/utils/popups/popupStoreUtils.svelte.ts (createChangeEventDetails:runtime, BaseUIChangeEventDetails:type), packages/base/src/lib/utils/popups/useTriggerFocusGuards.svelte.ts (createChangeEventDetails:runtime, BaseUIChangeEventDetails:type).

## packages/base/src/lib/internals/getDisabledMountTransitionStyles.ts

SHA256 `7fb54d405a10ceeaa1ad3d5d630dc80a7b835eeb2fb92eb13daf47c1f668bd6c`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Complete starting-status branch and Source transition:none return shape.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Popup.svelte (getDisabledMountTransitionStyles:runtime), packages/base/src/lib/preview-card/Popup.svelte (getDisabledMountTransitionStyles:runtime), packages/base/src/lib/tooltip/Popup.svelte (getDisabledMountTransitionStyles:runtime), packages/base/src/lib/utils/usePositioner.svelte.ts (getDisabledMountTransitionStyles:runtime).

## packages/base/src/lib/internals/getStateAttributesProps.ts

SHA256 `e48367a890024a54cb200eabc5c2a0ba0a397256baacfaec8b0a05ced3b10344`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/stateAttributesMapping.ts (StateAttributesMapping:type), packages/base/src/lib/internals/useRenderElement.ts (getStateAttributesProps:runtime, StateAttributesMapping:type), packages/base/src/lib/utils/popupStateMapping.ts (StateAttributesMapping:type), packages/base/src/lib/utils/usePositioner.svelte.ts (StateAttributesMapping:type).

## packages/base/src/lib/internals/nativeProps.ts

SHA256 `d6b3999ffe54e8c70e0dcdac61474b3bf9f53e60f3b1207dd4f976ef5212e4eb`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/FloatingPortal.svelte (toNativeStyle:runtime), packages/base/src/lib/internals/RenderElement.svelte (toNativeStyle:runtime), packages/base/src/lib/internals/types.ts (NativeStyle:type), packages/base/src/lib/internals/useRenderElement.ts (mergeNativeStyles:runtime, toNativeClass:runtime), packages/base/src/lib/merge-props/mergeProps.ts (copyAttachmentSymbols:runtime, mergeNativeStyles:runtime, toNativeClass:runtime), packages/base/src/lib/popover/Viewport.svelte (toNativeStyle:runtime), packages/base/src/lib/preview-card/Viewport.svelte (toNativeStyle:runtime), packages/base/src/lib/tooltip/Viewport.svelte (toNativeStyle:runtime), packages/base/src/lib/utils/FocusGuard.svelte (toNativeStyle:runtime), packages/base/src/lib/utils/InternalBackdrop.svelte (toNativeStyle:runtime), packages/base/src/lib/utils/resolveStyle.ts (NativeStyle:type).

## packages/base/src/lib/internals/nativeRefAttachment.ts

SHA256 `564718b20326d9f5e18bf75d30b3905ce2f93a093fbdfbb7027928e1fd20e319`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/RenderElement.svelte (createRefAttachment:runtime), packages/base/src/lib/internals/useRenderElement.ts (isNativeRefAttachment:runtime), packages/base/src/lib/popover/Viewport.svelte (createRefAttachment:runtime), packages/base/src/lib/preview-card/Viewport.svelte (createRefAttachment:runtime), packages/base/src/lib/tooltip/Viewport.svelte (createRefAttachment:runtime), packages/base/src/lib/utils/FocusGuard.svelte (createRefAttachment:runtime), packages/base/src/lib/utils/InternalBackdrop.svelte (createRefAttachment:runtime).

## packages/base/src/lib/internals/reason-parts.ts

SHA256 `0326d21ce4be2c41b5488c86e3687249faf3c51f5e10ae49c16e8efdc183abf5`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/internals/reasons.ts (*:runtime).

## packages/base/src/lib/internals/reasons.ts

SHA256 `f1f52caeefb14448a7e7c9833e24413b923b7bbf40aa1818ca73dc93710b42e7`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (REASONS:runtime), packages/base/src/lib/floating-ui/components/FloatingPortal.svelte (REASONS:runtime), packages/base/src/lib/floating-ui/hooks/useClick.svelte.ts (REASONS:runtime), packages/base/src/lib/floating-ui/hooks/useDelayGroup.svelte.ts (REASONS:runtime), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (REASONS:runtime), packages/base/src/lib/floating-ui/hooks/useFocus.svelte.ts (REASONS:runtime), packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts (REASONS:runtime), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (REASONS:runtime), packages/base/src/lib/internals/createBaseUIEventDetails.ts (REASONS:runtime), packages/base/src/lib/popover/Backdrop.svelte (REASONS:runtime), packages/base/src/lib/popover/Close.svelte (REASONS:runtime), packages/base/src/lib/popover/Popup.svelte (REASONS:runtime), packages/base/src/lib/popover/Positioner.svelte (REASONS:runtime), packages/base/src/lib/popover/Root.svelte (REASONS:runtime), packages/base/src/lib/popover/store/PopoverStore.svelte.ts (REASONS:runtime), packages/base/src/lib/popover/Trigger.svelte (REASONS:runtime), packages/base/src/lib/preview-card/Root.svelte (REASONS:runtime), packages/base/src/lib/preview-card/store/PreviewCardStore.svelte.ts (REASONS:runtime), packages/base/src/lib/tooltip/Root.svelte (REASONS:runtime), packages/base/src/lib/tooltip/store/TooltipStore.svelte.ts (REASONS:runtime), packages/base/src/lib/tooltip/Trigger.svelte (REASONS:runtime), packages/base/src/lib/utils/popups/popupHandle.svelte.ts (REASONS:runtime), packages/base/src/lib/utils/popups/popupStoreUtils.svelte.ts (REASONS:runtime), packages/base/src/lib/utils/popups/useTriggerFocusGuards.svelte.ts (REASONS:runtime).

## packages/base/src/lib/internals/RenderElement.svelte

SHA256 `bbc7cb9be3a6d554f07090d250923b06b5581b29f190d48d874b62698f1cdef5`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/hooks/useFloatingPortalNode.svelte.ts (default:runtime), packages/base/src/lib/popover/Arrow.svelte (default:runtime), packages/base/src/lib/popover/Backdrop.svelte (default:runtime), packages/base/src/lib/popover/Close.svelte (default:runtime), packages/base/src/lib/popover/Description.svelte (default:runtime), packages/base/src/lib/popover/Popup.svelte (default:runtime), packages/base/src/lib/popover/Positioner.svelte (default:runtime), packages/base/src/lib/popover/Title.svelte (default:runtime), packages/base/src/lib/popover/Trigger.svelte (default:runtime), packages/base/src/lib/popover/Viewport.svelte (default:runtime), packages/base/src/lib/preview-card/Arrow.svelte (default:runtime), packages/base/src/lib/preview-card/Backdrop.svelte (default:runtime), packages/base/src/lib/preview-card/Popup.svelte (default:runtime), packages/base/src/lib/preview-card/Positioner.svelte (default:runtime), packages/base/src/lib/preview-card/Trigger.svelte (default:runtime), packages/base/src/lib/preview-card/Viewport.svelte (default:runtime), packages/base/src/lib/tooltip/Arrow.svelte (default:runtime), packages/base/src/lib/tooltip/Popup.svelte (default:runtime), packages/base/src/lib/tooltip/Positioner.svelte (default:runtime), packages/base/src/lib/tooltip/Trigger.svelte (default:runtime), packages/base/src/lib/tooltip/Viewport.svelte (default:runtime).

## packages/base/src/lib/internals/resolveClassValue.ts

SHA256 `584323b17cb1733a798e9ff86e9ff783d6a26d08ecf005a8c2b3c69917c1e722`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/internals/nativeProps.ts (resolveClassValue:runtime).

## packages/base/src/lib/internals/stateAttributesMapping.ts

SHA256 `d04c73fe454de256e1641245b5db6a3d70824693f0da33272d0863f033b5230d`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/utils/popupStateMapping.ts (transitionStatusMapping:runtime).

## packages/base/src/lib/internals/TransitionStatusDataAttributes.ts

SHA256 `d3e4a31041bcc80ba21b330d3fedadfadaeae3f498dc09e078e70470cfb98dfe`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/internals/stateAttributesMapping.ts (*:runtime), packages/base/src/lib/internals/useAnimationsFinished.ts (*:runtime), packages/base/src/lib/utils/CommonPopupDataAttributes.ts (*:runtime).

## packages/base/src/lib/internals/types.ts

SHA256 `56f62e49c3a1504981c523a1bee8764c45de90fb88f0fab5154bb7fc9d0c1bd3`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/FloatingPortal.svelte (BaseUIComponentProps:type, WithBaseUIEvent:type), packages/base/src/lib/floating-ui/hooks/useFloatingPortalNode.svelte.ts (HTMLProps:type), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (HTMLProps:type), packages/base/src/lib/floating-ui/types.ts (HTMLProps:type), packages/base/src/lib/internals/use-button/useButton.svelte.ts (BaseUIEvent:type, HTMLProps:type), packages/base/src/lib/internals/useRenderElement.ts (BaseUIComponentProps:type, ComponentRenderFn:type, HTMLProps:type), packages/base/src/lib/popover/types.ts (BaseUIComponentProps:type, WithBaseUIEvent:type), packages/base/src/lib/preview-card/types.ts (BaseUIComponentProps:type, WithBaseUIEvent:type), packages/base/src/lib/preview-card/types.ts (ComponentRenderFn:type, HTMLProps:type), packages/base/src/lib/separator/types.ts (BaseUIComponentProps:type, WithBaseUIEvent:type), packages/base/src/lib/toolbar/types.ts (BaseUIComponentProps:type, WithBaseUIEvent:type, ComponentRenderFn:type, HTMLProps:type), packages/base/src/lib/tooltip/types.ts (BaseUIComponentProps:type, WithBaseUIEvent:type), packages/base/src/lib/utils/FloatingPortalLite.svelte (BaseUIComponentProps:type, WithBaseUIEvent:type), packages/base/src/lib/utils/popups/store.ts (HTMLProps:type), packages/base/src/lib/utils/useFocusableWhenDisabled.ts (HTMLProps:type), packages/base/src/lib/utils/usePositioner.svelte.ts (HTMLProps:type).

## packages/base/src/lib/internals/use-button/useButton.svelte.ts

SHA256 `ee71d7077c51139162152716111472919bf80b71e6e9cde62d15ff0b7ce56f59`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Close.svelte (useButton:runtime), packages/base/src/lib/popover/Trigger.svelte (useButton:runtime).

## packages/base/src/lib/internals/useAnimationsFinished.ts

SHA256 `0ae8873174969326a7ac09377ab019af5cd575bbdfde7df9118317d0ec1c1e30`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/internals/useOpenChangeComplete.svelte.ts (useAnimationsFinished:runtime), packages/base/src/lib/popover/Positioner.svelte (useAnimationsFinished:runtime), packages/base/src/lib/utils/usePopupAutoResize.svelte.ts (useAnimationsFinished:runtime), packages/base/src/lib/utils/usePopupViewport.svelte.ts (useAnimationsFinished:runtime).

## packages/base/src/lib/internals/useBaseUiId.ts

SHA256 `fc6d9571f2fc0f71d6f75a8f34eb981a3e09a9a038fbb9aa8b4b83c2cbb3aaa3`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Description.svelte (useBaseUiId:runtime), packages/base/src/lib/popover/Title.svelte (useBaseUiId:runtime), packages/base/src/lib/popover/Trigger.svelte (useBaseUiId:runtime), packages/base/src/lib/preview-card/Trigger.svelte (useBaseUiId:runtime), packages/base/src/lib/tooltip/Trigger.svelte (useBaseUiId:runtime).

## packages/base/src/lib/internals/useOpenChangeComplete.svelte.ts

SHA256 `5e966dd1b10cbc1ed448d3583ca948a384d812f9e71afc1e128395485575931f`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Popup.svelte (useOpenChangeComplete:runtime), packages/base/src/lib/preview-card/Popup.svelte (useOpenChangeComplete:runtime), packages/base/src/lib/tooltip/Popup.svelte (useOpenChangeComplete:runtime), packages/base/src/lib/utils/popups/popupStoreUtils.svelte.ts (useOpenChangeComplete:runtime).

## packages/base/src/lib/internals/useRenderElement.ts

SHA256 `a8fb8a006629431ae42697dbbd9ea1177d9ce756bf953105c2e5f3eb5ed5a1e9`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/hooks/useFloatingPortalNode.svelte.ts (UseRenderElementComponentProps:type), packages/base/src/lib/internals/RenderElement.svelte (createRenderElement:runtime, UseRenderElementComponentProps:type, UseRenderElementParameters:type), packages/base/src/lib/utils/usePositioner.svelte.ts (UseRenderElementParameters:type).

## packages/base/src/lib/internals/useTransitionStatus.svelte.ts

SHA256 `1236abbbe5a5e1dec17c77d51d704f3f03e48ecdd34f85a995e1dde00c60c54b`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/FloatingRootStore.svelte.ts (TransitionStatus:type), packages/base/src/lib/internals/getDisabledMountTransitionStyles.ts (TransitionStatus:type), packages/base/src/lib/internals/stateAttributesMapping.ts (TransitionStatus:type), packages/base/src/lib/popover/types.ts (TransitionStatus:type), packages/base/src/lib/preview-card/types.ts (TransitionStatus:type), packages/base/src/lib/tooltip/types.ts (TransitionStatus:type), packages/base/src/lib/utils/popups/popupStoreUtils.svelte.ts (useTransitionStatus:runtime), packages/base/src/lib/utils/popups/store.ts (TransitionStatus:type), packages/base/src/lib/utils/popupStateMapping.ts (TransitionStatus:type), packages/base/src/lib/utils/usePositioner.svelte.ts (TransitionStatus:type).

## packages/base/src/lib/internals/useValueChanged.svelte.ts

SHA256 `340a8f5ed100094c283f167c8a8a3e196708cdf238eeadc93f148ee31c4274c9`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/utils/useOpenInteractionType.svelte.ts (useValueChanged:runtime).

## packages/base/src/lib/merge-props/index.ts

SHA256 `3ef38bba9b22f44bbcf69102d9556807f78897bedb69b410669c7b429971dd68`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/internals/types.ts (PreventableEvent:type), packages/base/src/lib/internals/use-button/useButton.svelte.ts (makeEventPreventable:runtime, mergeProps:runtime), packages/base/src/lib/internals/useRenderElement.ts (mergeProps:runtime, mergePropsN:runtime, mergeClassNames:runtime), packages/base/src/lib/tooltip/root/TooltipInteractions.svelte (mergeProps:runtime).

## packages/base/src/lib/merge-props/mergeProps.ts

SHA256 `7a097b833ae8854c5a26e34009adfb4e0297dd50f56ad5f0c1ac8afa8187f98b`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/merge-props/index.ts (*:runtime).

## packages/base/src/lib/popover/Arrow.svelte

SHA256 `fb9f9d4493f12be35d6779061e1aa6b21d2da23e81a4019cb1a8a1354d1c8d11`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Retain Source open/side/align/uncentered state maps and order of external/positioner arrow refs; render native div by canonical renderer. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Arrow registration belongs to the positioner ref and clears through attachment cleanup.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/arrow/PopoverArrow.tsx

Actual incoming consumers: packages/base/src/lib/popover/index.parts.ts (default:runtime).

## packages/base/src/lib/popover/Backdrop.svelte

SHA256 `1412553267405c19885afdf95d2d41d3410107d4a5752d3978644be704cb5282`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Retain Source transition mapping and pointer-events policy, canonical rendering and supplied native ref. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: No independent store/state or event lifecycle; delegates mount presence to Root/Portal and ref teardown to canonical renderer.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/backdrop/PopoverBackdrop.tsx

Actual incoming consumers: packages/base/src/lib/popover/index.parts.ts (default:runtime).

## packages/base/src/lib/popover/Close.svelte

SHA256 `c76941acda8819c7ddbf8e7276a9614a85f2b0cc26a9eed8ea32d9a5842ee940`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Compose actual useButton, useClosePartRegistration and Source close event detail/cancellation behavior; native click casing and HTML button defaults use canonical rendering. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: ClosePart registration cleanup unregisters one owned count; no duplicate close or button algorithm.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/close/PopoverClose.tsx

Actual incoming consumers: packages/base/src/lib/popover/index.parts.ts (default:runtime).

## packages/base/src/lib/popover/context.ts

SHA256 `1ad794ae8713b062cd6437548a0b37bef3e7ae68c21cc396adc8a381ac0f337a`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Translate required/optional Source Root and Portal context composition to typed native context functions with Source missing-provider errors and optional lookup. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Current store remains authority; portal keepMounted getter is the intended live provider value.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/root/PopoverRootContext.ts, packages/react/src/popover/portal/PopoverPortalContext.ts

Actual incoming consumers: packages/base/src/lib/popover/Arrow.svelte (usePopoverRootContext:runtime), packages/base/src/lib/popover/Backdrop.svelte (usePopoverRootContext:runtime), packages/base/src/lib/popover/Close.svelte (usePopoverRootContext:runtime), packages/base/src/lib/popover/Description.svelte (usePopoverRootContext:runtime), packages/base/src/lib/popover/Popup.svelte (usePopoverRootContext:runtime), packages/base/src/lib/popover/Portal.svelte (PORTAL:runtime, usePopoverRootContext:runtime), packages/base/src/lib/popover/Positioner.svelte (usePopoverRootContext:runtime, usePopoverPortalContext:runtime), packages/base/src/lib/popover/Root.svelte (ROOT:runtime, usePopoverRootContext:runtime), packages/base/src/lib/popover/Title.svelte (usePopoverRootContext:runtime), packages/base/src/lib/popover/Trigger.svelte (usePopoverRootContext:runtime), packages/base/src/lib/popover/Viewport.svelte (usePopoverRootContext:runtime).

## packages/base/src/lib/popover/Description.svelte

SHA256 `330b0388e9186e4ea24452008a99a58a7b70fb4d6f30e1b0e28d89c5c05e0233`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve Source generated-id publication to Popover store and canonical paragraph rendering with state/class/style refs. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Canonical Source useSyncedValueWithCleanup publishes the current descriptionElementId and clears it to undefined on cleanup; no additional overlap-identity policy is invented.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/description/PopoverDescription.tsx

Actual incoming consumers: packages/base/src/lib/popover/index.parts.ts (default:runtime).

## packages/base/src/lib/popover/handle.svelte.ts

SHA256 `364723acc45390c9f91947672d9e39ea83b7a04225bccc59217ea736176e2d43`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve the complete Source typed handle/factory API and anchored open(string), close/isOpen semantics over canonical BasePopupHandle. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Canonical attach/detach owner identity, detached trigger migration and inert fallback remain authoritative; no family-local registry or cloned store.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/store/PopoverHandle.ts

Actual incoming consumers: packages/base/src/lib/popover/index.parts.ts (PopoverHandle:runtime, createPopoverHandle:runtime).

## packages/base/src/lib/popover/index.parts.ts

SHA256 `b1ab6cebec3a51f5208e170b908b7ab7cc1c50059ebabeb875b4c651dc5c8c8c`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Read complete family namespace/barrel exports against original index.parts and Handle factories. All named actual parts, Props/State/Root namespaces and generic typed factories compose the separate family surface. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Part types are erased; no public anchor/createAnchor/Select or React boundary is introduced.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/index.parts.ts

Actual incoming consumers: none in this selected graph.

## packages/base/src/lib/popover/Popup.svelte

SHA256 `e3e7bb68b209421402cad03a0cf2227c09a3d8a18171ab7107fd21d968bfd8f6`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve Source popup state/transition maps, ref order, hover props and content behavior; Popover additionally composes canonical focus manager, ClosePart, label ids and toolbar keys. PreviewCard/Tooltip retain their lighter Source structure. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Popup ref/store publication is attachment-owned; canonical open completion captures close cycle and cancels observer/animation completion; no duplicated focus or transition controller.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/popup/PopoverPopup.tsx

Actual incoming consumers: packages/base/src/lib/popover/index.parts.ts (default:runtime).

## packages/base/src/lib/popover/Portal.svelte

SHA256 `d7fa637af3621b2118cdfe3c72fd9f4f83d69c4d753ffcef250324c23821bbdb`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Reuse exactly one canonical Full or Lite portal chosen by Source family; keepMounted and actual container/provider semantics remain. Native snippet mounting retains the captured context map. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Portal node/content ownership and null/defaultView realm behavior use the accepted exact helper; no family-created second portal-node lifecycle.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/portal/PopoverPortal.tsx

Actual incoming consumers: packages/base/src/lib/popover/index.parts.ts (default:runtime).

## packages/base/src/lib/popover/Positioner.svelte

SHA256 `f7f928ff3360c9cda92744e8cea20ec5a655b562e36a78dc2029519d6b634e2f`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Compose one canonical useAnchorPositioning and usePositioner with Source default offsets/collision/direction/arrow policy and family-specific backdrop/scroll/inline/cursor behavior. Native context/node setup replaces JSX providers. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Reference and positioner store fields are updated by attachment cleanup; canonical geometry cancels observer/tasks and context publication is identity-owned.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/positioner/PopoverPositioner.tsx

Actual incoming consumers: packages/base/src/lib/popover/index.parts.ts (default:runtime).

## packages/base/src/lib/popover/positioner/PopoverPositionerContext.ts

SHA256 `de7c427adf76adcb5178351f5c14cc11b5c486c06605c35c9772b3804f83b503`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Translate the actual Source positioner context contract to required typed native context getters/setters. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Positioner owns the context; children read the same positioning result and arrow refs.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/positioner/PopoverPositionerContext.ts

Actual incoming consumers: packages/base/src/lib/popover/Arrow.svelte (usePopoverPositionerContext:runtime), packages/base/src/lib/popover/Popup.svelte (usePopoverPositionerContext:runtime), packages/base/src/lib/popover/Positioner.svelte (providePopoverPositionerContext:runtime), packages/base/src/lib/popover/Viewport.svelte (usePopoverPositionerContext:runtime).

## packages/base/src/lib/popover/Root.svelte

SHA256 `9605e92f2aa58ccf5076f957983da4877d4aafbf6c6b447fcaa6b17cd4fd6130`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Own one Source store per native Root; synchronize controlled values, floating state, callbacks and transition actions through existing canonical helpers. Native setup/context/snippet composition replaces React provider/hook transport; Source family-specific dismissal/children/action behavior remains. Popover creates a floating tree only outside an existing Popover tree; patient-click timeout cleanup, modal dismissal and reset actions remain distinct.

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Handle attachment precedes interaction/user children; transition/interaction teardown targets the created store; no render-time store reassignment or separate popup authority.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. Popover creates a floating tree only outside an existing Popover tree; patient-click timeout cleanup, modal dismissal and reset actions remain distinct.

Complete Original owners: packages/react/src/popover/root/PopoverRoot.tsx

Actual incoming consumers: packages/base/src/lib/popover/index.parts.ts (default:runtime).

## packages/base/src/lib/popover/root/PopoverInteractions.svelte

SHA256 `df00246317da632a4c83b01aa18a1e6baae62e2397e68d3e267722000d1752ee`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Compose the Source family interaction prop bags through canonical useDismiss/useInteractions and store synchronization. Families remain separate; native store getters replace React hook values. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Interaction cleanup resets only this store prop bags; live getters drive current open/disabled/modal policy.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/root/PopoverRoot.tsx

Actual incoming consumers: packages/base/src/lib/popover/Root.svelte (default:runtime).

## packages/base/src/lib/popover/store/PopoverHandle.svelte.ts

SHA256 `8a3a1c93803ff557264199309062d242f183963f15cf2a1adb59ab877bcfe5f7`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve the complete Source typed handle/factory API and anchored open(string), close/isOpen semantics over canonical BasePopupHandle. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Canonical attach/detach owner identity, detached trigger migration and inert fallback remain authoritative; no family-local registry or cloned store.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/store/PopoverHandle.ts

Actual incoming consumers: packages/base/src/lib/popover/handle.svelte.ts (PopoverHandle:runtime, PopoverHandle:runtime, createPopoverHandle:runtime, createPopoverHandle:runtime), packages/base/src/lib/popover/types.ts (PopoverHandle:type).

## packages/base/src/lib/popover/store/PopoverStore.svelte.ts

SHA256 `5893b45b9120dbc282213f6c61781134e29bc3822c208f15f2680d575050c7fb`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Port complete Source Store state/context/selectors, null fallback and business setOpen/cancelPendingOpen bodies; compose canonical SvelteStore and popup helpers rather than a family lifecycle machine. Full patient-click500ms guard, reason/trigger/instant state and callback -> cancellation -> dispatch -> state commit ordering retained.

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Store-owned refs, registrations, callback order/cancellation/dispatch/state updates retain Source business; native flushSync is only renderer transport.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. Full patient-click500ms guard, reason/trigger/instant state and callback -> cancellation -> dispatch -> state commit ordering retained.

Complete Original owners: packages/react/src/popover/store/PopoverStore.ts

Actual incoming consumers: packages/base/src/lib/popover/context.ts (PopoverStore:type), packages/base/src/lib/popover/Root.svelte (PopoverStore:runtime, State:type), packages/base/src/lib/popover/root/PopoverInteractions.svelte (PopoverStore:type), packages/base/src/lib/popover/store/PopoverHandle.svelte.ts (PopoverStore:runtime, createNullPopoverStore:runtime, PopoverHandleStore:type), packages/base/src/lib/popover/Trigger.svelte (PopoverHandleStore:type).

## packages/base/src/lib/popover/Title.svelte

SHA256 `5e43c07f543ad2601b5cc0a1f095419ba4c56be74c061b86fcbc6ea587ae09c3`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve Source generated-id publication to Popover store and canonical h2 rendering with state/class/style refs. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Canonical Source useSyncedValueWithCleanup publishes the current titleElementId and clears it to undefined on cleanup; no additional overlap-identity policy is invented.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/title/PopoverTitle.tsx

Actual incoming consumers: packages/base/src/lib/popover/index.parts.ts (default:runtime).

## packages/base/src/lib/popover/Trigger.svelte

SHA256 `f53f01856584df96dcd251007547451099b8719073dfa14e315346097c309cfd`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve Source trigger registration, payload forwarding, active/inactive prop selection and ref/event order; native element/synthetic-event differences stay in canonical render/button adapters. Patient-click ownership/focus guards remain Source; only family caller of canonical useClick is this component (line47). That known dependency blocks closure acceptance.

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Register and migrate by current store/id/element ownership; timeouts/frames are canonical cleanup-owned resources. Current useClick is evaluated separately, not blessed by this caller body.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. Patient-click ownership/focus guards remain Source; only family caller of canonical useClick is this component (line47). That known dependency blocks closure acceptance.

Complete Original owners: packages/react/src/popover/trigger/PopoverTrigger.tsx

Actual incoming consumers: packages/base/src/lib/popover/index.parts.ts (default:runtime).

## packages/base/src/lib/popover/types.ts

SHA256 `a0e46944870708c6ae9b26f8ebdf1a9d094b999edb6e7aaf327275cd670827b1`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Read all complete public Props/State/action/event/payload/render type bodies against their complete Source declaration owners. Native Snippet/Element/ref/render attributes replace React types without changing business unions/default contracts. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: No runtime allocation. PreviewCard HTML anchor href admits the native null boundary; generic Handle payload and erased namespaces remain typed.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/arrow/PopoverArrow.tsx, packages/react/src/popover/arrow/PopoverArrowDataAttributes.ts, packages/react/src/popover/backdrop/PopoverBackdrop.tsx, packages/react/src/popover/backdrop/PopoverBackdropDataAttributes.ts, packages/react/src/popover/close/PopoverClose.tsx, packages/react/src/popover/description/PopoverDescription.tsx, packages/react/src/popover/index.parts.ts, packages/react/src/popover/index.ts, packages/react/src/popover/popup/PopoverPopup.tsx, packages/react/src/popover/popup/PopoverPopupCssVars.ts, packages/react/src/popover/popup/PopoverPopupDataAttributes.ts, packages/react/src/popover/portal/PopoverPortal.tsx, packages/react/src/popover/portal/PopoverPortalContext.ts, packages/react/src/popover/positioner/PopoverPositioner.tsx, packages/react/src/popover/positioner/PopoverPositionerContext.ts, packages/react/src/popover/positioner/PopoverPositionerCssVars.ts, packages/react/src/popover/positioner/PopoverPositionerDataAttributes.ts, packages/react/src/popover/root/PopoverRoot.tsx, packages/react/src/popover/root/PopoverRootContext.ts, packages/react/src/popover/store/PopoverHandle.ts, packages/react/src/popover/store/PopoverStore.ts, packages/react/src/popover/title/PopoverTitle.tsx, packages/react/src/popover/trigger/PopoverTrigger.tsx, packages/react/src/popover/trigger/PopoverTriggerDataAttributes.ts, packages/react/src/popover/utils/constants.ts, packages/react/src/popover/viewport/PopoverViewport.tsx, packages/react/src/popover/viewport/PopoverViewportCssVars.ts, packages/react/src/popover/viewport/PopoverViewportDataAttributes.ts

Actual incoming consumers: packages/base/src/lib/popover/Arrow.svelte (PopoverArrowProps:type), packages/base/src/lib/popover/Backdrop.svelte (PopoverBackdropProps:type), packages/base/src/lib/popover/Close.svelte (PopoverCloseProps:type), packages/base/src/lib/popover/Description.svelte (PopoverDescriptionProps:type), packages/base/src/lib/popover/index.parts.ts (PopoverRootProps:type, PopoverRootState:type, PopoverTriggerProps:type, PopoverTriggerState:type, PopoverPortalProps:type, PopoverPortalState:type, PopoverPositionerProps:type, PopoverPositionerState:type, PopoverPopupProps:type, PopoverPopupState:type, PopoverArrowProps:type, PopoverArrowState:type, PopoverBackdropProps:type, PopoverBackdropState:type, PopoverTitleProps:type, PopoverTitleState:type, PopoverDescriptionProps:type, PopoverDescriptionState:type, PopoverCloseProps:type, PopoverCloseState:type, PopoverViewportProps:type, PopoverViewportState:type, PopoverRootActions:type, PopoverRootChangeEventReason:type, PopoverRootChangeEventDetails:type), packages/base/src/lib/popover/Popup.svelte (PopoverPopupProps:type, PopoverPopupState:type), packages/base/src/lib/popover/Portal.svelte (PopoverPortalProps:type), packages/base/src/lib/popover/Positioner.svelte (PopoverPositionerProps:type, PopoverPositionerState:type), packages/base/src/lib/popover/Root.svelte (PopoverRootProps:type, PopoverRootChangeEventDetails:type), packages/base/src/lib/popover/store/PopoverStore.svelte.ts (PopoverRootChangeEventDetails:type, PopoverRootChangeEventReason:type), packages/base/src/lib/popover/Title.svelte (PopoverTitleProps:type), packages/base/src/lib/popover/Trigger.svelte (PopoverTriggerProps:type), packages/base/src/lib/popover/Viewport.svelte (PopoverViewportProps:type, PopoverViewportState:type).

## packages/base/src/lib/popover/utils/constants.ts

SHA256 `69a03145627953aab05636e24bfbe7b3e27a772314debe3038d5f634c052f90d`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve the Source family complete default scalar constants with native getter callers. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: No allocation/lifetime; default delay/tolerance values are not shared across families arbitrarily.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/utils/constants.ts

Actual incoming consumers: packages/base/src/lib/popover/Trigger.svelte (OPEN_DELAY:runtime).

## packages/base/src/lib/popover/Viewport.svelte

SHA256 `1125d2edb88bc84ff6a3d8bc06e65dc7864812950cb927494e1dd01940a6840b`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Delegate all content-change capture/morph/content-key business to the single canonical usePopupViewport. Native attachments and keyed snippet markup provide current/previous DOM containers. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Temporary transition content and style/size work remain owned by canonical viewport/resize helpers; current previous elements are detached on lifetime cleanup.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/popover/viewport/PopoverViewport.tsx

Actual incoming consumers: packages/base/src/lib/popover/index.parts.ts (default:runtime).

## packages/base/src/lib/preview-card/Arrow.svelte

SHA256 `efb4e56c39da4625ac5603fb06cb18f745abfd88c51608e8d41731ff08e07e23`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Retain Source open/side/align/uncentered state maps and order of external/positioner arrow refs; render native div by canonical renderer. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Arrow registration belongs to the positioner ref and clears through attachment cleanup.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/preview-card/arrow/PreviewCardArrow.tsx

Actual incoming consumers: packages/base/src/lib/preview-card/index.parts.ts (default:runtime).

## packages/base/src/lib/preview-card/Backdrop.svelte

SHA256 `3eef5e82926985a8d8d4d39c972007a4499f0b19dbb14dabcd21ef5b98a885e8`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Retain Source transition mapping and pointer-events policy, canonical rendering and supplied native ref. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: No independent store/state or event lifecycle; delegates mount presence to Root/Portal and ref teardown to canonical renderer.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/preview-card/backdrop/PreviewCardBackdrop.tsx

Actual incoming consumers: packages/base/src/lib/preview-card/index.parts.ts (default:runtime).

## packages/base/src/lib/preview-card/context.ts

SHA256 `932dc38f805f22f1b0a4f830fc7ec9f2a233b67451a332c1d9173c129af59d28`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Translate required/optional Source Root and Portal context composition to typed native context functions with Source missing-provider errors and optional lookup. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Current store remains authority; portal keepMounted getter is the intended live provider value.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/preview-card/root/PreviewCardContext.ts, packages/react/src/preview-card/portal/PreviewCardPortalContext.ts

Actual incoming consumers: packages/base/src/lib/preview-card/Arrow.svelte (usePreviewCardRootContext:runtime), packages/base/src/lib/preview-card/Backdrop.svelte (usePreviewCardRootContext:runtime), packages/base/src/lib/preview-card/Popup.svelte (usePreviewCardRootContext:runtime), packages/base/src/lib/preview-card/Portal.svelte (PORTAL:runtime, usePreviewCardRootContext:runtime), packages/base/src/lib/preview-card/Positioner.svelte (usePreviewCardRootContext:runtime, usePreviewCardPortalContext:runtime), packages/base/src/lib/preview-card/Root.svelte (ROOT:runtime, usePreviewCardRootContext:runtime), packages/base/src/lib/preview-card/Trigger.svelte (usePreviewCardRootContext:runtime), packages/base/src/lib/preview-card/Viewport.svelte (usePreviewCardRootContext:runtime).

## packages/base/src/lib/preview-card/handle.svelte.ts

SHA256 `fbc4aa31048a26d66c98e3b08fe935565a00d58b2bbd919050587d63f9bcd11e`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve the complete Source typed handle/factory API and anchored open(string), close/isOpen semantics over canonical BasePopupHandle. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Canonical attach/detach owner identity, detached trigger migration and inert fallback remain authoritative; no family-local registry or cloned store.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/preview-card/store/PreviewCardHandle.ts

Actual incoming consumers: packages/base/src/lib/preview-card/index.parts.ts (PreviewCardHandle:runtime, createPreviewCardHandle:runtime).

## packages/base/src/lib/preview-card/index.parts.ts

SHA256 `3053724c3fadccd959d44d93d8c02cfb17b19f54eb9ef8d2921509b4dff16241`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Read complete family namespace/barrel exports against original index.parts and Handle factories. All named actual parts, Props/State/Root namespaces and generic typed factories compose the separate family surface. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Part types are erased; no public anchor/createAnchor/Select or React boundary is introduced.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/preview-card/index.parts.ts

Actual incoming consumers: none in this selected graph.

## packages/base/src/lib/preview-card/Popup.svelte

SHA256 `5e6e0779c7d667edd217b6f0bd0a4196c60c93bd99ff015ae67e8496e32062c6`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve Source popup state/transition maps, ref order, hover props and content behavior; Popover additionally composes canonical focus manager, ClosePart, label ids and toolbar keys. PreviewCard/Tooltip retain their lighter Source structure. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Popup ref/store publication is attachment-owned; canonical open completion captures close cycle and cancels observer/animation completion; no duplicated focus or transition controller.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/preview-card/popup/PreviewCardPopup.tsx

Actual incoming consumers: packages/base/src/lib/preview-card/index.parts.ts (default:runtime).

## packages/base/src/lib/preview-card/Portal.svelte

SHA256 `f2f210e094fce2699dad636ac421ec56fa4ce5c5e051ad8de239696a787a0a8a`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Reuse exactly one canonical Full or Lite portal chosen by Source family; keepMounted and actual container/provider semantics remain. Native snippet mounting retains the captured context map. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Portal node/content ownership and null/defaultView realm behavior use the accepted exact helper; no family-created second portal-node lifecycle.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/preview-card/portal/PreviewCardPortal.tsx

Actual incoming consumers: packages/base/src/lib/preview-card/index.parts.ts (default:runtime).

## packages/base/src/lib/preview-card/Positioner.svelte

SHA256 `5de5491630bf8d2facf2d974ad04f69df192856d49722889658e9badbf492524`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Compose one canonical useAnchorPositioning and usePositioner with Source default offsets/collision/direction/arrow policy and family-specific backdrop/scroll/inline/cursor behavior. Native context/node setup replaces JSX providers. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Reference and positioner store fields are updated by attachment cleanup; canonical geometry cancels observer/tasks and context publication is identity-owned.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/preview-card/positioner/PreviewCardPositioner.tsx

Actual incoming consumers: packages/base/src/lib/preview-card/index.parts.ts (default:runtime).

## packages/base/src/lib/preview-card/positioner/PreviewCardPositionerContext.ts

SHA256 `a1b0389697380077fc36be07f197f8119c6bf09ae41099e236292f245763edd3`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Translate the actual Source positioner context contract to required typed native context getters/setters. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Positioner owns the context; children read the same positioning result and arrow refs.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/preview-card/positioner/PreviewCardPositionerContext.ts

Actual incoming consumers: packages/base/src/lib/preview-card/Arrow.svelte (usePreviewCardPositionerContext:runtime), packages/base/src/lib/preview-card/Popup.svelte (usePreviewCardPositionerContext:runtime), packages/base/src/lib/preview-card/Positioner.svelte (providePreviewCardPositionerContext:runtime), packages/base/src/lib/preview-card/Viewport.svelte (usePreviewCardPositionerContext:runtime).

## packages/base/src/lib/preview-card/Root.svelte

SHA256 `22e297499a4001f720ce577e7fedf0b5a55d760e25d6c389a3c1133b02b1fd05`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Own one Source store per native Root; synchronize controlled values, floating state, callbacks and transition actions through existing canonical helpers. Native setup/context/snippet composition replaces React provider/hook transport; Source family-specific dismissal/children/action behavior remains. PreviewCard retains closeOnActiveTriggerUnmount and unmount inline/unassociated-payload cleanup; parent PreviewCard tree composition remains Source.

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Handle attachment precedes interaction/user children; transition/interaction teardown targets the created store; no render-time store reassignment or separate popup authority.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. PreviewCard retains closeOnActiveTriggerUnmount and unmount inline/unassociated-payload cleanup; parent PreviewCard tree composition remains Source.

Complete Original owners: packages/react/src/preview-card/root/PreviewCardRoot.tsx

Actual incoming consumers: packages/base/src/lib/preview-card/index.parts.ts (default:runtime).

## packages/base/src/lib/preview-card/root/PreviewCardInteractions.svelte

SHA256 `341c48b849c27d5da6a76dbcd9380f7cd4a6f23d708e05c79d07aa6df395c278`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Compose the Source family interaction prop bags through canonical useDismiss/useInteractions and store synchronization. Families remain separate; native store getters replace React hook values. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Interaction cleanup resets only this store prop bags; live getters drive current open/disabled/modal policy.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/preview-card/root/PreviewCardRoot.tsx

Actual incoming consumers: packages/base/src/lib/preview-card/Root.svelte (default:runtime).

## packages/base/src/lib/preview-card/store/PreviewCardHandle.svelte.ts

SHA256 `6ef3415bc8dbbc682d4de9d1d4034499e37e962e8fb4248e0e2c41b56b4cffe8`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve the complete Source typed handle/factory API and anchored open(string), close/isOpen semantics over canonical BasePopupHandle. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Canonical attach/detach owner identity, detached trigger migration and inert fallback remain authoritative; no family-local registry or cloned store.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/preview-card/store/PreviewCardHandle.ts

Actual incoming consumers: packages/base/src/lib/preview-card/handle.svelte.ts (PreviewCardHandle:runtime, PreviewCardHandle:runtime, createPreviewCardHandle:runtime, createPreviewCardHandle:runtime), packages/base/src/lib/preview-card/types.ts (PreviewCardHandle:type).

## packages/base/src/lib/preview-card/store/PreviewCardStore.svelte.ts

SHA256 `aa3c78ab836e5ff87e5d0f3d6d56da8712504fe3cebdc67b9fc871697c0811d8`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Port complete Source Store state/context/selectors, null fallback and business setOpen/cancelPendingOpen bodies; compose canonical SvelteStore and popup helpers rather than a family lifecycle machine. Canonical applyPopupOpenChange uses actual inlineRect onBeforeDispatch; no private geometry/opening algorithm.

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Store-owned refs, registrations, callback order/cancellation/dispatch/state updates retain Source business; native flushSync is only renderer transport.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. Canonical applyPopupOpenChange uses actual inlineRect onBeforeDispatch; no private geometry/opening algorithm.

Complete Original owners: packages/react/src/preview-card/store/PreviewCardStore.ts

Actual incoming consumers: packages/base/src/lib/preview-card/context.ts (PreviewCardStore:type), packages/base/src/lib/preview-card/Root.svelte (PreviewCardStore:runtime, State:type), packages/base/src/lib/preview-card/root/PreviewCardInteractions.svelte (PreviewCardStore:type), packages/base/src/lib/preview-card/store/PreviewCardHandle.svelte.ts (PreviewCardStore:runtime, createNullPreviewCardStore:runtime, PreviewCardHandleStore:type), packages/base/src/lib/preview-card/Trigger.svelte (PreviewCardHandleStore:type).

## packages/base/src/lib/preview-card/Trigger.svelte

SHA256 `660084d904d9006b9a12caae524b9c0170f67f2a0062dcf3205d8af9d3f21794`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve Source trigger registration, payload forwarding, active/inactive prop selection and ref/event order; native element/synthetic-event differences stay in canonical render/button adapters. Actual native anchor default, inline focus/mouse coordinates, separate hover/focus hooks and forwarded payload remain Source.

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Register and migrate by current store/id/element ownership; timeouts/frames are canonical cleanup-owned resources. Current useClick is evaluated separately, not blessed by this caller body.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. Actual native anchor default, inline focus/mouse coordinates, separate hover/focus hooks and forwarded payload remain Source.

Complete Original owners: packages/react/src/preview-card/trigger/PreviewCardTrigger.tsx

Actual incoming consumers: packages/base/src/lib/preview-card/index.parts.ts (default:runtime).

## packages/base/src/lib/preview-card/types.ts

SHA256 `5e6509c872f45c9915a1cec66d60f95e05107a16364025a11f57fe9269547435`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Read all complete public Props/State/action/event/payload/render type bodies against their complete Source declaration owners. Native Snippet/Element/ref/render attributes replace React types without changing business unions/default contracts. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: No runtime allocation. PreviewCard HTML anchor href admits the native null boundary; generic Handle payload and erased namespaces remain typed.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/preview-card/arrow/PreviewCardArrow.tsx, packages/react/src/preview-card/arrow/PreviewCardArrowDataAttributes.ts, packages/react/src/preview-card/backdrop/PreviewCardBackdrop.tsx, packages/react/src/preview-card/backdrop/PreviewCardBackdropDataAttributes.ts, packages/react/src/preview-card/index.parts.ts, packages/react/src/preview-card/index.ts, packages/react/src/preview-card/popup/PreviewCardPopup.tsx, packages/react/src/preview-card/popup/PreviewCardPopupDataAttributes.ts, packages/react/src/preview-card/portal/PreviewCardPortal.tsx, packages/react/src/preview-card/portal/PreviewCardPortalContext.ts, packages/react/src/preview-card/positioner/PreviewCardPositioner.tsx, packages/react/src/preview-card/positioner/PreviewCardPositionerContext.ts, packages/react/src/preview-card/positioner/PreviewCardPositionerCssVars.ts, packages/react/src/preview-card/positioner/PreviewCardPositionerDataAttributes.ts, packages/react/src/preview-card/root/PreviewCardContext.ts, packages/react/src/preview-card/root/PreviewCardRoot.tsx, packages/react/src/preview-card/store/PreviewCardHandle.ts, packages/react/src/preview-card/store/PreviewCardStore.ts, packages/react/src/preview-card/trigger/PreviewCardTrigger.tsx, packages/react/src/preview-card/trigger/PreviewCardTriggerDataAttributes.ts, packages/react/src/preview-card/utils/constants.ts, packages/react/src/preview-card/viewport/PreviewCardViewport.tsx, packages/react/src/preview-card/viewport/PreviewCardViewportCssVars.ts, packages/react/src/preview-card/viewport/PreviewCardViewportDataAttributes.ts

Actual incoming consumers: packages/base/src/lib/preview-card/Arrow.svelte (PreviewCardArrowProps:type), packages/base/src/lib/preview-card/Backdrop.svelte (PreviewCardBackdropProps:type), packages/base/src/lib/preview-card/index.parts.ts (PreviewCardRootProps:type, PreviewCardRootState:type, PreviewCardTriggerProps:type, PreviewCardTriggerState:type, PreviewCardPortalProps:type, PreviewCardPortalState:type, PreviewCardPositionerProps:type, PreviewCardPositionerState:type, PreviewCardPopupProps:type, PreviewCardPopupState:type, PreviewCardArrowProps:type, PreviewCardArrowState:type, PreviewCardBackdropProps:type, PreviewCardBackdropState:type, PreviewCardViewportProps:type, PreviewCardViewportState:type, PreviewCardRootActions:type, PreviewCardRootChangeEventReason:type, PreviewCardRootChangeEventDetails:type), packages/base/src/lib/preview-card/Popup.svelte (PreviewCardPopupProps:type, PreviewCardPopupState:type), packages/base/src/lib/preview-card/Portal.svelte (PreviewCardPortalProps:type), packages/base/src/lib/preview-card/Positioner.svelte (PreviewCardPositionerProps:type, PreviewCardPositionerState:type), packages/base/src/lib/preview-card/Root.svelte (PreviewCardRootProps:type, PreviewCardRootChangeEventDetails:type), packages/base/src/lib/preview-card/store/PreviewCardStore.svelte.ts (PreviewCardRootChangeEventDetails:type), packages/base/src/lib/preview-card/Trigger.svelte (PreviewCardTriggerProps:type), packages/base/src/lib/preview-card/Viewport.svelte (PreviewCardViewportProps:type, PreviewCardViewportState:type).

## packages/base/src/lib/preview-card/utils/constants.ts

SHA256 `9d0cc589117e266bd607f809a6e70a1784cb73cf5402cddb9a7ea4684fa65438`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve the Source family complete default scalar constants with native getter callers. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: No allocation/lifetime; default delay/tolerance values are not shared across families arbitrarily.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/preview-card/utils/constants.ts

Actual incoming consumers: packages/base/src/lib/preview-card/store/PreviewCardStore.svelte.ts (CLOSE_DELAY:runtime), packages/base/src/lib/preview-card/Trigger.svelte (OPEN_DELAY:runtime, CLOSE_DELAY:runtime).

## packages/base/src/lib/preview-card/Viewport.svelte

SHA256 `6e50db1c9ce42783479361db3a87b26192026df9a240d851c100984d0bcc502b`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Delegate all content-change capture/morph/content-key business to the single canonical usePopupViewport. Native attachments and keyed snippet markup provide current/previous DOM containers. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Temporary transition content and style/size work remain owned by canonical viewport/resize helpers; current previous elements are detached on lifetime cleanup.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/preview-card/viewport/PreviewCardViewport.tsx

Actual incoming consumers: packages/base/src/lib/preview-card/index.parts.ts (default:runtime).

## packages/base/src/lib/separator/types.ts

SHA256 `b349b520840d7d7b3bbda5127105404312370ae300efe23bb354536c2d8c56dc`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/toolbar/types.ts (SeparatorProps:type, SeparatorState:type).

## packages/base/src/lib/toolbar/root/ToolbarRootContext.ts

SHA256 `ac7081f4de2f79dcdf425ee5ca7690db2d577f9363f2ef03b75f3b5395adc6cb`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Popup.svelte (useToolbarRootContext:runtime).

## packages/base/src/lib/toolbar/types.ts

SHA256 `c7cc1b91797831826e2605d119313666bce3f67185583beff516a80af9104e78`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/toolbar/root/ToolbarRootContext.ts (ToolbarRootOrientation:type).

## packages/base/src/lib/tooltip/Arrow.svelte

SHA256 `961e8214407cd4b74fc0a32b72da7c765463299b80082a41d5b522c77e793f4b`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Retain Source open/side/align/uncentered state maps and order of external/positioner arrow refs; render native div by canonical renderer. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Arrow registration belongs to the positioner ref and clears through attachment cleanup.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/tooltip/arrow/TooltipArrow.tsx

Actual incoming consumers: packages/base/src/lib/tooltip/index.parts.ts (default:runtime).

## packages/base/src/lib/tooltip/context.ts

SHA256 `c642d892b21d918bfb5c3322ec8d7496fad3ed1e9cff2d864744594219ddb297`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Translate required/optional Source Root and Portal context composition to typed native context functions with Source missing-provider errors and optional lookup. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Current store remains authority; portal keepMounted getter is the intended live provider value.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/tooltip/root/TooltipRootContext.ts, packages/react/src/tooltip/portal/TooltipPortalContext.ts

Actual incoming consumers: packages/base/src/lib/tooltip/Arrow.svelte (useTooltipRootContext:runtime), packages/base/src/lib/tooltip/Popup.svelte (useTooltipRootContext:runtime), packages/base/src/lib/tooltip/Portal.svelte (PORTAL:runtime, useTooltipRootContext:runtime), packages/base/src/lib/tooltip/Positioner.svelte (useTooltipRootContext:runtime, useTooltipPortalContext:runtime), packages/base/src/lib/tooltip/Root.svelte (ROOT:runtime), packages/base/src/lib/tooltip/Trigger.svelte (useTooltipRootContext:runtime), packages/base/src/lib/tooltip/Viewport.svelte (useTooltipRootContext:runtime).

## packages/base/src/lib/tooltip/handle.svelte.ts

SHA256 `4c2eb76636093c7bda40d1a20156ed8023aebb9958b37db1b68aa361de221418`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve the complete Source typed handle/factory API and anchored open(string), close/isOpen semantics over canonical BasePopupHandle. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Canonical attach/detach owner identity, detached trigger migration and inert fallback remain authoritative; no family-local registry or cloned store.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/tooltip/store/TooltipHandle.ts

Actual incoming consumers: packages/base/src/lib/tooltip/index.parts.ts (TooltipHandle:runtime, createTooltipHandle:runtime).

## packages/base/src/lib/tooltip/index.parts.ts

SHA256 `936cf205b53ef9394afc3fdeb94a50c3229a87a23a8eccb8fa9febbc0960f559`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Read complete family namespace/barrel exports against original index.parts and Handle factories. All named actual parts, Props/State/Root namespaces and generic typed factories compose the separate family surface. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Part types are erased; no public anchor/createAnchor/Select or React boundary is introduced.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/tooltip/index.parts.ts

Actual incoming consumers: none in this selected graph.

## packages/base/src/lib/tooltip/Popup.svelte

SHA256 `e1d77b9e5b0bd3cc51aa144f0cb00bfedb83ad152d06bfbf86d13e0f82bf640a`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve Source popup state/transition maps, ref order, hover props and content behavior; Popover additionally composes canonical focus manager, ClosePart, label ids and toolbar keys. PreviewCard/Tooltip retain their lighter Source structure. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Popup ref/store publication is attachment-owned; canonical open completion captures close cycle and cancels observer/animation completion; no duplicated focus or transition controller.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/tooltip/popup/TooltipPopup.tsx

Actual incoming consumers: packages/base/src/lib/tooltip/index.parts.ts (default:runtime).

## packages/base/src/lib/tooltip/Portal.svelte

SHA256 `e78111981a772562a1c181f733b601e43e94c9fd24283a6949feb97c0c17c5c3`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Reuse exactly one canonical Full or Lite portal chosen by Source family; keepMounted and actual container/provider semantics remain. Native snippet mounting retains the captured context map. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Portal node/content ownership and null/defaultView realm behavior use the accepted exact helper; no family-created second portal-node lifecycle.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/tooltip/portal/TooltipPortal.tsx

Actual incoming consumers: packages/base/src/lib/tooltip/index.parts.ts (default:runtime).

## packages/base/src/lib/tooltip/Positioner.svelte

SHA256 `390832a18620e038ac10d877be19f1f741deaf71f11434a57f91e2a20e603657`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Compose one canonical useAnchorPositioning and usePositioner with Source default offsets/collision/direction/arrow policy and family-specific backdrop/scroll/inline/cursor behavior. Native context/node setup replaces JSX providers. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Reference and positioner store fields are updated by attachment cleanup; canonical geometry cancels observer/tasks and context publication is identity-owned.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/tooltip/positioner/TooltipPositioner.tsx

Actual incoming consumers: packages/base/src/lib/tooltip/index.parts.ts (default:runtime).

## packages/base/src/lib/tooltip/positioner/TooltipPositionerContext.ts

SHA256 `5f9a2af9abeafe222dac49ad246730519d4464f218078f1339e84d6fd60e747b`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Translate the actual Source positioner context contract to required typed native context getters/setters. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Positioner owns the context; children read the same positioning result and arrow refs.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/tooltip/positioner/TooltipPositionerContext.ts

Actual incoming consumers: packages/base/src/lib/tooltip/Arrow.svelte (useTooltipPositionerContext:runtime), packages/base/src/lib/tooltip/Popup.svelte (useTooltipPositionerContext:runtime), packages/base/src/lib/tooltip/Positioner.svelte (provideTooltipPositionerContext:runtime), packages/base/src/lib/tooltip/Viewport.svelte (useTooltipPositionerContext:runtime).

## packages/base/src/lib/tooltip/Provider.svelte

SHA256 `f12f449463cbc1b0ddfee26f607bfbfdad1744a4acf7f2af086a080d2091bba4`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Keep Tooltip public delay/closeDelay/timeout context distinct from canonical FloatingDelayGroup. Public timeout default400 and group timeout0 are not conflated. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Typed native live provider getter plus canonical group lifetime; no global singleton or retained orphan timer.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/tooltip/provider/TooltipProvider.tsx

Actual incoming consumers: packages/base/src/lib/tooltip/index.parts.ts (default:runtime).

## packages/base/src/lib/tooltip/provider/TooltipProviderContext.ts

SHA256 `f8e3d2ff7f7ed85e1936013b653f56aa1e145b1e062204580550a35cc0be1db1`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve actual TooltipProvider delay/closeDelay numeric context using native getContext and live getter value. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Context belongs to the nearest native provider lifetime; independent from FloatingDelayGroup context.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/tooltip/provider/TooltipProviderContext.ts

Actual incoming consumers: packages/base/src/lib/tooltip/Provider.svelte (PROVIDER:runtime, TooltipProviderContext:type), packages/base/src/lib/tooltip/Trigger.svelte (useTooltipProviderContext:runtime).

## packages/base/src/lib/tooltip/Root.svelte

SHA256 `4e822ff9b34bc6f25f61bba4da669ed25cbc41d9cd512184d3390665953bf2eb`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Own one Source store per native Root; synchronize controlled values, floating state, callbacks and transition actions through existing canonical helpers. Native setup/context/snippet composition replaces React provider/hook transport; Source family-specific dismissal/children/action behavior remains. Tooltip has no invented tree wrapper; disabled/open filtering, cursor/hoverable sync, instant capture/restore and ClientPoint/dismiss composition remain Source.

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Handle attachment precedes interaction/user children; transition/interaction teardown targets the created store; no render-time store reassignment or separate popup authority.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. Tooltip has no invented tree wrapper; disabled/open filtering, cursor/hoverable sync, instant capture/restore and ClientPoint/dismiss composition remain Source.

Complete Original owners: packages/react/src/tooltip/root/TooltipRoot.tsx

Actual incoming consumers: packages/base/src/lib/tooltip/index.parts.ts (default:runtime).

## packages/base/src/lib/tooltip/root/TooltipInteractions.svelte

SHA256 `0a33edb0edd9d3c97846159ec46482b9ba05df50a5adaaa2d903f9afebf74f17`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Compose the Source family interaction prop bags through canonical useDismiss/useInteractions and store synchronization. Families remain separate; native store getters replace React hook values. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Interaction cleanup resets only this store prop bags; live getters drive current open/disabled/modal policy.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/tooltip/root/TooltipRoot.tsx

Actual incoming consumers: packages/base/src/lib/tooltip/Root.svelte (default:runtime).

## packages/base/src/lib/tooltip/store/TooltipHandle.svelte.ts

SHA256 `79d3d7aef5796a0d4705c31bedab98c7c67685b1fe97f65c681f50b35d6d3687`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve the complete Source typed handle/factory API and anchored open(string), close/isOpen semantics over canonical BasePopupHandle. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Canonical attach/detach owner identity, detached trigger migration and inert fallback remain authoritative; no family-local registry or cloned store.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/tooltip/store/TooltipHandle.ts

Actual incoming consumers: packages/base/src/lib/tooltip/handle.svelte.ts (TooltipHandle:runtime, TooltipHandle:runtime, createTooltipHandle:runtime, createTooltipHandle:runtime), packages/base/src/lib/tooltip/types.ts (TooltipHandle:type).

## packages/base/src/lib/tooltip/store/TooltipStore.svelte.ts

SHA256 `ac92eb68e9eed9d321322c3decca2789c03cdc16fc8d57d5cb499f7a1260b2f8`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Port complete Source Store state/context/selectors, null fallback and business setOpen/cancelPendingOpen bodies; compose canonical SvelteStore and popup helpers rather than a family lifecycle machine. Canonical applyPopupOpenChange uses Source extraState; cancelPendingOpen dispatches the floating cancellation event without committing a fabricated open state.

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Store-owned refs, registrations, callback order/cancellation/dispatch/state updates retain Source business; native flushSync is only renderer transport.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. Canonical applyPopupOpenChange uses Source extraState; cancelPendingOpen dispatches the floating cancellation event without committing a fabricated open state.

Complete Original owners: packages/react/src/tooltip/store/TooltipStore.ts

Actual incoming consumers: packages/base/src/lib/tooltip/context.ts (TooltipStore:type), packages/base/src/lib/tooltip/Root.svelte (TooltipStore:runtime, State:type), packages/base/src/lib/tooltip/root/TooltipInteractions.svelte (TooltipStore:type), packages/base/src/lib/tooltip/store/TooltipHandle.svelte.ts (TooltipStore:runtime, createNullTooltipStore:runtime, TooltipHandleStore:type), packages/base/src/lib/tooltip/Trigger.svelte (TooltipHandleStore:type).

## packages/base/src/lib/tooltip/Trigger.svelte

SHA256 `8dbcb7d31709801bf5275f16af8db7d50f631c13851bb1dc22bc3a01217f9aa8`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve Source trigger registration, payload forwarding, active/inactive prop selection and ref/event order; native element/synthetic-event differences stay in canonical render/button adapters. Nested-trigger traversal, delay group claim/cancel/instant-close, tooltip-specific timers, focus/hover props and disabled ARIA follow complete Source body.

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Register and migrate by current store/id/element ownership; timeouts/frames are canonical cleanup-owned resources. Current useClick is evaluated separately, not blessed by this caller body.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. Nested-trigger traversal, delay group claim/cancel/instant-close, tooltip-specific timers, focus/hover props and disabled ARIA follow complete Source body.

Complete Original owners: packages/react/src/tooltip/trigger/TooltipTrigger.tsx

Actual incoming consumers: packages/base/src/lib/tooltip/index.parts.ts (default:runtime).

## packages/base/src/lib/tooltip/types.ts

SHA256 `d6bcb48e91c715f38a13de19b848e2419d99e40f1eb1639e3131e45e69ae5357`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Read all complete public Props/State/action/event/payload/render type bodies against their complete Source declaration owners. Native Snippet/Element/ref/render attributes replace React types without changing business unions/default contracts. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: No runtime allocation. PreviewCard HTML anchor href admits the native null boundary; generic Handle payload and erased namespaces remain typed.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/tooltip/arrow/TooltipArrow.tsx, packages/react/src/tooltip/arrow/TooltipArrowDataAttributes.ts, packages/react/src/tooltip/index.parts.ts, packages/react/src/tooltip/index.ts, packages/react/src/tooltip/popup/TooltipPopup.tsx, packages/react/src/tooltip/popup/TooltipPopupDataAttributes.ts, packages/react/src/tooltip/portal/TooltipPortal.tsx, packages/react/src/tooltip/portal/TooltipPortalContext.ts, packages/react/src/tooltip/positioner/TooltipPositioner.tsx, packages/react/src/tooltip/positioner/TooltipPositionerContext.ts, packages/react/src/tooltip/positioner/TooltipPositionerCssVars.ts, packages/react/src/tooltip/positioner/TooltipPositionerDataAttributes.ts, packages/react/src/tooltip/provider/TooltipProvider.tsx, packages/react/src/tooltip/provider/TooltipProviderContext.ts, packages/react/src/tooltip/root/TooltipRoot.tsx, packages/react/src/tooltip/root/TooltipRootContext.ts, packages/react/src/tooltip/store/TooltipHandle.ts, packages/react/src/tooltip/store/TooltipStore.ts, packages/react/src/tooltip/trigger/TooltipTrigger.tsx, packages/react/src/tooltip/trigger/TooltipTriggerDataAttributes.ts, packages/react/src/tooltip/utils/constants.ts, packages/react/src/tooltip/viewport/TooltipViewport.tsx, packages/react/src/tooltip/viewport/TooltipViewportCssVars.ts, packages/react/src/tooltip/viewport/TooltipViewportDataAttributes.ts

Actual incoming consumers: packages/base/src/lib/tooltip/Arrow.svelte (TooltipArrowProps:type), packages/base/src/lib/tooltip/index.parts.ts (TooltipProviderProps:type, TooltipProviderState:type, TooltipRootProps:type, TooltipRootState:type, TooltipTriggerProps:type, TooltipTriggerState:type, TooltipPortalProps:type, TooltipPortalState:type, TooltipPositionerProps:type, TooltipPositionerState:type, TooltipPopupProps:type, TooltipPopupState:type, TooltipArrowProps:type, TooltipArrowState:type, TooltipViewportProps:type, TooltipViewportState:type, TooltipRootActions:type, TooltipRootChangeEventReason:type, TooltipRootChangeEventDetails:type), packages/base/src/lib/tooltip/Popup.svelte (TooltipPopupProps:type, TooltipPopupState:type), packages/base/src/lib/tooltip/Portal.svelte (TooltipPortalProps:type), packages/base/src/lib/tooltip/Positioner.svelte (TooltipPositionerProps:type, TooltipPositionerState:type), packages/base/src/lib/tooltip/Provider.svelte (TooltipProviderProps:type), packages/base/src/lib/tooltip/Root.svelte (TooltipRootProps:type, TooltipRootChangeEventDetails:type), packages/base/src/lib/tooltip/store/TooltipStore.svelte.ts (TooltipRootChangeEventDetails:type, TooltipRootChangeEventReason:type), packages/base/src/lib/tooltip/Trigger.svelte (TooltipTriggerProps:type), packages/base/src/lib/tooltip/Viewport.svelte (TooltipViewportProps:type, TooltipViewportState:type).

## packages/base/src/lib/tooltip/utils/constants.ts

SHA256 `ae787b9977ba3e23f7cc07478e949bb7ccaf31f9c1f755cbf7f706dd653235ce`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Preserve the Source family complete default scalar constants with native getter callers. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: No allocation/lifetime; default delay/tolerance values are not shared across families arbitrarily.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/tooltip/utils/constants.ts

Actual incoming consumers: packages/base/src/lib/tooltip/Trigger.svelte (OPEN_DELAY:runtime).

## packages/base/src/lib/tooltip/Viewport.svelte

SHA256 `a17da7ac90b08fdb0df8d356e0102b064034d65bd227399c8d6d6a64c8fa9f53`; fresh entire new family native and complete Original declaration/body owner; fresh current native full body: True.

Delegate all content-change capture/morph/content-key business to the single canonical usePopupViewport. Native attachments and keyed snippet markup provide current/previous DOM containers. 

Source: No additional issue in this entire body; complete dependency closure remains blocked by canonical useClick.

Native: Native runes/context/snippets/attachments and canonical helpers directly implement the Source composition; no new React hook engine.

Lifetime: Temporary transition content and style/size work remain owned by canonical viewport/resize helpers; current previous elements are detached on lifetime cleanup.

Maintainability: Separate actual part/store/context and one canonical helper per behavior; no arbitrary replacement algorithm. 

Complete Original owners: packages/react/src/tooltip/viewport/TooltipViewport.tsx

Actual incoming consumers: packages/base/src/lib/tooltip/index.parts.ts (default:runtime).

## packages/base/src/lib/utils/addEventListener.ts

SHA256 `77880d75a5c8c5ac2d924e69d7cc7662c616b953d4895c8e6a24de53de4502bf`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (addEventListener:runtime), packages/base/src/lib/floating-ui/components/FloatingPortal.svelte (addEventListener:runtime), packages/base/src/lib/floating-ui/hooks/useClientPoint.svelte.ts (addEventListener:runtime), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (addEventListener:runtime), packages/base/src/lib/floating-ui/hooks/useFocus.svelte.ts (addEventListener:runtime), packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts (addEventListener:runtime), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (addEventListener:runtime), packages/base/src/lib/utils/useScrollLock.svelte.ts (addEventListener:runtime).

## packages/base/src/lib/utils/closePart.svelte.ts

SHA256 `cf4f7d4a7a2d5616522a165bba1fc8a56ab08a1f746c9872f9cd8e8ad8451466`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Full complete native and Original ClosePart context/count/register/cleanup/clamp bodies and actual native provider/child call sites. CLEAR for helper Source/native/maintainability; family focusManagerModal composition remains absent and unclaimed.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Close.svelte (useClosePartRegistration:runtime), packages/base/src/lib/popover/Popup.svelte (ClosePartContext:runtime, useClosePartCount:runtime).

## packages/base/src/lib/utils/CommonPopupCssVars.ts

SHA256 `f9dddda047401345f05809796e771f5a204664ff6c828c82e0eb314198a1c57a`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Both complete Source popup prior-content width/height CSS variable names.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Viewport.svelte (*:runtime), packages/base/src/lib/preview-card/Viewport.svelte (*:runtime), packages/base/src/lib/tooltip/Viewport.svelte (*:runtime), packages/base/src/lib/utils/usePopupAutoResize.svelte.ts (*:runtime).

## packages/base/src/lib/utils/CommonPopupDataAttributes.ts

SHA256 `ed25a93130d096ba883e68999928e43dad59d09ae9dff52f0e8b68d5974abe15`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/utils/popupStateMapping.ts (*:runtime).

## packages/base/src/lib/utils/CommonPositionerCssVars.ts

SHA256 `457560d32ec1afda1f3880e9b284bd162f6923348830bf8983fb3a5d050ab74e`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Every Source available/anchor/transform-origin/positioner CSS variable name.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/utils/usePopupAutoResize.svelte.ts (*:runtime).

## packages/base/src/lib/utils/CommonTriggerDataAttributes.ts

SHA256 `199df87949923494ce8f3f6b3bfcc05e162744891afb12c033f5e7f9ba8f4f92`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/utils/popupStateMapping.ts (*:runtime).

## packages/base/src/lib/utils/CommonViewportDataAttributes.ts

SHA256 `b2b2ff787608db21ef5e579b026e6fd38c180046c2584acaa3b76c66e398d394`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Complete Source activation-direction attribute string.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/utils/usePopupViewport.svelte.ts (*:runtime).

## packages/base/src/lib/utils/createLogOnce.ts

SHA256 `a3c52188a495927ef9b49765ca1e70bc384b37b68a5c896ca86df15852a279b1`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/utils/error.ts (createLogOnce:runtime), packages/base/src/lib/utils/error.ts (reset:runtime).

## packages/base/src/lib/utils/dispatchClickWithModifiers.ts

SHA256 `60aab2aa25eb9c0aeaa0a57fc8ccd37aab747577ea22f019aff163946cabd373`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/use-button/useButton.svelte.ts (dispatchClickWithModifiers:runtime).

## packages/base/src/lib/utils/empty.ts

SHA256 `eb679c977169a61764f98516194102fed5b70b6157992b34029dcd39af467d7b`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/utils/enqueueFocus.ts (NOOP:runtime), packages/base/src/lib/internals/createBaseUIEventDetails.ts (EMPTY_OBJECT:runtime), packages/base/src/lib/internals/getDisabledMountTransitionStyles.ts (EMPTY_OBJECT:runtime), packages/base/src/lib/internals/useRenderElement.ts (EMPTY_OBJECT:runtime), packages/base/src/lib/popover/store/PopoverStore.svelte.ts (NOOP:runtime), packages/base/src/lib/tooltip/root/TooltipInteractions.svelte (EMPTY_OBJECT:runtime), packages/base/src/lib/tooltip/store/TooltipStore.svelte.ts (NOOP:runtime), packages/base/src/lib/utils/popups/popupStoreUtils.svelte.ts (EMPTY_OBJECT:runtime), packages/base/src/lib/utils/popups/store.ts (EMPTY_OBJECT:runtime), packages/base/src/lib/utils/usePopupAutoResize.svelte.ts (NOOP:runtime, EMPTY_OBJECT:runtime).

## packages/base/src/lib/utils/error.ts

SHA256 `de9eeee73db42c056c110eb94f3aef8b51ae3003e97d5140bfaf876bdde52c69`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/use-button/useButton.svelte.ts (error:runtime).

## packages/base/src/lib/utils/FloatingPortalLite.svelte

SHA256 `c506d0758a012c2789b9da39f17bd34d7bf3f10d67d3861368f998b6b4a12b72`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Entire Lite Source portal and actual canonical node/content/context-map adapter with keepMounted/native container behavior and cleanup; no duplicate Full portal state.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-shared-helper-review-058c281/audit.json

Actual incoming consumers: packages/base/src/lib/preview-card/Portal.svelte (default:runtime), packages/base/src/lib/tooltip/Portal.svelte (default:runtime).

## packages/base/src/lib/utils/FocusGuard.svelte

SHA256 `28a17af6cd0d817c9002e0e2bae206b33452fc6a0153ffb45f6f6f0b8f96c777`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/FloatingFocusManager.svelte (default:runtime), packages/base/src/lib/floating-ui/components/FloatingPortal.svelte (default:runtime), packages/base/src/lib/popover/Trigger.svelte (default:runtime).

## packages/base/src/lib/utils/getCssDimensions.ts

SHA256 `f5f7b8ba4da86949dfa6ac61b706fdebf079e7a03a78b0d7ab3dd4cb66c10829`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/utils/usePopupAutoResize.svelte.ts (getCssDimensions:runtime).

## packages/base/src/lib/utils/InternalBackdrop.svelte

SHA256 `41a9ef1e56c442d73930a86015e08ff543b871475b26bd5f8da1936c3715822c`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Positioner.svelte (default:runtime).

## packages/base/src/lib/utils/mergeCleanups.ts

SHA256 `28eb97759c815e7a3edcb4a5ac4464473790ae9294bda5a66ba268bca8efedcb`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (mergeCleanups:runtime), packages/base/src/lib/floating-ui/components/FloatingPortal.svelte (mergeCleanups:runtime), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (mergeCleanups:runtime), packages/base/src/lib/floating-ui/hooks/useFocus.svelte.ts (mergeCleanups:runtime), packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts (mergeCleanups:runtime), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (mergeCleanups:runtime).

## packages/base/src/lib/utils/mergeObjects.ts

SHA256 `1e6cfa2be20c639f5ce6f8b0b6cc447da3413bbbc6750a5b1ab03f5810d81746`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/internals/nativeProps.ts (mergeObjects:runtime), packages/base/src/lib/internals/useRenderElement.ts (mergeObjects:runtime), packages/base/src/lib/merge-props/mergeProps.ts (mergeObjects:runtime).

## packages/base/src/lib/utils/NullStore.svelte.ts

SHA256 `442595fdf67989d0bdae8f422a53bfed7622832b0e5112f60e782d8d75a97e43`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/store/PopoverStore.svelte.ts (NullStore:runtime), packages/base/src/lib/preview-card/store/PreviewCardStore.svelte.ts (NullStore:runtime), packages/base/src/lib/tooltip/store/TooltipStore.svelte.ts (NullStore:runtime).

## packages/base/src/lib/utils/owner.ts

SHA256 `4f32738229316fe875cf72e949caa4aa7d2fcdf924a2bd5b7f01e88ca5424185`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (ownerDocument:runtime, ownerWindow:runtime), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (ownerDocument:runtime), packages/base/src/lib/floating-ui/hooks/useFocus.svelte.ts (ownerDocument:runtime), packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts (ownerDocument:runtime), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (ownerDocument:runtime), packages/base/src/lib/floating-ui/utils/markOthers.ts (ownerDocument:runtime), packages/base/src/lib/floating-ui/utils/tabbable.ts (ownerDocument:runtime), packages/base/src/lib/utils/dispatchClickWithModifiers.ts (ownerWindow:runtime), packages/base/src/lib/utils/useAnchoredPopupScrollLock.svelte.ts (ownerDocument:runtime), packages/base/src/lib/utils/usePopupViewport.svelte.ts (ownerDocument:runtime), packages/base/src/lib/utils/useScrollLock.svelte.ts (ownerDocument:runtime, ownerWindow:runtime).

## packages/base/src/lib/utils/platform/engine.ts

SHA256 `e4745bcc586212a32cde2f7d206cc1aa4df86b8a29301f8d15cf3cd88996a987`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/utils/platform/parts.ts (*:runtime).

## packages/base/src/lib/utils/platform/env.ts

SHA256 `dbd7cc1369986d370094b986c44b1bce3c10eba1f792f0e5c3e99c071e00eb9d`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/utils/platform/parts.ts (*:runtime).

## packages/base/src/lib/utils/platform/index.ts

SHA256 `c9c1174c0f82f01033187e382b461370123d356d8e14901a9ca7d85dbd2ea63c`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (platform:runtime), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (platform:runtime), packages/base/src/lib/floating-ui/hooks/useFocus.svelte.ts (platform:runtime), packages/base/src/lib/floating-ui/utils/event.ts (platform:runtime), packages/base/src/lib/floating-ui/utils/matchesFocusVisible.ts (platform:runtime), packages/base/src/lib/utils/FocusGuard.svelte (platform:runtime), packages/base/src/lib/utils/useOpenInteractionType.svelte.ts (platform:runtime), packages/base/src/lib/utils/useScrollLock.svelte.ts (platform:runtime).

## packages/base/src/lib/utils/platform/media-query.ts

SHA256 `5e91ea2589962018778ad88498ff9acd432a5244fe37ee922d0a6014b1fb7ed9`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/utils/platform/parts.ts (*:runtime).

## packages/base/src/lib/utils/platform/os.ts

SHA256 `456f2f5814e890fb12d899c1cc2f08566529216fd8f6d40a9a8e5846b2c9c3d6`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/utils/platform/parts.ts (*:runtime), packages/base/src/lib/utils/platform/screen-reader.ts (apple:runtime).

## packages/base/src/lib/utils/platform/parts.ts

SHA256 `5382169dc9803fde93bc85e33062cbc85d7cdc0bf754d1a7f6f21eb2b4dcac29`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/utils/platform/index.ts (*:runtime).

## packages/base/src/lib/utils/platform/screen-reader.ts

SHA256 `c43ebce8b6557becf984c0ae7f36395da615110e7f878bab1c0dfd476ceb19a7`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/utils/platform/parts.ts (*:runtime).

## packages/base/src/lib/utils/platform/shared.ts

SHA256 `28621a4723495ed9f1370c09b12480a6f488f19e59c70e78524325fc6e080db2`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/utils/platform/engine.ts (lowerUserAgent:runtime), packages/base/src/lib/utils/platform/env.ts (lowerUserAgent:runtime), packages/base/src/lib/utils/platform/os.ts (lowerUserAgent:runtime, lowerPlatform:runtime, maxTouchPoints:runtime).

## packages/base/src/lib/utils/popups/index.ts

SHA256 `8685650fb9e3f7bfe7528330f062c4b3f94df89bf9adc8a48b13728774474e01`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/utils/element.ts (PopupTriggerMap:type), packages/base/src/lib/popover/store/PopoverStore.svelte.ts (createInitialPopupStoreState:runtime, PopupStoreContext:type, popupStoreSelectors:runtime, PopupStoreState:type, PopupTriggerMap:runtime, PopupTriggerStoreKeys:type, createPopupOpenState:runtime), packages/base/src/lib/preview-card/store/PreviewCardStore.svelte.ts (createInitialPopupStoreState:runtime, PopupStoreContext:type, popupStoreSelectors:runtime, PopupStoreState:type, PopupTriggerMap:runtime, PopupTriggerStoreKeys:type), packages/base/src/lib/tooltip/store/TooltipStore.svelte.ts (createInitialPopupStoreState:runtime, PopupStoreContext:type, popupStoreSelectors:runtime, PopupStoreState:type, PopupTriggerMap:runtime, PopupTriggerStoreKeys:type).

## packages/base/src/lib/utils/popups/inlineRect.ts

SHA256 `e7e677e1575edf7c0c090442605503b156f557b5b103bf26f27b94eeae6905f4`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Full complete native and Original inlineRect business functions: line grouping/fallback, hit tolerance, stored lineIndex, native focusin/mouseenter/mousemove boundary, trigger/contextElement identity, selected edge rectangles, actual platform.getElementRects call, no-op equal-rect guard, reset rects. CLEAR for Source/native/maintainability; framework event/ref/type substitutions explicit.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/preview-card/Positioner.svelte (createInlineMiddleware:runtime), packages/base/src/lib/preview-card/store/PreviewCardStore.svelte.ts (InlineRectCoords:type, updateInlineRectCoords:runtime), packages/base/src/lib/preview-card/Trigger.svelte (getInlineRectTriggerProps:runtime).

## packages/base/src/lib/utils/popups/popupHandle.svelte.ts

SHA256 `5acdc474609054a89472cdaa01531fa06e2670ac98e735f11f19e1651239ae89`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/store/PopoverHandle.svelte.ts (BasePopupHandle:runtime), packages/base/src/lib/preview-card/store/PreviewCardHandle.svelte.ts (BasePopupHandle:runtime), packages/base/src/lib/tooltip/store/TooltipHandle.svelte.ts (BasePopupHandle:runtime), packages/base/src/lib/utils/popups/usePopupHandleStore.svelte.ts (PopupHandleStoreProvider:type).

## packages/base/src/lib/utils/popups/PopupHandleAttachment.svelte

SHA256 `bb34f4ea941b5579a57d1ff6432f3f5bf59c84a762c663112be7c7a9f4338985`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Root.svelte (default:runtime), packages/base/src/lib/preview-card/Root.svelte (default:runtime), packages/base/src/lib/tooltip/Root.svelte (default:runtime).

## packages/base/src/lib/utils/popups/popupStoreUtils.svelte.ts

SHA256 `3f80c77e00b2b8d73068a48477096f30f174c433d804b790813894f6624f016e`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Full current native module freshly read. Exact11 individually accepted existing function bodies and imports remain preserved; complete appended Source function read with callback/preventUnmount, cancellation, beforeDispatch, canonical floating dispatch, state precedence/reasons and native flushSync unchanged. No wider Menu/Dialog acceptance.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Popup.svelte (FOCUSABLE_POPUP_PROPS:runtime), packages/base/src/lib/popover/Popup.svelte (createDefaultInitialFocus:runtime), packages/base/src/lib/popover/Root.svelte (useImplicitActiveTrigger:runtime, useOpenStateTransitions:runtime, usePopupRootStore:runtime, usePopupRootSync:runtime), packages/base/src/lib/popover/root/PopoverInteractions.svelte (usePopupInteractionProps:runtime), packages/base/src/lib/popover/store/PopoverStore.svelte.ts (attachPreventUnmountOnClose:runtime), packages/base/src/lib/popover/Trigger.svelte (useTriggerDataForwarding:runtime), packages/base/src/lib/preview-card/Popup.svelte (FOCUSABLE_POPUP_PROPS:runtime), packages/base/src/lib/preview-card/Root.svelte (useImplicitActiveTrigger:runtime, useOpenStateTransitions:runtime, usePopupRootStore:runtime), packages/base/src/lib/preview-card/root/PreviewCardInteractions.svelte (usePopupInteractionProps:runtime), packages/base/src/lib/preview-card/store/PreviewCardStore.svelte.ts (applyPopupOpenChange:runtime), packages/base/src/lib/preview-card/Trigger.svelte (useTriggerDataForwarding:runtime), packages/base/src/lib/tooltip/Popup.svelte (FOCUSABLE_POPUP_PROPS:runtime), packages/base/src/lib/tooltip/Root.svelte (useImplicitActiveTrigger:runtime, useOpenStateTransitions:runtime, usePopupRootStore:runtime), packages/base/src/lib/tooltip/root/TooltipInteractions.svelte (usePopupInteractionProps:runtime), packages/base/src/lib/tooltip/store/TooltipStore.svelte.ts (applyPopupOpenChange:runtime), packages/base/src/lib/tooltip/Trigger.svelte (useTriggerDataForwarding:runtime), packages/base/src/lib/utils/popups/index.ts (createPopupOpenState:runtime).

## packages/base/src/lib/utils/popups/popupTriggerMap.svelte.ts

SHA256 `812f1d6cb454c0f5236cda69919932ccfc569611050c19fe8198617beacf6b2c`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/FloatingRootStore.svelte.ts (PopupTriggerMap:type), packages/base/src/lib/utils/popups/index.ts (PopupTriggerMap:runtime), packages/base/src/lib/utils/popups/popupHandle.svelte.ts (PopupTriggerMap:type), packages/base/src/lib/utils/popups/store.ts (PopupTriggerMap:runtime).

## packages/base/src/lib/utils/popups/store.ts

SHA256 `f10a365441f28fa1e93b1d1cc871349a0555944e3fd937344b3415c3d32a87d3`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/hooks/useSyncedFloatingRootContext.svelte.ts (PopupStoreState:type, PopupTriggerDataStore:type), packages/base/src/lib/utils/popups/index.ts (*:runtime), packages/base/src/lib/utils/popups/popupStoreUtils.svelte.ts (PopupStoreState:type, PopupStoreContext:type), packages/base/src/lib/utils/popups/popupStoreUtils.svelte.ts (PopupTriggerDataStore:type).

## packages/base/src/lib/utils/popups/usePopupHandleStore.svelte.ts

SHA256 `3bbe4fd4132a3acdeb82b575f734b01caccc7c3033b8162fa64ad619a8bfbf58`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Trigger.svelte (usePopupHandleStore:runtime), packages/base/src/lib/preview-card/Trigger.svelte (usePopupHandleStore:runtime), packages/base/src/lib/tooltip/Trigger.svelte (usePopupHandleStore:runtime).

## packages/base/src/lib/utils/popups/useTriggerFocusGuards.svelte.ts

SHA256 `61c4a5e3e40b0f8ff0d48d40208687ef43a209818cbe4bb6a9058050d91a1678`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Entire Source trigger before/after focus guard and target selection, mounted/root/element registration, focus scheduling, callback and cleanup order.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Trigger.svelte (useTriggerFocusGuards:runtime).

## packages/base/src/lib/utils/popupStateMapping.ts

SHA256 `07a2ecdd556f8e1371d395f7749cbfb1bff445b4f07b321d8e7d8ecf5393350d`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Arrow.svelte (popupStateMapping:runtime), packages/base/src/lib/popover/Backdrop.svelte (popupTransitionStateMapping:runtime), packages/base/src/lib/popover/Popup.svelte (popupTransitionStateMapping:runtime), packages/base/src/lib/popover/Trigger.svelte (triggerOpenStateMapping:runtime, pressableTriggerOpenStateMapping:runtime), packages/base/src/lib/preview-card/Arrow.svelte (popupStateMapping:runtime), packages/base/src/lib/preview-card/Backdrop.svelte (popupTransitionStateMapping:runtime), packages/base/src/lib/preview-card/Popup.svelte (popupTransitionStateMapping:runtime), packages/base/src/lib/preview-card/Trigger.svelte (triggerOpenStateMapping:runtime), packages/base/src/lib/tooltip/Arrow.svelte (popupStateMapping:runtime), packages/base/src/lib/tooltip/Popup.svelte (popupTransitionStateMapping:runtime), packages/base/src/lib/tooltip/Trigger.svelte (triggerOpenStateMapping:runtime), packages/base/src/lib/utils/usePositioner.svelte.ts (popupStateMapping:runtime).

## packages/base/src/lib/utils/resolveClassName.ts

SHA256 `b22aead630ca531851a08a63e5165e64ff8cdc9de5765ff20997f578071cb108`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/useRenderElement.ts (resolveClassName:runtime).

## packages/base/src/lib/utils/resolveRef.ts

SHA256 `ac85daa436a61800f824aa34ea08ff4cbe492c86c12be327de957a381acddaa7`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (resolveRef:runtime), packages/base/src/lib/internals/useAnimationsFinished.ts (resolveRef:runtime).

## packages/base/src/lib/utils/resolveStyle.ts

SHA256 `cdc420598c1ae4b75a32e7f47ac8cc7f4fe444d4f006e2736f528951fb932977`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/useRenderElement.ts (resolveStyle:runtime).

## packages/base/src/lib/utils/shadowDom.ts

SHA256 `a5bfa768f801af70e62c012459ddd2b4289a3d2a27aa79c5e9e1414a50395ed1`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/utils/element.ts (activeElement:runtime, contains:runtime, getTarget:runtime).

## packages/base/src/lib/utils/store/Store.svelte.ts

SHA256 `cb14e7e3e12bffcb353761c48bc275e41949bad5706860f0d877ea3344e0b600`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/utils/store/SvelteStore.svelte.ts (Store:runtime).

## packages/base/src/lib/utils/store/SvelteStore.svelte.ts

SHA256 `1a3fe2b85c9b4c3dc0333f43f9988bbfa01e39eb5972b84b3648294199e111a2`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Entire native facade and full ReactStore Source boundary; canonical Store observe subscription/change comparator/cleanup retained, rune version+createSubscriber transport replaces React controlled/synced/useState/render transport. No React commit snapshot engine.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/FloatingRootStore.svelte.ts (SvelteStore:runtime), packages/base/src/lib/popover/store/PopoverStore.svelte.ts (SvelteStore:runtime), packages/base/src/lib/preview-card/store/PreviewCardStore.svelte.ts (SvelteStore:runtime), packages/base/src/lib/tooltip/store/TooltipStore.svelte.ts (SvelteStore:runtime), packages/base/src/lib/utils/NullStore.svelte.ts (SvelteStore:runtime), packages/base/src/lib/utils/popups/store.ts (SvelteStore:type).

## packages/base/src/lib/utils/useAnchoredPopupScrollLock.svelte.ts

SHA256 `583b97998d16e0b1aef3c44fdbef154fa848d8f8385a07dc21aa56b3c8470dce`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Full Source lock enable/interaction/open/modal selection and canonical scroll-lock delegation/cleanup.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Positioner.svelte (useAnchoredPopupScrollLock:runtime).

## packages/base/src/lib/utils/useAnimationFrame.ts

SHA256 `4de538634e157740822dc1d3896da18ea84c6a706fe79f28fa6b9e7d380038ad`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (useAnimationFrame:runtime), packages/base/src/lib/floating-ui/hooks/useClick.svelte.ts (useAnimationFrame:runtime), packages/base/src/lib/internals/useAnimationsFinished.ts (useAnimationFrame:runtime), packages/base/src/lib/internals/useTransitionStatus.svelte.ts (AnimationFrame:runtime), packages/base/src/lib/utils/popups/popupHandle.svelte.ts (AnimationFrame:runtime), packages/base/src/lib/utils/usePopupAutoResize.svelte.ts (useAnimationFrame:runtime), packages/base/src/lib/utils/usePopupViewport.svelte.ts (useAnimationFrame:runtime), packages/base/src/lib/utils/useScrollLock.svelte.ts (AnimationFrame:runtime).

## packages/base/src/lib/utils/useEnhancedClickHandler.ts

SHA256 `6a045d6b74a7851d3446200f55711ffc1dcc22449a2e92680cdf328750a436d5`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (InteractionType:type), packages/base/src/lib/popover/store/PopoverStore.svelte.ts (InteractionType:type), packages/base/src/lib/popover/types.ts (InteractionType:type), packages/base/src/lib/utils/popups/popupStoreUtils.svelte.ts (InteractionType:type), packages/base/src/lib/utils/useOpenInteractionType.svelte.ts (useEnhancedClickHandler:runtime, InteractionType:type).

## packages/base/src/lib/utils/useFocusableWhenDisabled.ts

SHA256 `8c52b8e41b8801cd46d4232802c5ed86588cb4e8008f814741970246b378742c`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/use-button/useButton.svelte.ts (useFocusableWhenDisabled:runtime).

## packages/base/src/lib/utils/useId.ts

SHA256 `126f5436587c25942d9b12cf2ffbf353c7b87690bf37c0795da7ee5e14244e90`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/internals/useBaseUiId.ts (useId:runtime).

## packages/base/src/lib/utils/useIsoLayoutEffect.svelte.ts

SHA256 `0d24dd22dad18fc54341aaedb964a25829ae62322f10bf110a4fd8bde65dd1f3`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/floating-ui/components/FloatingDelayGroup.svelte (useIsoLayoutEffect:runtime), packages/base/src/lib/floating-ui/components/FloatingPortal.svelte (useIsoLayoutEffect:runtime), packages/base/src/lib/floating-ui/components/FloatingTree.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/floating-ui/hooks/useClientPoint.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/floating-ui/hooks/useDelayGroup.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/floating-ui/hooks/useFloating.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/floating-ui/hooks/useFloatingPortalNode.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/floating-ui/hooks/useFocus.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/floating-ui/hooks/useSyncedFloatingRootContext.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/internals/use-button/useButton.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/internals/useOpenChangeComplete.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/internals/useTransitionStatus.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/internals/useValueChanged.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/popover/Positioner.svelte (useIsoLayoutEffect:runtime), packages/base/src/lib/popover/Root.svelte (useIsoLayoutEffect:runtime), packages/base/src/lib/preview-card/Positioner.svelte (useIsoLayoutEffect:runtime), packages/base/src/lib/preview-card/Root.svelte (useIsoLayoutEffect:runtime), packages/base/src/lib/tooltip/Root.svelte (useIsoLayoutEffect:runtime), packages/base/src/lib/utils/closePart.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/utils/popups/PopupHandleAttachment.svelte (useIsoLayoutEffect:runtime), packages/base/src/lib/utils/popups/popupStoreUtils.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/utils/useAnchoredPopupScrollLock.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/utils/usePopupAutoResize.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/utils/usePopupViewport.svelte.ts (useIsoLayoutEffect:runtime), packages/base/src/lib/utils/useScrollLock.svelte.ts (useIsoLayoutEffect:runtime).

## packages/base/src/lib/utils/useMergedRefs.ts

SHA256 `d9420f3db2872a32aca95c7c32db1342da4df6595df68a17707f55a27ea41fe2`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (createMergedRefs:runtime), packages/base/src/lib/floating-ui/components/FloatingPortal.svelte (MergedRef:type), packages/base/src/lib/floating-ui/hooks/useFloatingPortalNode.svelte.ts (MergedRef:type), packages/base/src/lib/internals/nativeRefAttachment.ts (MergedRefCallback:type), packages/base/src/lib/internals/useRenderElement.ts (createMergedRefs:runtime, MergedRef:type, MergedRefCallback:type), packages/base/src/lib/utils/FloatingPortalLite.svelte (MergedRef:type), packages/base/src/lib/utils/FocusGuard.svelte (createMergedRefs:runtime, MergedRef:type), packages/base/src/lib/utils/InternalBackdrop.svelte (createMergedRefs:runtime, MergedRef:type), packages/base/src/lib/utils/usePositioner.svelte.ts (MergedRef:type).

## packages/base/src/lib/utils/useOnMount.ts

SHA256 `a7ba4007eff27b601eebcb76755886a23a4dd8548a54f67e15fa1cd648e0e695`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/hooks/useHoverInteractionSharedState.svelte.ts (useOnMount:runtime), packages/base/src/lib/utils/useAnimationFrame.ts (useOnMount:runtime), packages/base/src/lib/utils/useTimeout.ts (useOnMount:runtime).

## packages/base/src/lib/utils/useOpenInteractionType.svelte.ts

SHA256 `1e226c9fd96e234f73f7c8889e233455f8e4b0951f1e75059e3e17ac812550e2`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Full Source event/ref classification and latest open interaction output, owner realm/virtual/touch/key event branches.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Trigger.svelte (useOpenMethodTriggerProps:runtime).

## packages/base/src/lib/utils/usePopupAutoResize.svelte.ts

SHA256 `9af5d5bdaa1f01f907b8dc41250737747f8535a10c50cf5095e3eac4a3ddc1d5`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

All 180 lines/full Original; actual current content/popup dims, MutationObserver and ResizeObserver scopes, effect/callback timing, transition size bookkeeping, Source scrollarea stylesheet marker/default handling and cleanup.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/utils/usePopupViewport.svelte.ts (usePopupAutoResize:runtime).

## packages/base/src/lib/utils/usePopupViewport.svelte.ts

SHA256 `d0c82a8b70e176d109c4a3755d5186bf678e6cdb516053140f307eddd3336409`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

All 269 lines/full Original; seven narrow typed Store capability overloads, real source payload/active-trigger key remount bookkeeping, previous/current DOM transition/cleanup, CSS vars and direction offsets, dimension timers and subscriber ownership. Overloads express actual store operations, not algorithm fork.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Viewport.svelte (popupViewportStateMapping:runtime, usePopupViewport:runtime), packages/base/src/lib/preview-card/Viewport.svelte (popupViewportStateMapping:runtime, usePopupViewport:runtime), packages/base/src/lib/tooltip/Viewport.svelte (popupViewportStateMapping:runtime, usePopupViewport:runtime).

## packages/base/src/lib/utils/usePositioner.svelte.ts

SHA256 `59422a6bc1fb88a6027ada39f53382730d151a8e9958e14a2202514ce95b192d`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: True.

Full Source resize/current element ref, open/presence dimensions and canonical positioner style/CSS variable updates and cleanup.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/popover/Positioner.svelte (usePositioner:runtime), packages/base/src/lib/preview-card/Positioner.svelte (usePositioner:runtime), packages/base/src/lib/tooltip/Positioner.svelte (usePositioner:runtime).

## packages/base/src/lib/utils/usePreviousValue.svelte.ts

SHA256 `9583824fa430b3db985b9a288f69305b2a0f29b6a4defa06d20bb5b39f9b6d46`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Full Source Object.is keyed previous/current pair; native derived bookkeeping updates on distinct values and returns prior pair value, not effect-lag emulation.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/utils/usePopupViewport.svelte.ts (usePreviousValue:runtime).

## packages/base/src/lib/utils/useRefWithInit.ts

SHA256 `998166cdfed66790af4659ac61d8b36f49f1aa4c35a66bb532f6239771271036`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/hooks/useHoverInteractionSharedState.svelte.ts (useRefWithInit:runtime), packages/base/src/lib/internals/useValueChanged.svelte.ts (useRefWithInit:runtime), packages/base/src/lib/utils/useAnimationFrame.ts (useRefWithInit:runtime), packages/base/src/lib/utils/useMergedRefs.ts (useRefWithInit:runtime), packages/base/src/lib/utils/useTimeout.ts (useRefWithInit:runtime).

## packages/base/src/lib/utils/useScrollLock.svelte.ts

SHA256 `414a9408f41af2df8abfe984a0a1c6a667a592bb58467a977d8618e7e8bd5489`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/utils/useAnchoredPopupScrollLock.svelte.ts (useScrollLock:runtime).

## packages/base/src/lib/utils/useStableCallback.ts

SHA256 `b790a02da99e0e9365bc05d35a434ef37dcffb2a4db8186b1327b949a994d05e`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (useStableCallback:runtime), packages/base/src/lib/floating-ui/hooks/useClientPoint.svelte.ts (useStableCallback:runtime), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (useStableCallback:runtime), packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts (useStableCallback:runtime), packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts (useStableCallback:runtime), packages/base/src/lib/internals/use-button/useButton.svelte.ts (useStableCallback:runtime), packages/base/src/lib/internals/useAnimationsFinished.ts (useStableCallback:runtime), packages/base/src/lib/internals/useOpenChangeComplete.svelte.ts (useStableCallback:runtime), packages/base/src/lib/internals/useValueChanged.svelte.ts (useStableCallback:runtime), packages/base/src/lib/utils/closePart.svelte.ts (useStableCallback:runtime), packages/base/src/lib/utils/popups/popupStoreUtils.svelte.ts (useStableCallback:runtime), packages/base/src/lib/utils/usePopupAutoResize.svelte.ts (useStableCallback:runtime), packages/base/src/lib/utils/usePopupViewport.svelte.ts (useStableCallback:runtime).

## packages/base/src/lib/utils/useTimeout.ts

SHA256 `a04448de8715b8728243ee6e33572c57bc5b151674628304f6c3906966738c78`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/popup-remaining-helpers-review-bd73205/audit.json

Actual incoming consumers: packages/base/src/lib/floating-ui/components/createFloatingFocusManager.svelte.ts (useTimeout:runtime), packages/base/src/lib/floating-ui/components/FloatingDelayGroup.svelte (useTimeout:runtime), packages/base/src/lib/floating-ui/components/FloatingDelayGroupContext.ts (Timeout:runtime), packages/base/src/lib/floating-ui/hooks/useClick.svelte.ts (useTimeout:runtime), packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts (Timeout:runtime, useTimeout:runtime), packages/base/src/lib/floating-ui/hooks/useFocus.svelte.ts (useTimeout:runtime), packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts (useTimeout:runtime), packages/base/src/lib/floating-ui/hooks/useHoverInteractionSharedState.svelte.ts (Timeout:runtime), packages/base/src/lib/floating-ui/safePolygon.ts (Timeout:runtime), packages/base/src/lib/popover/store/PopoverStore.svelte.ts (Timeout:runtime), packages/base/src/lib/tooltip/Trigger.svelte (useTimeout:runtime), packages/base/src/lib/utils/useScrollLock.svelte.ts (Timeout:runtime).

## packages/base/src/lib/utils/visuallyHidden.ts

SHA256 `8f49185df1c0536608090368454cc3d30a3bfc1991b23a4b5e5239184ead8020`; exact individual complete Source/native scope with current member/kind and incoming-consumer review; fresh current native full body: False.

Inherited precise complete Source/native body scope from authoritative CLEAR report, with new Menu consumer/caller boundary inspected separately. Not a fresh body reading; no acceptance from hash/graph alone.

Source: CLEAR only within retained exact individual whole-body scope and current reviewed incoming boundaries; no historical family/closure verdict transfer.

Native: Retain the explicit individual native composition scope; fresh new-family callers directly compose its existing contract.

Lifetime: Exact prior complete lifetime/resource/ref cleanup scope retained; current incoming callbacks/store/context/ref policies read in whole family bodies. Changed bridge and known click are separate fresh rows.

Maintainability: Retain exact individual fullbody maintainability judgment and canonical shared authority; no new family duplicate algorithm.

Exact individual authority: /workspace/sveltery-tmp/menu-family-realm-review-2a3ed25/audit.json

Actual incoming consumers: packages/base/src/lib/utils/FocusGuard.svelte (visuallyHidden:runtime).

