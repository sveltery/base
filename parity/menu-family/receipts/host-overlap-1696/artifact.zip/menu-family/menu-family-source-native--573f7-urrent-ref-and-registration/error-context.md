# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: menu-family-source.spec.ts >> native Svelte: replacing a render host preserves the current ref and registration
- Location: tests/browser/menu-family-source.spec.ts:190:3

# Error details

```
Error: expect(received).toMatchObject(expected)

- Expected  - 2
+ Received  + 2

  Object {
    "afterHostCount": 1,
-   "boundHost": "after",
-   "registeredHost": "after",
+   "boundHost": null,
+   "registeredHost": null,
  }
```

# Page snapshot

```yaml
- main [ref=e3]:
  - button "Open" [ref=e4] [cursor=pointer]
```

# Test source

```ts
  149 |     await setup(page, reference, { mode: 'context' });
  150 |     await page.locator('#opener').click({ button: 'right', position: { x: 15, y: 10 } });
  151 |     await expect(page.locator('[data-testid=popup]')).toBeVisible();
  152 |     await expect(page.locator('[data-testid=positioner]')).toHaveCSS('position', 'fixed');
  153 |     await page.keyboard.press('ArrowDown');
  154 |     await expect(page.locator('#alpha')).toBeFocused();
  155 |     await page.keyboard.press('Escape');
  156 |     await expect(page.locator('[data-testid=popup]')).toHaveCount(0);
  157 |   });
  158 |   test(`${framework}: hover opens after rest and mouse exit dismisses`, async ({ page }) => {
  159 |     await setup(page, reference, { mode: 'hover' });
  160 |     await page.locator('#opener').hover();
  161 |     await expect(page.locator('[data-testid=popup]')).toBeVisible();
  162 |     await page.mouse.move(600, 400);
  163 |     await expect(page.locator('[data-testid=popup]')).toHaveCount(0);
  164 |   });
  165 |   test(`${framework}: Toolbar menu restores composite focus and arrow relay`, async ({ page }) => {
  166 |     await setup(page, reference, { mode: 'toolbar' });
  167 |     await page.locator('#opener').focus();
  168 |     await page.keyboard.press('Enter');
  169 |     await expect(page.locator('#alpha')).toBeFocused();
  170 |     await page.keyboard.press('Escape');
  171 |     await expect(page.locator('#opener')).toBeFocused();
  172 |     await page.keyboard.press('ArrowRight');
  173 |     await expect(page.locator('#after')).toBeFocused();
  174 |   });
  175 |   test(`${framework}: modal menu locks scroll and outside pointer dismisses`, async ({ page }) => {
  176 |     await setup(page, reference, { mode: 'modal' });
  177 |     await page.locator('#opener').click();
  178 |     await expect(page.locator('[data-testid=popup]')).toBeVisible();
  179 |     expect(
  180 |       await page.evaluate(
  181 |         () => document.documentElement.style.overflow || document.body.style.overflow,
  182 |       ),
  183 |     ).toBe('hidden');
  184 |     await page.mouse.click(600, 400);
  185 |     await expect(page.locator('[data-testid=popup]')).toHaveCount(0);
  186 |   });
  187 | }
  188 | 
  189 | for (const reference of [true, false]) {
  190 |   test(`${reference ? 'Original React' : 'native Svelte'}: replacing a render host preserves the current ref and registration`, async ({
  191 |     page,
  192 |   }) => {
  193 |     await page.goto(`/menu-trigger-host-overlap${reference ? '?reference' : ''}`);
  194 |     const main = page.locator('main');
  195 |     await expect(main).toHaveAttribute('data-hydrated', 'true');
  196 |     test.info().annotations.push({
  197 |       type: 'browser-version',
  198 |       description: page.context().browser()?.version() ?? 'unavailable',
  199 |     });
  200 |     const snapshot = () =>
  201 |       main.evaluate((element) =>
  202 |         (
  203 |           element as HTMLElement & {
  204 |             hostSnapshot(): {
  205 |               boundHost: string | null;
  206 |               registeredHost: string | null;
  207 |               oldOutroEnded: boolean;
  208 |               beforeConnected: boolean;
  209 |               currentConnected: boolean;
  210 |             };
  211 |           }
  212 |         ).hostSnapshot(),
  213 |       );
  214 |     const run = (value: string) =>
  215 |       main.evaluate(
  216 |         (element, command) =>
  217 |           (element as HTMLElement & { hostCommand(value: string): void }).hostCommand(command),
  218 |         value,
  219 |       );
  220 |     const record = async (phase: string) => {
  221 |       const value = {
  222 |         ...(await snapshot()),
  223 |         beforeHostCount: await page.locator('[data-host="before"]').count(),
  224 |         afterHostCount: await page.locator('[data-host="after"]').count(),
  225 |       };
  226 |       await test.info().attach(`host-${phase}`, {
  227 |         body: JSON.stringify(
  228 |           { framework: reference ? 'Original' : 'native', phase, ...value },
  229 |           null,
  230 |           2,
  231 |         ),
  232 |         contentType: 'application/json',
  233 |       });
  234 |       return value;
  235 |     };
  236 |     expect(await record('before')).toMatchObject({ boundHost: 'before', registeredHost: 'before' });
  237 |     await run('swap');
  238 |     await expect(page.locator('[data-host="after"]')).toHaveCount(1);
  239 |     if (!reference) {
  240 |       // Real Svelte out:fade keeps the old actual host mounted while publishing its replacement.
  241 |       await expect(page.locator('[data-host="before"]')).toHaveCount(1);
  242 |     }
  243 |     const overlap = await record('replacement-published');
  244 |     if (!reference)
  245 |       expect(overlap).toMatchObject({ beforeConnected: true, currentConnected: true });
  246 |     expect(overlap).toMatchObject({ boundHost: 'after', registeredHost: 'after' });
  247 |     await expect(page.locator('[data-host="before"]')).toHaveCount(0);
  248 |     await expect(page.locator('[data-host="after"]')).toHaveCount(1);
> 249 |     expect(await record('previous-host-removed')).toMatchObject({
      |                                                   ^ Error: expect(received).toMatchObject(expected)
  250 |       afterHostCount: 1,
  251 |       boundHost: 'after',
  252 |       registeredHost: 'after',
  253 |     });
  254 |     await run('remove');
  255 |     await expect(page.locator('[data-host="after"]')).toHaveCount(0);
  256 |     expect(await record('trigger-removed')).toMatchObject({
  257 |       boundHost: null,
  258 |       registeredHost: null,
  259 |     });
  260 |   });
  261 | }
  262 | 
```