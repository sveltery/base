# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dialog-motion-source.spec.ts >> /dialog: reopening while a physical exit animation is paused aborts that incomplete close
- Location: tests/browser/dialog-motion-source.spec.ts:28:3

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0
```

# Page snapshot

```yaml
- main [ref=e3]:
  - textbox "before" [ref=e4]
  - textbox "final" [ref=e5]
  - button "Owner toggle" [ref=e6]
  - button "Mount toggle" [ref=e7]
  - button "Title toggle" [ref=e8]
  - button "Title ID" [ref=e9]
  - button "Stop deferring" [ref=e10]
  - button "Modality toggle" [ref=e11]
  - button "Imperative close" [ref=e12]
  - button "Imperative unmount" [ref=e13]
  - button "Open" [active] [ref=e14]
  - button "Other open" [ref=e15]
  - textbox "after" [ref=e16]
  - status [ref=e17]: "[{\"channel\":\"click\"},{\"channel\":\"consumer\",\"open\":true,\"reason\":\"trigger-press\",\"trigger\":\"trigger\",\"event\":\"click\",\"before\":false},{\"channel\":\"internal\",\"open\":true,\"reason\":\"trigger-press\"},{\"channel\":\"complete\",\"open\":true},{\"channel\":\"consumer\",\"open\":false,\"reason\":\"escape-key\",\"trigger\":\"trigger\",\"event\":\"keydown\",\"before\":true},{\"channel\":\"internal\",\"open\":false,\"reason\":\"escape-key\"},{\"channel\":\"complete\",\"open\":false}]"
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | // Physical CSS-animation Source/native supplements; no ordinary assertion credit.
  3  | async function completions(page: Page) {
  4  |   return JSON.parse(await page.getByTestId('log').innerText()).filter((entry: { channel: string }) => entry.channel === 'complete').map((entry: { open: boolean }) => entry.open) as boolean[];
  5  | }
  6  | async function setup(page: Page, route: string) {
  7  |   await page.goto(`${route}?keep&animate`);
  8  |   await expect(page.locator('main')).toHaveAttribute('data-hydrated', 'true');
  9  |   await page.locator('#trigger').click();
  10 |   await expect(page.getByRole('dialog')).toBeVisible();
  11 |   await expect.poll(() => completions(page)).toEqual([true]);
  12 | }
  13 | for (const route of ['/dialog', '/reference']) {
  14 |   test(`${route}: returned focus marks a completed close before keyboard reopening starts another close cycle`, async ({ page }) => {
  15 |     await setup(page, route);
  16 |     await page.keyboard.press('Escape');
  17 |     await expect(page.getByTestId('popup')).toHaveAttribute('data-ending-style', '');
  18 |     await expect(page.locator('#trigger')).toBeFocused();
  19 |     await expect.poll(() => completions(page)).toEqual([true, false]);
  20 |     await page.keyboard.press('Enter');
  21 |     await expect(page.getByRole('dialog')).toBeVisible();
  22 |     await expect.poll(() => completions(page)).toEqual([true, false, true]);
  23 |     await page.keyboard.press('Escape');
  24 |     await expect(page.getByRole('dialog')).toHaveCount(0);
  25 |     await expect(page.getByTestId('popup')).toBeHidden();
  26 |     await expect.poll(() => completions(page)).toEqual([true, false, true, false]);
  27 |   });
  28 |   test(`${route}: reopening while a physical exit animation is paused aborts that incomplete close`, async ({ page }) => {
  29 |     await setup(page, route);
  30 |     await page.keyboard.press('Escape');
  31 |     await expect(page.getByTestId('popup')).toHaveAttribute('data-ending-style', '');
  32 |     expect(await page.getByTestId('popup').evaluate(node => {
  33 |       const animations = node.getAnimations(); animations.forEach(animation => animation.pause()); return animations.length;
> 34 |     })).toBeGreaterThan(0);
     |         ^ Error: expect(received).toBeGreaterThan(expected)
  35 |     await expect(page.getByRole('dialog')).toHaveCount(1);
  36 |     await expect(page.getByRole('textbox', { name: 'first', exact: true })).toBeFocused();
  37 |     await page.locator('#trigger').evaluate((button: HTMLButtonElement) => button.click());
  38 |     await expect(page.getByTestId('popup')).toHaveAttribute('data-open', '');
  39 |     await expect.poll(() => completions(page)).toEqual([true, true]);
  40 |     await page.waitForTimeout(250); // Beyond the canceled exit's duration, without an extra close completion.
  41 |     await expect(page.getByRole('dialog')).toBeVisible();
  42 |     expect(await completions(page)).toEqual([true, true]);
  43 |     await page.keyboard.press('Escape');
  44 |     await expect(page.getByRole('dialog')).toHaveCount(0);
  45 |     await expect.poll(() => completions(page)).toEqual([true, true, false]);
  46 |     await expect(page.locator('#trigger')).toBeFocused();
  47 |   });
  48 | }
  49 | 
```