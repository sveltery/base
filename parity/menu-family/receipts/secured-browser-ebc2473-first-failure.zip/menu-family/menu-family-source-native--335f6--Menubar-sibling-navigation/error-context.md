# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: menu-family-source.spec.ts >> native Svelte: ltr/horizontal Menubar sibling navigation
- Location: tests/browser/menu-family-source.spec.ts:65:97

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('#second')
    - locator resolved to <button id="second" type="button" tabindex="-1" role="menuitem" aria-haspopup="menu" aria-disabled="false" aria-expanded="false">…</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <div id="group-label" aria-hidden="true">…</div> from <div id="c1" data-base-ui-portal="">…</div> subtree intercepts pointer events
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <div id="group-label" aria-hidden="true">…</div> from <div id="c1" data-base-ui-portal="">…</div> subtree intercepts pointer events
    - retrying click action
      - waiting 100ms
    56 × waiting for element to be visible, enabled and stable
       - element is visible, enabled and stable
       - scrolling into view if needed
       - done scrolling
       - <div id="group-label" aria-hidden="true">…</div> from <div id="c1" data-base-ui-portal="">…</div> subtree intercepts pointer events
     - retrying click action
       - waiting 500ms

```

# Page snapshot

```yaml
- main [ref=e3]:
  - menubar [ref=e4]:
    - menuitem "File" [expanded] [ref=e5]
    - group:
      - menu "File" [active] [ref=e8]:
        - group "Group label" [ref=e9]:
          - generic [aria-hidden] [ref=e10]: Group label
          - menuitem "Alpha" [ref=e11]
          - menuitem "Disabled" [disabled] [ref=e12]
          - menuitem "Custom Bravo" [ref=e13]
          - menuitem "Link" [ref=e14] [cursor=pointer]
          - menuitemcheckbox "Check" [ref=e15]
          - group "Radios" [ref=e16]:
            - generic [aria-hidden] [ref=e17]: Radios
            - menuitemradio "One" [checked] [ref=e18]:
              - text: One
              - generic [aria-hidden] [ref=e19]: ✓
            - menuitemradio "Two" [ref=e20]
    - menuitem "Edit" [ref=e23]
  - button "Outside" [ref=e24]
```

# Test source

```ts
  1   | // Authored paired supplements using actual Base UI 1.8.0 and native Svelte.
  2   | // All declarations receive zero unchanged Original ordinary assertion credit.
  3   | import { expect, test, type Page } from '@playwright/test';
  4   | async function setup(page: Page, reference: boolean, options: Record<string, string> = {}) {
  5   |   const parameters = new URLSearchParams(options);
  6   |   if (reference) parameters.set('reference', '');
  7   |   await page.goto(`/menu-family?${parameters}`);
  8   |   await expect(page.locator('main')).toHaveAttribute('data-hydrated', 'true');
  9   |   test.info().annotations.push({ type: 'browser-version', description: page.context().browser()?.version() ?? 'unavailable' });
  10  | }
  11  | async function command(page: Page, value: string) {
  12  |   await page.locator('main').evaluate((element, argument) => {
  13  |     (element as HTMLElement & { menuCommand(value: string): void }).menuCommand(argument);
  14  |   }, value);
  15  | }
  16  | async function calls(page: Page) {
  17  |   return page.locator('main').evaluate(element => {
  18  |     return (element as HTMLElement & { menuSnapshot(): { calls: unknown[] } }).menuSnapshot().calls;
  19  |   });
  20  | }
  21  | for (const reference of [false, true]) {
  22  |   const framework = reference ? 'Original React' : 'native Svelte';
  23  |   test(`${framework}: trusted mouse opens, navigates disabled items, typeahead and selection`, async ({ page }) => {
  24  |     await setup(page, reference); await page.locator('#opener').click();
  25  |     await expect(page.locator('[data-testid=popup]')).toBeVisible();
  26  |     await expect(page.locator('#opener')).toHaveAttribute('aria-haspopup', 'menu');
  27  |     await expect(page.locator('#group')).toHaveAttribute('aria-labelledby', 'group-label');
  28  |     await expect(page.locator('#radio-group')).toHaveAttribute('aria-labelledby', 'radio-label');
  29  |     await page.keyboard.press('ArrowDown'); await expect(page.locator('#alpha')).toBeFocused();
  30  |     await page.keyboard.press('ArrowDown'); await expect(page.locator('#disabled')).toBeFocused();
  31  |     await page.keyboard.press('Enter'); await expect(page.locator('[data-testid=popup]')).toBeVisible();
  32  |     await page.keyboard.press('b'); await expect(page.locator('#bravo')).toBeFocused();
  33  |     await page.keyboard.press('Enter'); await expect(page.locator('[data-testid=popup]')).toHaveCount(0);
  34  |     await expect(page.locator('#opener')).toBeFocused();
  35  |     expect(await calls(page)).toContainEqual(['open', false, 'item-press']);
  36  |   });
  37  |   for (const key of ['Enter', 'Space', 'ArrowDown', 'ArrowUp']) test(`${framework}: keyboard ${key} trigger opening`, async ({ page }) => {
  38  |     await setup(page, reference); await page.locator('#opener').focus(); await page.keyboard.press(key);
  39  |     await expect(page.locator('[data-testid=popup]')).toBeVisible();
  40  |     await expect(page.locator(key === 'ArrowUp' ? '#two' : '#alpha')).toBeFocused();
  41  |     await page.keyboard.press('Escape'); await expect(page.locator('[data-testid=popup]')).toHaveCount(0);
  42  |     await expect(page.locator('#opener')).toBeFocused();
  43  |   });
  44  |   for (const cancel of ['', 'check', 'radio']) test(`${framework}: selection callback cancellation ${cancel || 'accepted'}`, async ({ page }) => {
  45  |     await setup(page, reference, { open: '', cancel });
  46  |     await page.locator('#check').click(); await expect(page.locator('#check')).toHaveAttribute('aria-checked', cancel === 'check' ? 'false' : 'true');
  47  |     await page.locator('#two').click(); await expect(page.locator('#two')).toHaveAttribute('aria-checked', cancel === 'radio' ? 'false' : 'true');
  48  |     await expect(page.locator('[data-testid=popup]')).toBeVisible();
  49  |   });
  50  |   for (const cancel of ['open', 'close']) test(`${framework}: root ${cancel} cancellation`, async ({ page }) => {
  51  |     await setup(page, reference, { ...(cancel === 'close' ? { open: '' } : {}), cancel });
  52  |     await page.locator('#opener').click();
  53  |     await expect(page.locator('[data-testid=popup]')).toHaveCount(cancel === 'close' ? 1 : 0);
  54  |   });
  55  |   for (const direction of ['ltr', 'rtl']) test(`${framework}: three nested levels and ${direction} arrow relay`, async ({ page }) => {
  56  |     await setup(page, reference, { mode: 'nested', open: '', direction });
  57  |     await page.locator('#sub').focus(); await page.keyboard.press(direction === 'rtl' ? 'ArrowLeft' : 'ArrowRight');
  58  |     await expect(page.locator('#sub-first')).toBeFocused();
  59  |     await page.keyboard.press('ArrowDown'); await expect(page.locator('#deep')).toBeFocused();
  60  |     await page.keyboard.press(direction === 'rtl' ? 'ArrowLeft' : 'ArrowRight'); await expect(page.locator('#deep-first')).toBeFocused();
  61  |     await page.keyboard.press('Escape'); await expect(page.locator('#deep-first')).toHaveCount(0); await expect(page.locator('#deep')).toBeFocused();
  62  |     await page.keyboard.press('Escape'); await expect(page.locator('[data-testid=sub-popup]')).toHaveCount(0);
  63  |     await expect(page.locator('[data-testid=popup]')).toBeVisible(); await expect(page.locator('#sub')).toBeFocused();
  64  |   });
  65  |   for (const orientation of ['horizontal', 'vertical']) for (const direction of ['ltr', 'rtl']) test(`${framework}: ${direction}/${orientation} Menubar sibling navigation`, async ({ page }) => {
  66  |     await setup(page, reference, { mode: 'menubar', orientation, direction });
  67  |     await page.locator('#opener').click(); await expect(page.locator('[data-testid=popup]')).toBeVisible();
> 68  |     await page.locator('#second').click(); await expect(page.locator('[data-testid=popup]')).toHaveCount(0);
      |                                   ^ Error: locator.click: Test timeout of 30000ms exceeded.
  69  |     await expect(page.locator('[data-testid=edit-popup]')).toBeVisible();
  70  |     await expect(page.locator('#menubar')).toHaveAttribute('data-has-submenu-open', '');
  71  |     await page.keyboard.press('Escape'); await expect(page.locator('[data-testid=edit-popup]')).toHaveCount(0);
  72  |     await expect(page.locator('#second')).toBeFocused();
  73  |     await page.keyboard.press(orientation === 'vertical' ? 'ArrowUp' : direction === 'rtl' ? 'ArrowRight' : 'ArrowLeft');
  74  |     await expect(page.locator('#opener')).toBeFocused();
  75  |   });
  76  |   test(`${framework}: retained actions keep mounted exit until unmount`, async ({ page }) => {
  77  |     await setup(page, reference, { mode: 'retain' }); await page.locator('#opener').click();
  78  |     await expect(page.locator('[data-testid=popup]')).toBeVisible(); await command(page, 'close');
  79  |     await expect(page.locator('[data-testid=popup]')).toHaveAttribute('data-closed', '');
  80  |     await command(page, 'unmount'); await expect(page.locator('[data-testid=popup]')).toHaveCount(0);
  81  |   });
  82  |   test(`${framework}: detached handle trigger ownership and payload viewport remount`, async ({ page }) => {
  83  |     await setup(page, reference, { mode: 'viewport' }); await command(page, 'open');
  84  |     await expect(page.locator('#payload')).toHaveText('7'); await expect(page.locator('#opener')).toHaveAttribute('aria-expanded', 'true');
  85  |     await command(page, 'second'); await expect(page.locator('[data-current] #payload')).toHaveText('9');
  86  |     await expect(page.locator('[data-previous]')).toHaveAttribute('inert', '');
  87  |     await expect(page.locator('[data-previous] #payload')).toHaveText('7');
  88  |     await expect(page.locator('#second')).toHaveAttribute('aria-expanded', 'true'); await expect(page.locator('#opener')).toHaveAttribute('aria-expanded', 'false');
  89  |     await expect(page.locator('[data-previous]')).toHaveCount(0); await command(page, 'close');
  90  |     await expect(page.locator('[data-testid=popup]')).toHaveCount(0);
  91  |   });
  92  |   test(`${framework}: ContextMenu uses trusted pointer anchor, outside release and Escape`, async ({ page }) => {
  93  |     await setup(page, reference, { mode: 'context' }); await page.locator('#opener').click({ button: 'right', position: { x: 15, y: 10 } });
  94  |     await expect(page.locator('[data-testid=popup]')).toBeVisible();
  95  |     await expect(page.locator('[data-testid=positioner]')).toHaveCSS('position', 'fixed');
  96  |     await page.keyboard.press('ArrowDown'); await expect(page.locator('#alpha')).toBeFocused();
  97  |     await page.keyboard.press('Escape'); await expect(page.locator('[data-testid=popup]')).toHaveCount(0);
  98  |   });
  99  |   test(`${framework}: hover opens after rest and mouse exit dismisses`, async ({ page }) => {
  100 |     await setup(page, reference, { mode: 'hover' }); await page.locator('#opener').hover();
  101 |     await expect(page.locator('[data-testid=popup]')).toBeVisible(); await page.locator('#outside').hover();
  102 |     await expect(page.locator('[data-testid=popup]')).toHaveCount(0);
  103 |   });
  104 |   test(`${framework}: Toolbar menu restores composite focus and arrow relay`, async ({ page }) => {
  105 |     await setup(page, reference, { mode: 'toolbar' }); await page.locator('#opener').focus(); await page.keyboard.press('Enter');
  106 |     await expect(page.locator('#alpha')).toBeFocused(); await page.keyboard.press('Escape'); await expect(page.locator('#opener')).toBeFocused();
  107 |     await page.keyboard.press('ArrowRight'); await expect(page.locator('#after')).toBeFocused();
  108 |   });
  109 |   test(`${framework}: modal menu locks scroll and outside pointer dismisses`, async ({ page }) => {
  110 |     await setup(page, reference, { mode: 'modal' }); await page.locator('#opener').click();
  111 |     await expect(page.locator('[data-testid=popup]')).toBeVisible();
  112 |     expect(await page.evaluate(() => document.documentElement.style.overflow || document.body.style.overflow)).toBe('hidden');
  113 |     await page.mouse.click(600, 400); await expect(page.locator('[data-testid=popup]')).toHaveCount(0);
  114 |   });
  115 | }
  116 | 
```