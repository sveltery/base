    it('syncs replacement refs without publishing an unchanged map', async () => {
      const firstElementsRef = {
        current: [] as Array<HTMLElement | null>,
      };
      const secondElementsRef = {
        current: [null, null] as Array<HTMLElement | null>,
      };
      const firstLabelsRef = {
        current: [] as Array<string | null>,
      };
      const secondLabelsRef = {
        current: [null, null] as Array<string | null>,
      };
      const onMapChange = vi.fn();

      function UnstableRefItem() {
        const internalRef = React.useRef<HTMLElement | null>(null);
        const { ref } = useCompositeListItem({ label: 'item' });

        return <div ref={mergeRefs(ref, internalRef)} data-testid="item" />;
      }

      function App() {
        const [useSecondRef, setUseSecondRef] = React.useState(false);
        return (
          <CompositeList
            elementsRef={useSecondRef ? secondElementsRef : firstElementsRef}
            labelsRef={useSecondRef ? secondLabelsRef : firstLabelsRef}
            onMapChange={onMapChange}
          >
            <button type="button" onClick={() => setUseSecondRef(true)}>
              Replace ref
            </button>
            <UnstableRefItem />
          </CompositeList>
        );
      }

      const { user } = await render(<App />);
      const item = screen.getByTestId('item');
      expect(firstElementsRef.current).toEqual([item]);
      expect(firstLabelsRef.current).toEqual(['item']);
      onMapChange.mockClear();

      await user.click(screen.getByRole('button', { name: 'Replace ref' }));

      expect(firstElementsRef.current).toEqual([]);
      expect(firstLabelsRef.current).toEqual([]);
      expect(secondElementsRef.current).toEqual([item]);
      expect(secondLabelsRef.current).toEqual(['item']);
      expect(onMapChange).not.toHaveBeenCalled();
    });

