import 'svelte/internal/disclose-version';
import * as $ from 'svelte/internal/client';
import { fade } from 'svelte/transition';
import { NumberField } from '@sveltery/base/number-field';

var root = $.from_html(`<button>Outgoing increase</button>`);
var root_1 = $.from_html(`<button>Replacement increase</button>`);
var root_2 = $.from_html(`<!> <!>`, 1);
var root_3 = $.from_html(`<!> <button id="owner-publish-replacement">Publish replacement</button> <button id="owner-dispose-outgoing">Dispose outgoing</button> <button id="owner-begin-outro">Replace with native outro</button> <button id="owner-require-nonnative">Require nonnative host</button> <button id="owner-require-native">Require native host</button> <output id="owner-published-host"> </output> <output id="owner-outro-state"> </output>`, 1);

export default function NumberFieldStepperOwnerBrowserFixture($$anchor, $$props) {
	const // Native owner lifetime supplement; no unchanged upstream assertion credit.
	hosts = ($$anchor, props = $.noop) => {
		var fragment = root_2();
		var node = $.first_child(fragment);

		{
			var consequent_1 = ($$anchor) => {
				var fragment_1 = $.comment();
				var node_1 = $.first_child(fragment_1);

				{
					var consequent = ($$anchor) => {
						var button = root();

						var event_handler = () => {
							$.set(outroStarted, $.get(outroStarted) + 1);
						};

						var event_handler_1 = () => {
							$.set(outroEnded, $.get(outroEnded) + 1);
						};

						$.attribute_effect(button, () => ({
							...props(),
							'data-owner-host': 'A',
							onoutrostart: event_handler,
							onoutroend: event_handler_1
						}));

						$.transition(2, button, () => fade, () => ({ duration: 1200 }));
						$.append($$anchor, button);
					};

					var alternate = ($$anchor) => {
						var button_1 = root();

						$.attribute_effect(button_1, () => ({ ...props(), 'data-owner-host': 'A' }));
						$.append($$anchor, button_1);
					};

					$.if(node_1, ($$render) => {
						if ($$props.scenario === 'stepper-owner-outro') $$render(consequent); else $$render(alternate, -1);
					});
				}

				$.append($$anchor, fragment_1);
			};

			$.if(node, ($$render) => {
				if ($.get(stage) < 3) $$render(consequent_1);
			});
		}

		var node_2 = $.sibling(node, 2);

		{
			var consequent_2 = ($$anchor) => {
				var button_2 = root_1();

				$.attribute_effect(button_2, () => ({ ...props(), 'data-owner-host': 'B' }));
				$.append($$anchor, button_2);
			};

			$.if(node_2, ($$render) => {
				if ($.get(stage) > 1) $$render(consequent_2);
			});
		}

		$.append($$anchor, fragment);
	};

	let stage = $.state(1);
	let nativeButton = $.state(true);
	let publishedHost = $.state(void 0);
	let outroStarted = $.state(0);
	let outroEnded = $.state(0);
	var fragment_2 = root_3();
	var node_3 = $.first_child(fragment_2);

	$.component(node_3, () => NumberField.Root, ($$anchor, NumberField_Root) => {
		NumberField_Root($$anchor, {
			defaultValue: 2,
			locale: 'en-US',
			children: ($$anchor, $$slotProps) => {
				var fragment_3 = root_2();
				var node_4 = $.first_child(fragment_3);

				$.component(node_4, () => NumberField.Input, ($$anchor, NumberField_Input) => {
					NumberField_Input($$anchor, {});
				});

				var node_5 = $.sibling(node_4, 2);

				$.component(node_5, () => NumberField.Increment, ($$anchor, NumberField_Increment) => {
					NumberField_Increment($$anchor, {
						get nativeButton() {
							return $.get(nativeButton);
						},

						get render() {
							return hosts;
						},

						get ref() {
							return $.get(publishedHost);
						},

						set ref($$value) {
							$.set(publishedHost, $$value, true);
						}
					});
				});

				$.append($$anchor, fragment_3);
			},
			$$slots: { default: true }
		});
	});

	var button_3 = $.sibling(node_3, 2);
	var button_4 = $.sibling(button_3, 2);
	var button_5 = $.sibling(button_4, 2);
	var button_6 = $.sibling(button_5, 2);
	var button_7 = $.sibling(button_6, 2);
	var output = $.sibling(button_7, 2);
	var text = $.only_child(output, true);
	var output_1 = $.sibling(output, 2);
	var text_1 = $.only_child(output_1, true);

	$.template_effect(
		($0) => {
			$.set_text(text, $.get(publishedHost)?.dataset.ownerHost ?? 'none');
			$.set_text(text_1, $0);
		},
		[
			() => JSON.stringify({ started: $.get(outroStarted), ended: $.get(outroEnded) })
		]
	);

	$.delegated('click', button_3, () => {
		$.set(stage, 2);
	});

	$.delegated('click', button_4, () => {
		$.set(stage, 3);
	});

	$.delegated('click', button_5, () => {
		$.set(stage, 3);
	});

	$.delegated('click', button_6, () => {
		$.set(nativeButton, false);
	});

	$.delegated('click', button_7, () => {
		$.set(nativeButton, true);
	});

	$.append($$anchor, fragment_2);
}

$.delegate(['click']);