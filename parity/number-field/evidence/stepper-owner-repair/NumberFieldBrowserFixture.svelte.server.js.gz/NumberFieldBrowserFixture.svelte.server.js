import * as $ from 'svelte/internal/server';
import { onMount, untrack } from 'svelte';
import NumberFieldStepperOwnerBrowserFixture from './NumberFieldStepperOwnerBrowserFixture.svelte';
import { NumberField } from '@sveltery/base/number-field';
import { Field } from '@sveltery/base/field';
import { Form } from '@sveltery/base/form';

function inputReplacement($$renderer, props) {
	$$renderer.push(`<input${$.attributes({ ...props, 'data-replacement': 'true' }, void 0, void 0, void 0, 4)}/>`);
}

export default function NumberFieldBrowserFixture($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		// Actual NumberField family witness; native framework supplements earn zero ordinary credit.
		let { scenario: scenarioProp = 'default' } = $$props;

		const scenario = untrack(() => scenarioProp);

		const initial = scenario.includes('empty')
			? undefined
			: scenario.includes('rounding-blur')
				? 1.234
				: scenario.includes('precision') ? 1.23456789 : scenario === 'percent' ? 0.12 : 2;

		const controlled = scenario.includes('controlled');
		let owner = initial ?? null;
		let hydrated = false;
		let shown = true;
		let replacement = scenario.includes('replacement');
		let traces = [];
		let submissions = [];
		let validationCalls = [];
		let rootRef = void 0;
		let visibleRef = void 0;
		let hiddenRef = null;

		const options = {
			locale: scenario === 'currency' ? 'de-DE' : 'en-US',
			allowWheelScrub: true,
			...scenario.includes('bounds') || scenario.includes('outofrange') ? { min: 0, max: 5 } : {},
			...scenario.includes('outofrange') ? { allowOutOfRange: true } : {},
			...scenario.includes('negative') ? { min: -10, max: -3 } : {},
			...scenario.includes('precision') ? { step: 0.1 } : {},
			...scenario.includes('rounding-blur')
				? { step: 'any', format: { maximumFractionDigits: 2 } }
				: {},
			...scenario === 'snap' ? { min: 0.3, step: 0.2, snapOnStep: true } : {},
			...scenario === 'currency'
				? { format: { style: 'currency', currency: 'EUR' } }
				: {},
			...scenario === 'percent' ? { format: { style: 'percent' } } : {},
			...scenario.includes('readonly') ? { readOnly: true } : {},
			...scenario.includes('disabled') ? { disabled: true } : {},
			...scenario.includes('required') ? { required: true } : {},
			...scenario === 'external-form' ? { form: 'external-number-form' } : {}
		};

		function changed(value, details) {
			traces.push({
				kind: 'change',
				value,
				reason: details.reason,
				direction: details.direction,
				type: details.event.type
			});

			if (scenario.includes('cancel')) details.cancel();
			if (controlled && !scenario.includes('reject') && !details.isCanceled) owner = value;
		}

		function committed(value, details) {
			traces.push({
				kind: 'commit',
				value,
				reason: details.reason,
				type: details.event.type
			});
		}

		function validate(value, values) {
			validationCalls.push({ value, values });

			if (scenario.includes('rounding-blur')) return scenario.includes('async')
				? Promise.resolve('Rounded amount rejected')
				: 'Rounded amount rejected';

			return value === 7 ? 'Seven unavailable' : null;
		}

		onMount(() => {
			hydrated = true;
		});

		let $$settled = true;
		let $$inner_renderer;

		function $$render_inner($$renderer) {
			$$renderer.push(`<main${$.attr('data-hydrated', hydrated)} data-renderer="svelte-5.57.1">`);

			if (scenario.startsWith('stepper-owner')) {
				$$renderer.push('<!--[0-->');
				NumberFieldStepperOwnerBrowserFixture($$renderer, { scenario });
			} else {
				$$renderer.push('<!--[-1-->');
			}

			$$renderer.push(`<!--]--> `);

			Form($$renderer, {
				id: 'number-form',
				validationMode: scenario === 'validation' || scenario.includes('rounding-blur') ? 'onBlur' : 'onSubmit',
				onFormSubmit: (values) => {
					submissions.push(values);
				},

				children: ($$renderer) => {
					if (Field.Root) {
						$$renderer.push('<!--[-->');

						Field.Root($$renderer, {
							name: 'amount',
							id: 'number-field',
							validate: scenario === 'validation' || scenario.includes('rounding-blur') ? validate : undefined,
							children: ($$renderer) => {
								if (Field.Label) {
									$$renderer.push('<!--[-->');

									Field.Label($$renderer, {
										id: 'amount-label',
										children: ($$renderer) => {
											$$renderer.push(`<!---->Amount`);
										},
										$$slots: { default: true }
									});

									$$renderer.push('<!--]-->');
								} else {
									$$renderer.push('<!--[!-->');
									$$renderer.push('<!--]-->');
								}

								$$renderer.push(` `);

								if (Field.Description) {
									$$renderer.push('<!--[-->');

									Field.Description($$renderer, {
										id: 'amount-description',
										children: ($$renderer) => {
											$$renderer.push(`<!---->A numeric amount`);
										},
										$$slots: { default: true }
									});

									$$renderer.push('<!--]-->');
								} else {
									$$renderer.push('<!--[!-->');
									$$renderer.push('<!--]-->');
								}

								$$renderer.push(` `);

								if (shown) {
									$$renderer.push('<!--[0-->');

									if (NumberField.Root) {
										$$renderer.push('<!--[-->');

										NumberField.Root($$renderer, $.spread_props([
											{ id: 'amount-input' },
											options,
											{
												defaultValue: initial,
												value: controlled ? owner : undefined,
												onValueChange: changed,
												onValueCommitted: committed,
												get inputRef() {
													return hiddenRef;
												},

												set inputRef($$value) {
													hiddenRef = $$value;
													$$settled = false;
												},

												get ref() {
													return rootRef;
												},

												set ref($$value) {
													rootRef = $$value;
													$$settled = false;
												},

												children: ($$renderer) => {
													if (NumberField.Group) {
														$$renderer.push('<!--[-->');

														NumberField.Group($$renderer, {
															id: 'number-group',
															children: ($$renderer) => {
																if (NumberField.Decrement) {
																	$$renderer.push('<!--[-->');

																	NumberField.Decrement($$renderer, {
																		id: 'decrease',
																		children: ($$renderer) => {
																			$$renderer.push(`<!---->Decrease`);
																		},
																		$$slots: { default: true }
																	});

																	$$renderer.push('<!--]-->');
																} else {
																	$$renderer.push('<!--[!-->');
																	$$renderer.push('<!--]-->');
																}

																$$renderer.push(` `);

																if (NumberField.Input) {
																	$$renderer.push('<!--[-->');

																	NumberField.Input($$renderer, {
																		'data-testid': 'visible',
																		oninput: (event) => {
																			if (scenario === 'prevent-input') event.preventBaseUIHandler();
																		},

																		onkeydown: (event) => {
																			if (scenario === 'prevent-key') event.preventBaseUIHandler();
																		},
																		render: replacement ? inputReplacement : undefined,
																		get ref() {
																			return visibleRef;
																		},

																		set ref($$value) {
																			visibleRef = $$value;
																			$$settled = false;
																		}
																	});

																	$$renderer.push('<!--]-->');
																} else {
																	$$renderer.push('<!--[!-->');
																	$$renderer.push('<!--]-->');
																}

																$$renderer.push(` `);

																if (NumberField.Increment) {
																	$$renderer.push('<!--[-->');

																	NumberField.Increment($$renderer, {
																		id: 'increase',
																		children: ($$renderer) => {
																			$$renderer.push(`<!---->Increase`);
																		},
																		$$slots: { default: true }
																	});

																	$$renderer.push('<!--]-->');
																} else {
																	$$renderer.push('<!--[!-->');
																	$$renderer.push('<!--]-->');
																}
															},
															$$slots: { default: true }
														});

														$$renderer.push('<!--]-->');
													} else {
														$$renderer.push('<!--[!-->');
														$$renderer.push('<!--]-->');
													}

													$$renderer.push(` `);

													if (NumberField.ScrubArea) {
														$$renderer.push('<!--[-->');

														NumberField.ScrubArea($$renderer, {
															'data-testid': 'scrub',
															children: ($$renderer) => {
																if (NumberField.ScrubAreaCursor) {
																	$$renderer.push('<!--[-->');

																	NumberField.ScrubAreaCursor($$renderer, {
																		'data-testid': 'cursor',
																		children: ($$renderer) => {
																			$$renderer.push(`<!---->Cursor`);
																		},
																		$$slots: { default: true }
																	});

																	$$renderer.push('<!--]-->');
																} else {
																	$$renderer.push('<!--[!-->');
																	$$renderer.push('<!--]-->');
																}

																$$renderer.push(`Scrub`);
															},
															$$slots: { default: true }
														});

														$$renderer.push('<!--]-->');
													} else {
														$$renderer.push('<!--[!-->');
														$$renderer.push('<!--]-->');
													}
												},
												$$slots: { default: true }
											}
										]));

										$$renderer.push('<!--]-->');
									} else {
										$$renderer.push('<!--[!-->');
										$$renderer.push('<!--]-->');
									}
								} else {
									$$renderer.push('<!--[-1-->');
								}

								$$renderer.push(`<!--]--> `);

								if (Field.Error) {
									$$renderer.push('<!--[-->');
									Field.Error($$renderer, { id: 'number-error' });
									$$renderer.push('<!--]-->');
								} else {
									$$renderer.push('<!--[!-->');
									$$renderer.push('<!--]-->');
								}

								$$renderer.push(` `);

								{
									function children($$renderer, state) {
										$$renderer.push(`<output id="validity">${$.escape(JSON.stringify(state))}</output>`);
									}

									if (Field.Validity) {
										$$renderer.push('<!--[-->');
										Field.Validity($$renderer, { children, $$slots: { default: true } });
										$$renderer.push('<!--]-->');
									} else {
										$$renderer.push('<!--[!-->');
										$$renderer.push('<!--]-->');
									}
								}
							},
							$$slots: { default: true }
						});

						$$renderer.push('<!--]-->');
					} else {
						$$renderer.push('<!--[!-->');
						$$renderer.push('<!--]-->');
					}

					$$renderer.push(` <button id="submit" type="submit">Submit</button><button id="reset" type="reset">Reset</button>`);
				},
				$$slots: { default: true }
			});

			$$renderer.push(`<!----> <form id="external-number-form"></form> <button id="outside">Outside</button> <button id="owner-update">Owner update</button> <button id="replace-input">Replace input</button> <button id="toggle-root">Toggle root</button> <output id="number-traces">${$.escape(JSON.stringify(traces))}</output> <output id="number-submissions">${$.escape(JSON.stringify(submissions))}</output> <output id="number-validation-calls">${$.escape(JSON.stringify(validationCalls))}</output> <output id="ref-state">${$.escape(JSON.stringify({
				root: rootRef?.isConnected ?? false,
				visible: visibleRef?.isConnected ?? false,
				hidden: hiddenRef?.isConnected ?? false
			}))}</output></main>`);
		}

		do {
			$$settled = true;
			$$inner_renderer = $$renderer.copy();
			$$render_inner($$inner_renderer);
		} while (!$$settled);

		$$renderer.subsume($$inner_renderer);
	});
}