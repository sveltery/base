import 'svelte/internal/disclose-version';
import * as $ from 'svelte/internal/client';
import { onMount, untrack } from 'svelte';
import NumberFieldStepperOwnerBrowserFixture from './NumberFieldStepperOwnerBrowserFixture.svelte';
import { NumberField } from '@sveltery/base/number-field';
import { Field } from '@sveltery/base/field';
import { Form } from '@sveltery/base/form';

const inputReplacement = ($$anchor, props = $.noop) => {
	var input = root();

	$.attribute_effect(input, () => ({ ...props(), 'data-replacement': 'true' }), void 0, void 0, void 0, void 0, true);
	$.append($$anchor, input);
};

var root = $.from_html(`<input/>`);
var root_1 = $.from_html(`<!> <!> <!>`, 1);
var root_2 = $.from_html(`<!>Scrub`, 1);
var root_3 = $.from_html(`<!> <!>`, 1);
var root_4 = $.from_html(`<output id="validity"> </output>`);
var root_5 = $.from_html(`<!> <!> <!> <!> <!>`, 1);
var root_6 = $.from_html(`<!> <button id="submit" type="submit">Submit</button><button id="reset" type="reset">Reset</button>`, 1);
var root_7 = $.from_html(`<main data-renderer="svelte-5.57.1"><!> <!> <form id="external-number-form"></form> <button id="outside">Outside</button> <button id="owner-update">Owner update</button> <button id="replace-input">Replace input</button> <button id="toggle-root">Toggle root</button> <output id="number-traces"> </output> <output id="number-submissions"> </output> <output id="number-validation-calls"> </output> <output id="ref-state"> </output></main>`);

export default function NumberFieldBrowserFixture($$anchor, $$props) {
	$.push($$props, true);

	// Actual NumberField family witness; native framework supplements earn zero ordinary credit.
	let scenarioProp = $.prop($$props, 'scenario', 3, 'default');

	const scenario = untrack(() => scenarioProp());

	const initial = scenario.includes('empty')
		? undefined
		: scenario.includes('rounding-blur')
			? 1.234
			: scenario.includes('precision') ? 1.23456789 : scenario === 'percent' ? 0.12 : 2;

	const controlled = scenario.includes('controlled');
	let owner = $.state($.proxy(initial ?? null));
	let hydrated = $.state(false);
	let shown = $.state(true);
	let replacement = $.state($.proxy(scenario.includes('replacement')));
	let traces = $.proxy([]);
	let submissions = $.proxy([]);
	let validationCalls = $.proxy([]);
	let rootRef = $.state(void 0);
	let visibleRef = $.state(void 0);
	let hiddenRef = $.state(null);

	const options = {
		locale: scenario === 'currency' ? 'de-DE' : 'en-US',
		allowWheelScrub: true,
		...scenario.includes('bounds') || scenario.includes('outofrange') ? { min: 0, max: 5 } : {},
		...scenario.includes('outofrange') ? { allowOutOfRange: true } : {},
		...scenario.includes('negative') ? { min: -10, max: -3 } : {},
		...scenario.includes('precision') ? { step: 0.1 } : {},
		...scenario.includes('rounding-blur')
			? { step: 'any', format: { maximumFractionDigits: 2 } }
			: {},
		...scenario === 'snap' ? { min: 0.3, step: 0.2, snapOnStep: true } : {},
		...scenario === 'currency'
			? { format: { style: 'currency', currency: 'EUR' } }
			: {},
		...scenario === 'percent' ? { format: { style: 'percent' } } : {},
		...scenario.includes('readonly') ? { readOnly: true } : {},
		...scenario.includes('disabled') ? { disabled: true } : {},
		...scenario.includes('required') ? { required: true } : {},
		...scenario === 'external-form' ? { form: 'external-number-form' } : {}
	};

	function changed(value, details) {
		traces.push({
			kind: 'change',
			value,
			reason: details.reason,
			direction: details.direction,
			type: details.event.type
		});

		if (scenario.includes('cancel')) details.cancel();
		if (controlled && !scenario.includes('reject') && !details.isCanceled) $.set(owner, value, true);
	}

	function committed(value, details) {
		traces.push({
			kind: 'commit',
			value,
			reason: details.reason,
			type: details.event.type
		});
	}

	function validate(value, values) {
		validationCalls.push({ value, values });

		if (scenario.includes('rounding-blur')) return scenario.includes('async')
			? Promise.resolve('Rounded amount rejected')
			: 'Rounded amount rejected';

		return value === 7 ? 'Seven unavailable' : null;
	}

	onMount(() => {
		$.set(hydrated, true);
	});

	var main = root_7();
	var node = $.child(main);

	{
		var consequent = ($$anchor) => {
			NumberFieldStepperOwnerBrowserFixture($$anchor, {
				get scenario() {
					return scenario;
				}
			});
		};

		var d = $.derived(() => scenario.startsWith('stepper-owner'));

		$.if(node, ($$render) => {
			if ($.get(d)) $$render(consequent);
		});
	}

	var node_1 = $.sibling(node, 2);

	{
		let $0 = $.derived(() => scenario === 'validation' || scenario.includes('rounding-blur') ? 'onBlur' : 'onSubmit');

		Form(node_1, {
			id: 'number-form',
			get validationMode() {
				return $.get($0);
			},

			onFormSubmit: (values) => {
				submissions.push(values);
			},

			children: ($$anchor, $$slotProps) => {
				var fragment_1 = root_6();
				var node_2 = $.first_child(fragment_1);

				{
					let $0 = $.derived(() => scenario === 'validation' || scenario.includes('rounding-blur') ? validate : undefined);

					$.component(node_2, () => Field.Root, ($$anchor, Field_Root) => {
						Field_Root($$anchor, {
							name: 'amount',
							id: 'number-field',
							get validate() {
								return $.get($0);
							},

							children: ($$anchor, $$slotProps) => {
								var fragment_2 = root_5();
								var node_3 = $.first_child(fragment_2);

								$.component(node_3, () => Field.Label, ($$anchor, Field_Label) => {
									Field_Label($$anchor, {
										id: 'amount-label',
										children: ($$anchor, $$slotProps) => {
											$.next();

											var text = $.text('Amount');

											$.append($$anchor, text);
										},
										$$slots: { default: true }
									});
								});

								var node_4 = $.sibling(node_3, 2);

								$.component(node_4, () => Field.Description, ($$anchor, Field_Description) => {
									Field_Description($$anchor, {
										id: 'amount-description',
										children: ($$anchor, $$slotProps) => {
											$.next();

											var text_1 = $.text('A numeric amount');

											$.append($$anchor, text_1);
										},
										$$slots: { default: true }
									});
								});

								var node_5 = $.sibling(node_4, 2);

								{
									var consequent_1 = ($$anchor) => {
										var fragment_3 = $.comment();
										var node_6 = $.first_child(fragment_3);

										{
											let $0 = $.derived(() => controlled ? $.get(owner) : undefined);

											$.component(node_6, () => NumberField.Root, ($$anchor, NumberField_Root) => {
												NumberField_Root($$anchor, $.spread_props({ id: 'amount-input' }, () => options, {
													get defaultValue() {
														return initial;
													},

													get value() {
														return $.get($0);
													},
													onValueChange: changed,
													onValueCommitted: committed,
													get inputRef() {
														return $.get(hiddenRef);
													},

													set inputRef($$value) {
														$.set(hiddenRef, $$value, true);
													},

													get ref() {
														return $.get(rootRef);
													},

													set ref($$value) {
														$.set(rootRef, $$value, true);
													},

													children: ($$anchor, $$slotProps) => {
														var fragment_4 = root_3();
														var node_7 = $.first_child(fragment_4);

														$.component(node_7, () => NumberField.Group, ($$anchor, NumberField_Group) => {
															NumberField_Group($$anchor, {
																id: 'number-group',
																children: ($$anchor, $$slotProps) => {
																	var fragment_5 = root_1();
																	var node_8 = $.first_child(fragment_5);

																	$.component(node_8, () => NumberField.Decrement, ($$anchor, NumberField_Decrement) => {
																		NumberField_Decrement($$anchor, {
																			id: 'decrease',
																			children: ($$anchor, $$slotProps) => {
																				$.next();

																				var text_2 = $.text('Decrease');

																				$.append($$anchor, text_2);
																			},
																			$$slots: { default: true }
																		});
																	});

																	var node_9 = $.sibling(node_8, 2);

																	{
																		let $0 = $.derived(() => $.get(replacement) ? inputReplacement : undefined);

																		$.component(node_9, () => NumberField.Input, ($$anchor, NumberField_Input) => {
																			NumberField_Input($$anchor, {
																				'data-testid': 'visible',
																				oninput: (event) => {
																					if (scenario === 'prevent-input') event.preventBaseUIHandler();
																				},

																				onkeydown: (event) => {
																					if (scenario === 'prevent-key') event.preventBaseUIHandler();
																				},

																				get render() {
																					return $.get($0);
																				},

																				get ref() {
																					return $.get(visibleRef);
																				},

																				set ref($$value) {
																					$.set(visibleRef, $$value, true);
																				}
																			});
																		});
																	}

																	var node_10 = $.sibling(node_9, 2);

																	$.component(node_10, () => NumberField.Increment, ($$anchor, NumberField_Increment) => {
																		NumberField_Increment($$anchor, {
																			id: 'increase',
																			children: ($$anchor, $$slotProps) => {
																				$.next();

																				var text_3 = $.text('Increase');

																				$.append($$anchor, text_3);
																			},
																			$$slots: { default: true }
																		});
																	});

																	$.append($$anchor, fragment_5);
																},
																$$slots: { default: true }
															});
														});

														var node_11 = $.sibling(node_7, 2);

														$.component(node_11, () => NumberField.ScrubArea, ($$anchor, NumberField_ScrubArea) => {
															NumberField_ScrubArea($$anchor, {
																'data-testid': 'scrub',
																children: ($$anchor, $$slotProps) => {
																	var fragment_6 = root_2();
																	var node_12 = $.first_child(fragment_6);

																	$.component(node_12, () => NumberField.ScrubAreaCursor, ($$anchor, NumberField_ScrubAreaCursor) => {
																		NumberField_ScrubAreaCursor($$anchor, {
																			'data-testid': 'cursor',
																			children: ($$anchor, $$slotProps) => {
																				$.next();

																				var text_4 = $.text('Cursor');

																				$.append($$anchor, text_4);
																			},
																			$$slots: { default: true }
																		});
																	});

																	$.next();
																	$.append($$anchor, fragment_6);
																},
																$$slots: { default: true }
															});
														});

														$.append($$anchor, fragment_4);
													},
													$$slots: { default: true }
												}));
											});
										}

										$.append($$anchor, fragment_3);
									};

									$.if(node_5, ($$render) => {
										if ($.get(shown)) $$render(consequent_1);
									});
								}

								var node_13 = $.sibling(node_5, 2);

								$.component(node_13, () => Field.Error, ($$anchor, Field_Error) => {
									Field_Error($$anchor, { id: 'number-error' });
								});

								var node_14 = $.sibling(node_13, 2);

								{
									const children = ($$anchor, state = $.noop) => {
										var output = root_4();
										var text_5 = $.only_child(output, true);

										$.template_effect(($0) => $.set_text(text_5, $0), [() => JSON.stringify(state())]);
										$.append($$anchor, output);
									};

									$.component(node_14, () => Field.Validity, ($$anchor, Field_Validity) => {
										Field_Validity($$anchor, { children, $$slots: { default: true } });
									});
								}

								$.append($$anchor, fragment_2);
							},
							$$slots: { default: true }
						});
					});
				}

				$.next(3);
				$.append($$anchor, fragment_1);
			},
			$$slots: { default: true }
		});
	}

	var button = $.sibling(node_1, 6);
	var button_1 = $.sibling(button, 2);
	var button_2 = $.sibling(button_1, 2);
	var output_1 = $.sibling(button_2, 2);
	var text_6 = $.only_child(output_1, true);
	var output_2 = $.sibling(output_1, 2);
	var text_7 = $.only_child(output_2, true);
	var output_3 = $.sibling(output_2, 2);
	var text_8 = $.only_child(output_3, true);
	var output_4 = $.sibling(output_3, 2);
	var text_9 = $.only_child(output_4, true);

	$.reset(main);

	$.template_effect(
		($0, $1, $2, $3) => {
			$.set_attribute(main, 'data-hydrated', $.get(hydrated));
			$.set_text(text_6, $0);
			$.set_text(text_7, $1);
			$.set_text(text_8, $2);
			$.set_text(text_9, $3);
		},
		[
			() => JSON.stringify(traces),
			() => JSON.stringify(submissions),
			() => JSON.stringify(validationCalls),
			() => JSON.stringify({
				root: $.get(rootRef)?.isConnected ?? false,
				visible: $.get(visibleRef)?.isConnected ?? false,
				hidden: $.get(hiddenRef)?.isConnected ?? false
			})
		]
	);

	$.delegated('click', button, () => {
		$.set(owner, 42);
	});

	$.delegated('click', button_1, () => {
		$.set(replacement, !$.get(replacement));
	});

	$.delegated('click', button_2, () => {
		$.set(shown, !$.get(shown));
	});

	$.append($$anchor, main);
	$.pop();
}

$.delegate(['click']);