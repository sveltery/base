import * as $ from 'svelte/internal/server';
import { fade } from 'svelte/transition';
import { NumberField } from '@sveltery/base/number-field';

export default function NumberFieldStepperOwnerBrowserFixture($$renderer, $$props) {
	// Native owner lifetime supplement; no unchanged upstream assertion credit.
	let { scenario } = $$props;

	let stage = 1;
	let nativeButton = true;
	let publishedHost = void 0;
	let outroStarted = 0;
	let outroEnded = 0;

	function hosts($$renderer, props) {
		if (stage < 3) {
			$$renderer.push('<!--[0-->');

			if (scenario === 'stepper-owner-outro') {
				$$renderer.push(`<!--[0--><button${$.attributes({ ...props, 'data-owner-host': 'A' })}>Outgoing increase</button>`);
			} else {
				$$renderer.push(`<!--[-1--><button${$.attributes({ ...props, 'data-owner-host': 'A' })}>Outgoing increase</button>`);
			}

			$$renderer.push(`<!--]-->`);
		} else {
			$$renderer.push('<!--[-1-->');
		}

		$$renderer.push(`<!--]--> `);

		if (stage > 1) {
			$$renderer.push(`<!--[0--><button${$.attributes({ ...props, 'data-owner-host': 'B' })}>Replacement increase</button>`);
		} else {
			$$renderer.push('<!--[-1-->');
		}

		$$renderer.push(`<!--]-->`);
	}

	let $$settled = true;
	let $$inner_renderer;

	function $$render_inner($$renderer) {
		if (NumberField.Root) {
			$$renderer.push('<!--[-->');

			NumberField.Root($$renderer, {
				defaultValue: 2,
				locale: 'en-US',
				children: ($$renderer) => {
					if (NumberField.Input) {
						$$renderer.push('<!--[-->');
						NumberField.Input($$renderer, {});
						$$renderer.push('<!--]-->');
					} else {
						$$renderer.push('<!--[!-->');
						$$renderer.push('<!--]-->');
					}

					$$renderer.push(` `);

					if (NumberField.Increment) {
						$$renderer.push('<!--[-->');

						NumberField.Increment($$renderer, {
							nativeButton,
							render: hosts,
							get ref() {
								return publishedHost;
							},

							set ref($$value) {
								publishedHost = $$value;
								$$settled = false;
							}
						});

						$$renderer.push('<!--]-->');
					} else {
						$$renderer.push('<!--[!-->');
						$$renderer.push('<!--]-->');
					}
				},
				$$slots: { default: true }
			});

			$$renderer.push('<!--]-->');
		} else {
			$$renderer.push('<!--[!-->');
			$$renderer.push('<!--]-->');
		}

		$$renderer.push(` <button id="owner-publish-replacement">Publish replacement</button> <button id="owner-dispose-outgoing">Dispose outgoing</button> <button id="owner-begin-outro">Replace with native outro</button> <button id="owner-require-nonnative">Require nonnative host</button> <button id="owner-require-native">Require native host</button> <output id="owner-published-host">${$.escape(publishedHost?.dataset.ownerHost ?? 'none')}</output> <output id="owner-outro-state">${$.escape(JSON.stringify({ started: outroStarted, ended: outroEnded }))}</output>`);
	}

	do {
		$$settled = true;
		$$inner_renderer = $$renderer.copy();
		$$render_inner($$inner_renderer);
	} while (!$$settled);

	$$renderer.subsume($$inner_renderer);
}