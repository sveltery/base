# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: number-field.spec.ts >> svelte NumberField stepper native outro retains its actual host diagnostics
- Location: tests/browser/number-field.spec.ts:531:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('[data-owner-host="A"]')
Expected: 1
Received: 0
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('[data-owner-host="A"]') with timeout 5000ms
  - waiting for locator('[data-owner-host="A"]')
    14 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- main [ref=e3]:
  - generic [ref=e4]:
    - textbox [ref=e5]: "2"
    - button "Increase" [ref=e6]: Replacement increase
  - spinbutton [aria-hidden] [ref=e7]: "2"
  - button "Publish replacement" [ref=e8]
  - button "Dispose outgoing" [ref=e9]
  - button "Replace with native outro" [active] [ref=e10]
  - button "Require nonnative host" [ref=e11]
  - button "Require native host" [ref=e12]
  - status [ref=e13]: B
  - status [ref=e14]: "{\"started\":0,\"ended\":0}"
  - generic [ref=e15]:
    - generic [ref=e16]:
      - generic [ref=e17]: Amount
      - paragraph [ref=e18]: A numeric amount
      - generic [ref=e19]:
        - group [ref=e20]:
          - button "Decrease" [ref=e21]
          - textbox "Amount" [ref=e22]: "2"
          - button "Increase" [ref=e23]
        - text: Scrub
      - spinbutton [aria-hidden] [ref=e24]: "2"
      - status [ref=e25]: "{\"state\":{\"badInput\":false,\"customError\":false,\"patternMismatch\":false,\"rangeOverflow\":false,\"rangeUnderflow\":false,\"stepMismatch\":false,\"tooLong\":false,\"tooShort\":false,\"typeMismatch\":false,\"valid\":null,\"valueMissing\":false},\"error\":\"\",\"errors\":[],\"value\":null,\"initialValue\":2,\"validity\":{\"badInput\":false,\"customError\":false,\"patternMismatch\":false,\"rangeOverflow\":false,\"rangeUnderflow\":false,\"stepMismatch\":false,\"tooLong\":false,\"tooShort\":false,\"typeMismatch\":false,\"valid\":null,\"valueMissing\":false}}"
    - button "Submit" [ref=e26]
    - button "Reset" [ref=e27]
  - button "Outside" [ref=e28]
  - button "Owner update" [ref=e29]
  - button "Replace input" [ref=e30]
  - button "Toggle root" [ref=e31]
  - status [ref=e32]: "[]"
  - status [ref=e33]: "[]"
  - status [ref=e34]: "[]"
  - status [ref=e35]: "{\"root\":true,\"visible\":true,\"hidden\":true}"
```

# Test source

```ts
  455 |   const warnings: string[] = [];
  456 |   page.on('console', (message) => {
  457 |     if (/hydration|mismatch/i.test(message.text())) warnings.push(message.text());
  458 |   });
  459 |   await page.goto('/number-field?scenario=precision');
  460 |   await expect(page.locator('main[data-hydrated="true"]')).toBeVisible();
  461 |   await expect(page.getByTestId('visible')).toHaveValue('1.235');
  462 |   await expect(page.getByTestId('visible')).toHaveAttribute('aria-labelledby', 'amount-label');
  463 |   await expect(page.locator('input[type="number"]')).toHaveValue('1.23456789');
  464 |   expect(warnings).toEqual([]);
  465 | });
  466 | test('Svelte actual Kit typed Form namespace composes authored source NumberField with native descriptor names and owner values', async ({
  467 |   page,
  468 | }) => {
  469 |   await page.goto('/number-field-remote');
  470 |   await expect(page.locator('main[data-hydrated="true"]')).toBeVisible();
  471 |   const input = page.getByTestId('remote-number-visible');
  472 |   await expect(input).toHaveValue('2');
  473 |   await expect(input).toHaveAttribute('aria-labelledby', 'remote-number-label');
  474 |   const serialized = await page
  475 |     .locator('#remote-number-form')
  476 |     .evaluate((form) => [...new FormData(form as HTMLFormElement)]);
  477 |   expect(serialized).toEqual([['n:amount', '2']]);
  478 |   await input.press('ArrowUp');
  479 |   await expect(page.locator('#remote-number-values')).toHaveText('{"amount":3}');
  480 |   await page.locator('#remote-number-owner').click();
  481 |   await expect(input).toHaveValue('4');
  482 |   await page.locator('#remote-number-submit').click();
  483 |   await expect(page.locator('#remote-number-result')).toContainText('"amount":4');
  484 |   await expect(page.locator('#remote-number-enhancements')).toHaveText('["caller","settled"]');
  485 | });
  486 | test('Svelte actual Kit invalid and canceled source submissions emit zero POSTs and a later valid submit emits one', async ({
  487 |   page,
  488 | }) => {
  489 |   let posts = 0;
  490 |   page.on('request', (request) => {
  491 |     if (request.method() === 'POST') posts += 1;
  492 |   });
  493 |   await page.goto('/number-field-remote');
  494 |   await expect(page.locator('main[data-hydrated="true"]')).toBeVisible();
  495 |   const input = page.getByTestId('remote-number-visible');
  496 |   await input.fill('7');
  497 |   await page.locator('#remote-number-submit').click();
  498 |   await expect(page.locator('#remote-number-error')).toHaveText('Seven unavailable locally');
  499 |   expect(posts).toBe(0);
  500 |   await input.fill('5');
  501 |   await page.locator('#remote-number-cancel-submit').click();
  502 |   await page.locator('#remote-number-submit').click();
  503 |   await expect(page.locator('#remote-number-enhancements')).toHaveText('[]');
  504 |   expect(posts).toBe(0);
  505 |   await page.locator('#remote-number-cancel-submit').click();
  506 |   await page.locator('#remote-number-submit').click();
  507 |   await expect(page.locator('#remote-number-result')).toContainText('"amount":5');
  508 |   expect(posts).toBe(1);
  509 | });
  510 | test('Svelte actual Kit source change cancellation retains owner and live server issues remain Field-owned', async ({
  511 |   page,
  512 | }) => {
  513 |   await page.goto('/number-field-remote');
  514 |   await expect(page.locator('main[data-hydrated="true"]')).toBeVisible();
  515 |   const input = page.getByTestId('remote-number-visible');
  516 |   await page.locator('#remote-number-cancel-change').click();
  517 |   await input.press('ArrowUp');
  518 |   await expect(input).toHaveValue('2');
  519 |   await expect(page.locator('#remote-number-values')).toHaveText('{"amount":2}');
  520 |   await page.locator('#remote-number-cancel-change').click();
  521 |   await input.fill('9');
  522 |   await page.locator('#remote-number-submit').click();
  523 |   await expect(page.locator('#remote-number-error')).toHaveText('Server amount unavailable');
  524 |   await input.fill('4');
  525 |   await page.locator('#remote-number-submit').click();
  526 |   await expect(page.locator('#remote-number-result')).toContainText('"amount":4');
  527 | });
  528 | 
  529 | // Native-only actual-host owner lifetime supplements; zero unchanged upstream credit.
  530 | for (const mode of ['same-host', 'replacement', 'outro'] as const) {
  531 |   test(`svelte NumberField stepper native ${mode} retains its actual host diagnostics`, async ({
  532 |     page,
  533 |   }) => {
  534 |     const diagnostics: string[] = [];
  535 |     page.on('console', (message) => {
  536 |       if (
  537 |         message.type() === 'error' &&
  538 |         message.text().includes('Base UI: A component that acts as a button')
  539 |       )
  540 |         diagnostics.push(message.text());
  541 |     });
  542 |     await page.goto(`/number-field?scenario=stepper-owner-${mode}`);
  543 |     await expect(page.locator('main[data-hydrated="true"]')).toBeVisible();
  544 |     await expect(page.locator('[data-owner-host="A"]')).toBeVisible();
  545 |     await expect(page.locator('#owner-published-host')).toHaveText('A');
  546 |     if (mode === 'replacement') {
  547 |       await page.locator('#owner-publish-replacement').click();
  548 |       await expect(page.locator('[data-owner-host="A"]')).toBeVisible();
  549 |       await expect(page.locator('[data-owner-host="B"]')).toBeVisible();
  550 |       await expect(page.locator('#owner-published-host')).toHaveText('B');
  551 |       await page.locator('#owner-dispose-outgoing').click();
  552 |     } else if (mode === 'outro') {
  553 |       await page.locator('#owner-begin-outro').click();
  554 |       // Real Svelte out:fade retains A while replacement B has its own attachment.
> 555 |       await expect(page.locator('[data-owner-host="A"]')).toHaveCount(1);
      |                                                           ^ Error: expect(locator).toHaveCount(expected) failed
  556 |       await expect(page.locator('[data-owner-host="B"]')).toBeVisible();
  557 |       await expect(page.locator('#owner-published-host')).toHaveText('B');
  558 |       await expect(page.locator('#owner-outro-state')).toHaveText('{"started":1,"ended":0}');
  559 |     }
  560 |     if (mode !== 'same-host') {
  561 |       await expect(page.locator('[data-owner-host="A"]')).toHaveCount(0);
  562 |       await expect(page.locator('#owner-published-host')).toHaveText('B');
  563 |     }
  564 |     if (mode === 'outro')
  565 |       await expect(page.locator('#owner-outro-state')).toHaveText('{"started":1,"ended":1}');
  566 |     expect(diagnostics).toEqual([]);
  567 |     await page.locator('#owner-require-nonnative').click();
  568 |     await expect.poll(() => diagnostics.length).toBe(1);
  569 |     expect(diagnostics[0]).toContain('expected a non-<button>');
  570 |     await expect(
  571 |       page.locator(`[data-owner-host="${mode === 'same-host' ? 'A' : 'B'}"]`),
  572 |     ).toHaveAttribute('role', 'button');
  573 |   });
  574 | }
  575 | 
```