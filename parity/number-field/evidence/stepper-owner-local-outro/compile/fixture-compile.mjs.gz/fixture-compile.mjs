import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
const repository = process.cwd();
const output = '/workspace/scratch/2bab9a276da0/stepper-owner-witness/focused-gates';
const require = createRequire(join(repository, 'apps/fixtures/package.json'));
const { compile } = require('svelte/compiler');
const { render } = require('svelte/server');
for (const file of ['NumberFieldStepperOwnerBrowserFixture.svelte', 'NumberFieldBrowserFixture.svelte']) {
  const filename = join(repository, 'apps/fixtures/src/lib', file);
  for (const generate of ['server', 'client']) {
    const result = compile(readFileSync(filename, 'utf8'), { filename, generate });
    writeFileSync(join(output, `${file}.${generate}.js`), result.js.code);
    assert.equal(result.warnings.length, 0);
    console.log(`${file} ${generate} compilation PASS: ${result.js.code.length} JavaScript bytes, zero warnings`);
  }
}
const { default: Fixture } = await import(join(repository, 'apps/fixtures/src/lib/NumberFieldBrowserFixture.svelte'));
const result = render(Fixture, { props: { scenario: 'stepper-owner-outro' } });
assert.match(result.body, /data-owner-host="A"/);
assert.doesNotMatch(result.body, /data-owner-host="B"/);
assert.match(result.body, /id="owner-begin-outro"/);
assert.match(result.body, /id="owner-outro-state"/);
writeFileSync(join(output, 'fixture-owner-ssr.html'), result.body);
console.log('Actual no-browser outer NumberFieldBrowserFixture owner-outro SSR PASS: initial real A host and native-outro controls');
