import * as $ from 'svelte/internal/server';
import { fade } from 'svelte/transition';
import { onDestroy, tick } from 'svelte';
import { NumberField } from '@sveltery/base/number-field';

export default function NumberFieldStepperOwnerBrowserFixture($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		// Native owner lifetime supplement; no unchanged upstream assertion credit.
		let { scenario } = $$props;

		let stage = 1;
		let nativeButton = true;
		let publishedHost = void 0;
		let outroStarted = 0;
		let outroEnded = 0;
		let incomingHost = void 0;
		let diagnosticPhase = 'idle';
		let lifetimeRecords = [];
		let destroyed = false;

		onDestroy(() => {
			destroyed = true;
		});

		function recordOutro(event, phase) {
			const outgoing = event.currentTarget;

			if (phase === 'start') outroStarted += 1; else outroEnded += 1;

			// Observe real native hosts after Svelte has committed the replacement or disposal.
			void tick().then(() => {
				if (destroyed) return;

				lifetimeRecords.push({
					phase,
					outgoingConnected: outgoing.isConnected,
					incomingConnected: incomingHost?.isConnected ?? false,
					publishedHost: publishedHost?.dataset.ownerHost ?? 'none',
					publishedIsIncoming: publishedHost === incomingHost
				});
			});
		}

		function hosts($$renderer, props) {
			if (scenario === 'stepper-owner-outro') {
				$$renderer.push('<!--[0-->');

				if (stage < 3) {
					$$renderer.push(`<!--[0--><button${$.attributes({ ...props, 'data-owner-host': 'A' })}>Outgoing increase</button>`);
				} else {
					$$renderer.push('<!--[-1-->');
				}

				$$renderer.push(`<!--]-->`);
			} else if (stage < 3) {
				$$renderer.push(`<!--[1--><button${$.attributes({ ...props, 'data-owner-host': 'A' })}>Outgoing increase</button>`);
			} else {
				$$renderer.push('<!--[-1-->');
			}

			$$renderer.push(`<!--]--> `);

			if (stage > 1) {
				$$renderer.push(`<!--[0--><button${$.attributes({ ...props, 'data-owner-host': 'B' })}>Replacement increase</button>`);
			} else {
				$$renderer.push('<!--[-1-->');
			}

			$$renderer.push(`<!--]-->`);
		}

		let $$settled = true;
		let $$inner_renderer;

		function $$render_inner($$renderer) {
			if (NumberField.Root) {
				$$renderer.push('<!--[-->');

				NumberField.Root($$renderer, {
					defaultValue: 2,
					locale: 'en-US',
					children: ($$renderer) => {
						if (NumberField.Input) {
							$$renderer.push('<!--[-->');
							NumberField.Input($$renderer, {});
							$$renderer.push('<!--]-->');
						} else {
							$$renderer.push('<!--[!-->');
							$$renderer.push('<!--]-->');
						}

						$$renderer.push(` `);

						if (NumberField.Increment) {
							$$renderer.push('<!--[-->');

							NumberField.Increment($$renderer, {
								nativeButton,
								render: hosts,
								get ref() {
									return publishedHost;
								},

								set ref($$value) {
									publishedHost = $$value;
									$$settled = false;
								}
							});

							$$renderer.push('<!--]-->');
						} else {
							$$renderer.push('<!--[!-->');
							$$renderer.push('<!--]-->');
						}
					},
					$$slots: { default: true }
				});

				$$renderer.push('<!--]-->');
			} else {
				$$renderer.push('<!--[!-->');
				$$renderer.push('<!--]-->');
			}

			$$renderer.push(` <button id="owner-publish-replacement">Publish replacement</button> <button id="owner-dispose-outgoing">Dispose outgoing</button> <button id="owner-begin-outro">Replace with native outro</button> <button id="owner-require-nonnative">Require nonnative host</button> <button id="owner-require-native">Require native host</button> <output id="owner-published-host">${$.escape(publishedHost?.dataset.ownerHost ?? 'none')}</output> <output id="owner-outro-state">${$.escape(JSON.stringify({ started: outroStarted, ended: outroEnded }))}</output> <output id="owner-lifetime-records">${$.escape(JSON.stringify(lifetimeRecords))}</output> <output id="owner-diagnostic-phase">${$.escape(diagnosticPhase)}</output>`);
		}

		do {
			$$settled = true;
			$$inner_renderer = $$renderer.copy();
			$$render_inner($$inner_renderer);
		} while (!$$settled);

		$$renderer.subsume($$inner_renderer);
	});
}