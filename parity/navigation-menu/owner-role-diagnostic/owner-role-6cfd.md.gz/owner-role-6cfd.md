# NavigationMenu owner-role diagnostic

Candidate `6cfd4a49088347301db195fe661357ea73742d3f`; immutable pin `47b40521eab921c2756bf9bdb0b0f07fbfdb8c8c`. Complete graph inventory: 137 modules / 542 import statements, all 137 actual Git body hashes match recorded closure.

This diagnostic identifies native representation work. It does not claim a new Source business bug, runtime pass, complete source equivalence, final review or acceptance. Existing original assertions and red provenance remain binding.

AGENTS requires classes for reusable state-owner roles previously carried by custom hooks. Direct component state, native lifecycle/context integration, thin class factories and stateless business algorithms remain valid.

| Function / actual path and line | Allocated persistent role | Actual seam |
| --- | --- | --- |
| `useTransitionStatus` — `packages/base/src/lib/internals/useTransitionStatus.svelte.ts:7` | phase and retainedMounted runes; frame requests/cancellation | Root/Content presence |
| `useAnimationsFinished` — `packages/base/src/lib/internals/useAnimationsFinished.ts:25` | allocated AnimationFrame and animation/start-style MutationObserver completion watcher | Trigger and OpenChangeComplete |
| `useOpenChangeComplete` — `packages/base/src/lib/internals/useOpenChangeComplete.svelte.ts:11` | animation completion instance and per-open/host abortable watcher | Root/Content completion |
| `useFloating` — `packages/base/src/lib/internals/anchor-positioning/useFloating.svelte.ts:25` | reactive hosts/data/error, request/generation ownership and autoUpdate teardown | Positioner DOM geometry driver |
| `useAnchorPositioningWithHook` — `packages/base/src/lib/internals/anchor-positioning/useAnchorPositioning.svelte.ts:28` | arrow and mountSide state, registered external anchor, orchestration of positioning owner | Positioner anchor orchestration |
| `useFloatingWithStore` — `packages/base/src/lib/floating-ui/hooks/useFloating.svelte.ts:47` | local reference/floating state and captured root/tree context publication | Positioner public Floating path |
| `useClick` — `packages/base/src/lib/floating-ui/hooks/useClick.svelte.ts:59` | pointer type across events plus allocated frame and touch request timer | Trigger click interaction |
| `useDismiss` — `packages/base/src/lib/floating-ui/hooks/useDismiss.svelte.ts:117` | press/touch/composition session state; timeout owners; bus/document listener registration | List dismissal interaction |
| `createCompositeList` — `packages/base/src/lib/internals/composite/list/createCompositeList.svelte.ts:20` | registration/listener maps, dirty/index refs, MutationObserver and teardown | CompositeRoot list provider |
| `useCompositeListItem` — `packages/base/src/lib/internals/composite/list/useCompositeListItem.svelte.ts:12` | internal index rune, captured registered host and map-change subscription | CompositeItem enrollment |
| `useCompositeRoot` — `packages/base/src/lib/internals/composite/root/useCompositeRoot.svelte.ts:71` | highlighted-index state, default-index/host/item refs and navigation owner | CompositeRoot roving focus |
| `useCompositeItem` — `packages/base/src/lib/internals/composite/item/useCompositeItem.svelte.ts:5` | allocated actual itemRef plus attachment-owned enrollment cleanup | CompositeItem current host/focus |
| `useButton` — `packages/base/src/lib/internals/use-button/useButton.svelte.ts:19` | allocated reactive actual host and disabled synchronization lifetime | Trigger button owner |
| `useFloatingPortalNode` — `packages/base/src/lib/floating-ui/hooks/useFloatingPortalNode.svelte.ts:31` | container/portal node/id state, host MutationObserver and mounted PortalHost teardown | FloatingPortal native host |
| `useFloatingPortalContent` — `packages/base/src/lib/floating-ui/hooks/useFloatingPortalNode.svelte.ts:132` | mounted PortalContent instance and captured target teardown | Content/FloatingPortal relocation |
| `useHoverFloatingInteraction` — `packages/base/src/lib/floating-ui/hooks/useHoverFloatingInteraction.svelte.ts:51` | persistent Floating hover interaction handlers, installed subscriptions and timer/request ownership | List hover interaction; known pending lane |
| `useHoverReferenceInteraction` — `packages/base/src/lib/floating-ui/hooks/useHoverReferenceInteraction.svelte.ts:78` | persistent reference hover listener/rest/open request ownership | Trigger hover interaction; known pending lane |

## Disposition

The two hover functions have a known pending canonical Floating class lane. The other fifteen findings require lead assignment; this audit does not expand PR42 fallback ownership into Composite class ownership or assign every Floating role to the current hover owner. Preserve recognizable full Source bodies, callback/branch order, live state, actual subscription targets, cancellation and captured cleanup. No per-part workaround or duplicated helper is authorized.

Existing real classes include Controlled, Timeout, AnimationFrame/Scheduler, Store/SvelteStore, FloatingRootStore, FloatingTreeStore, PopupTriggerMap and HoverInteraction. useFloatingRootContext is a thin live integration around FloatingRootStore; useHoverInteractionSharedState integrates HoverInteraction. usePositioner only derives prop business. createEventEmitter is pinned business, not a React custom-hook lifetime adapter. Native Svelte component state/effects and useFloatingNodeId context enrollment are direct native integration, so this audit does not demand ornamental classes around them.

The JSON includes every used module body hash, original correspondence paths, sorted direct caller/import seams and precise finding lines. Original body hashes are from the immutable supplied tar archive where present; missing entries are expressly recorded and do not receive source credit.

PR42 Composite fallback and PR73 nativeProps empty-style transport are reached dependencies. Final native/business/maintainability acceptance remains pending accepted-main integration, exact stable pushed-head independent closure review and required local/secured hosted gates.

No tracked helper edits or heavy test launches were made.
