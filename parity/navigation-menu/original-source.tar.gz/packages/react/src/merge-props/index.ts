export * from './mergeProps';
